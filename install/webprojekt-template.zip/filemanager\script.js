let editor = null;
let darkModeVal = localStorage.getItem("darkMode");
let darkMode = darkModeVal === null ? true : (darkModeVal === "true");

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¾ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ Dark Mode
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    applyEditorTheme();
}
// Initialer Check ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ nur wenn body bereits existiert (script am Ende des body)
if (document.body) {
    if (darkMode) {
        document.body.classList.add("dark-mode");
    } else {
        document.body.classList.remove("dark-mode");
    }
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â½ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨ Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    const ec = document.getElementById("editor-container");
    if (ec) ec.style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "[DIR]";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "[HTML]",
        htm: "[HTML]",
        php: "[PHP]",
        js: "[JS]",
        css: "[CSS]",
        txt: "[TXT]",
        json: "[JSON]",
        pdf: "[PDF]",
        ico: "[ICO]",
        zip: "[ZIP]",
        rar: "[RAR]",
        png: "[IMG]",
        jpg: "[IMG]",
        jpeg: "[IMG]",
        mp4: "[VID]",
        mov: "[VID]"
    };
    return icons[ext] || "[FILE]";
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ HTML escapen (XSS-Schutz)
function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'm4v', 'ogg', 'ogv'];

function getExtension(name) {
    const parts = String(name || '').toLowerCase().split('.');
    return parts.length > 1 ? parts.pop() : '';
}

function isImageFile(name) {
    return IMAGE_EXTENSIONS.includes(getExtension(name));
}

function isVideoFile(name) {
    return VIDEO_EXTENSIONS.includes(getExtension(name));
}

function isMediaFile(name) {
    return isImageFile(name) || isVideoFile(name);
}
const systemBlockedFileMap = new Map();

function showSystemBlockedMessage() {
    return customModal({
        title: 'System gesperrt',
        message: 'Diese Datei ist durch das System gesperrt und kann nicht bearbeitet werden.'
    });
}

const EXTENSION_ASYNC_MESSAGE = 'A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received';
let extensionAsyncWarningShown = false;
window.addEventListener('unhandledrejection', event => {
    const reason = event && event.reason;
    const message = typeof reason === 'string'
        ? reason
        : (reason && typeof reason.message === 'string' ? reason.message : '');

    if (message.includes(EXTENSION_ASYNC_MESSAGE)) {
        event.preventDefault();
        if (!extensionAsyncWarningShown) {
            extensionAsyncWarningShown = true;
            console.info('Hinweis: Eine Browser-Erweiterung verursacht asynchrone Message-Channel-Errors.');
        }
    }
});
// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¼ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â Custom Modal
function customModal({
    title,
    message,
    type = 'alert',
    confirmText = 'OK',
    cancelText = 'Abbrechen',
    inputPlaceholder = '',
    defaultValue = ''
}) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay modal-front"></div>');
        const card = $('<div class="modal-card"></div>');
        const header = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close" title="Schlie&szlig;en">x</button>');
        header.append(closeBtn);
        closeBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        const body = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${defaultValue}">`);
            body.append(input);
        }

        const confirmBtn = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const cancelBtn = $(`<button class="btn btn-secondary">${cancelText}</button>`);


        confirmBtn.on('click', () => {
            let result = true;
            if (type === 'prompt') result = input.val();
            overlay.remove();
            resolve(result);
        });
        cancelBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        footer.append(cancelBtn).append(confirmBtn);
        if (type === 'alert') cancelBtn.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').append(overlay);
        if (input) input.focus();
    });
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¾ Dateien laden
function loadFiles() {
    const dirInput = document.getElementById("directoryPath");
    if (!dirInput) return;
    const dir = dirInput.value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            customModal({
                title: 'Fehler',
                message: escHtml(data.error)
            });
            return;
        }

        const table = $("#fileTable").empty();
        systemBlockedFileMap.clear();
        const files = data.files || [];
        const separator = dir.includes("\\") ? "\\" : "/";

        if (files.length === 0) {
            table.append(`
                <tr>
                    <td colspan="6" style="text-align:center; padding:60px 20px; color:var(--text-muted);">
                        <div style="font-size:48px; margin-bottom:16px;">ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡</div>
                        <h3 style="margin:0 0 8px; color:var(--text);">Dieser Ordner ist leer</h3>
                        <p style="margin:0 0 24px; font-size:14px;">Lade eine Datei hoch oder erstelle einen neuen Ordner.</p>
                    </td>
                </tr>
            `);
            return;
        }

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = (dir === '.' ? '' : dir).replace(/[/\\]$/, "") + (dir === '.' ? '' : separator) + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";
            const isPrivate = !!file.isPrivate;
            const nameEsc = escHtml(file.name);
            const typeEsc = escHtml(file.type);
            const dateEsc = escHtml(file.date);
            // Schloss-Icon fÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¼r private Elemente (nur Admin sieht es, da normale User private Elemente gar nicht sehen)
            const privBadge = (window.isSystemAdmin && isPrivate) ? ' <span title="Privat - nur Admins" style="font-size:12px; opacity:0.7;">[P]</span>' : '';
            let badgeText = isPrivate ? 'Verborgen' : 'Sichtbar';
            let badgeClass = isPrivate ? 'vis-private' : 'vis-public';
            if (file.isSystemBlocked) {
                badgeText = 'Gesperrt';
                badgeClass = 'vis-system';
            }

            const sizeEsc = escHtml(file.sizeFormatted || '-');

            const row = $(`
                <tr data-type="${typeEsc}" data-name="${nameEsc}" data-path="${escHtml(fullPath)}">
                    <td style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:0;" title="${nameEsc}">${icon} ${nameEsc}</td>
                    <td>
                        <span class="vis-badge ${badgeClass}">
                            ${badgeText}
                        </span>
                    </td>
                    <td>${typeEsc}</td>
                    <td>${sizeEsc}</td>
                    <td>${dateEsc}</td>
                    <td>
                        <div class="action-btn-group">
                            <button class="btn btn-primary  btn-small js-open-folder" title="Oeffnen" style="display:${isFolder?'':'none'}">Oeffnen</button>
                            <button class="btn btn-warning  btn-small js-edit-file" title="Bearbeiten" style="display:${isFolder?'none':''}">Edit</button>
                            <button class="btn btn-warning  btn-small js-rename" title="Umbenennen">Rename</button>
                            <button class="btn btn-danger   btn-small js-delete" title="Loeschen">Loeschen</button>
                            <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-small" title="Herunterladen">Download</a>
                            ${window.isSystemAdmin ? `<button class="btn btn-secondary btn-small js-visibility" title="${isPrivate?'Privat - klicken um oeffentlich zu setzen':'Oeffentlich - klicken um privat zu setzen'}" style="opacity:${isPrivate?'1':'0.5'}; visibility:${file.isSystemBlocked ? 'hidden' : 'visible'};">${isPrivate?'Privat':'Oeffentlich'}</button>` : ''}
                        </div>
                    </td>
                </tr>`);

            row.find('.js-open-folder').on('click', () => openFolderByPath(encodeURIComponent(file.name)));
            row.find('.js-edit-file').on('click', () => handleEditAction(file, fullPath));
            row.find('.js-rename').on('click', () => renameFile(file.name));
            row.find('.js-delete').on('click', () => deleteFile(file.name));
            row.find('.js-visibility').on('click', () => showVisibility(fullPath, isFolder, isPrivate));
            if (!isFolder) {
                systemBlockedFileMap.set(fullPath, !!file.isSystemBlocked);
            }

            table.append(row);
        });
    }).fail(jqXHR => customModal({
        title: 'Fehler',
        message: "Ladefehler: " + escHtml(jqXHR.responseText)
    }));
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â Sichtbarkeit verwalten
async function showVisibility(path, isFolder, currentlyPrivate) {
    if (!window.isSystemAdmin) return customModal({
        title: 'Zugriff verweigert',
        message: 'Admin-Rechte erforderlich!'
    });

    const itemName = path.split('/').pop() || path.split('\\').pop() || path;

    if (currentlyPrivate) {
        let cascade = false;
        if (isFolder) {
            const overlay = $('<div class="modal-overlay modal-front"></div>');
            const card = $(`
                <div class="modal-card" style="max-width:420px;">
                    <div class="modal-header">Ordner oeffentlich setzen
                        <button class="modal-close">x</button>
                    </div>
                    <div class="modal-body">
                        <p>Ordner <b>${escHtml(itemName)}</b> fuer alle angemeldeten Nutzer sichtbar machen?</p>
                        <div style="margin-top:15px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px;">
                                <input type="checkbox" id="vis-cascade" style="width:18px; height:18px; flex-shrink:0;">
                                <span>Auch alle Unterordner und Dateien oeffentlich setzen (private Einzel-Einstellungen entfernen)</span>
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="vis-cancel">Abbrechen</button>
                        <button class="btn btn-success" id="vis-confirm">Oeffentlich setzen</button>
                    </div>
                </div>`);
            overlay.append(card);
            $('body').append(overlay);
            card.find('.modal-close, #vis-cancel').on('click', () => {
                overlay.remove();
                return;
            });
            card.find('#vis-confirm').on('click', () => {
                cascade = card.find('#vis-cascade').is(':checked');
                overlay.remove();
                doSetVisibility(path, 'public', cascade);
            });
            return;
        }

        const ok = await customModal({
            title: 'Oeffentlich setzen',
            message: `<b>${escHtml(itemName)}</b> fuer alle angemeldeten Nutzer sichtbar machen?`,
            type: 'confirm',
            confirmText: 'Oeffentlich setzen'
        });
        if (ok) doSetVisibility(path, 'public', false);
    } else {
        let msg = `<b>${escHtml(itemName)}</b> nur fuer Admins sichtbar machen?`;
        if (isFolder) msg += `<br><br><span style="font-size:12px; color:#94a3b8;">Alle Unterordner und Dateien werden automatisch ausgeblendet - kein einzelnes Setzen noetig.</span>`;
        const ok = await customModal({
            title: 'Privat setzen',
            message: msg,
            type: 'confirm',
            confirmText: 'Privat setzen'
        });
        if (ok) doSetVisibility(path, 'private', false);
    }
}
function doSetVisibility(path, status, cascade) {
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'set_visibility',
            path,
            status,
            cascade
        }),
        success: res => {
            if (res.error) customModal({
                title: 'Fehler',
                message: escHtml(res.error)
            });
            else {
                customModal({
                    title: 'Gespeichert',
                    message: escHtml(res.success)
                });
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: 'Fehler',
            message: 'Fehler: ' + escHtml(jqXHR.responseText)
        })
    });
}

// Ordner ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¶ffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    const sep = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + sep + name;
    loadFiles();
}

$(document).on("click", "#fileTable tr", function(e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").trim();
    const type = $(this).attr("data-type");
    if (type === "folder" || type === "Ordner") openFolderByPath(name);
});

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â Datei bearbeiten
function handleEditAction(file, fullPath) {
    if (file && file.isSystemBlocked) {
        showSystemBlockedMessage();
        return;
    }
    if (isMediaFile(file.name)) {
        showMediaActionModal(file, fullPath);
        return;
    }
    editFile(file.name, file);
}

function showMediaActionModal(file, fullPath) {
    const fileName = escHtml(file.name).replace(/\uFFFD/g, "");
    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:520px;">
            <div class="modal-header">Medien-Aktionen: ${fileName}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body">
                <p>Diese Datei kann nicht als Text bearbeitet werden. W&auml;hle stattdessen eine Aktion:</p>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                    <button type="button" class="btn btn-primary" id="media-meta-btn">Metadaten bearbeiten</button>
                    <button type="button" class="btn btn-success" id="media-view-btn">Datei anzeigen</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="media-cancel-btn">Schlie&szlig;en</button>
            </div>
        </div>
    `);
    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    card.find('.modal-close, #media-cancel-btn').on('click', close);
    card.find('#media-view-btn').on('click', () => {
        close();
        showMediaViewer(file, fullPath);
    });
    card.find('#media-meta-btn').on('click', () => {
        close();
        showMediaMetadataEditor(file, fullPath);
    });
}

function showMediaViewer(file, fullPath) {
    const encodedPath = encodeURIComponent(fullPath);
    const url = `download.php?path=${encodedPath}&inline=1`;
    const fileName = escHtml(file.name).replace(/\uFFFD/g, "");

    let viewerHtml = '';
    if (isImageFile(file.name)) {
        viewerHtml = `<img src="${url}" alt="${fileName}" style="max-width:100%; max-height:70vh; border-radius:10px; display:block; margin:0 auto;">`;
    } else if (isVideoFile(file.name)) {
        viewerHtml = `<video controls style="width:100%; max-height:70vh; border-radius:10px; background:black;"><source src="${url}">Dein Browser unterstuetzt dieses Videoformat nicht.</video>`;
    } else {
        window.open(url, '_blank', 'noopener');
        return;
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:900px; width:min(900px, 95vw);">
            <div class="modal-header">Vorschau: ${fileName}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body" style="text-align:center;">
                ${viewerHtml}
                <p style="margin-top:12px; font-size:12px; opacity:0.75;">Falls die Vorschau blockiert ist, oeffnet der Link die Datei direkt.</p>
            </div>
            <div class="modal-footer">
                <a href="${url}" target="_blank" rel="noopener" class="btn btn-success">In neuem Tab oeffnen</a>
                <button type="button" class="btn btn-secondary" id="media-view-close-btn">Schlie&szlig;en</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);
    card.find('.modal-close, #media-view-close-btn').on('click', () => overlay.remove());
}

async function showMediaMetadataEditor(file, fullPath) {
    let meta = null;
    try {
        const response = await $.ajax({
            url: 'media_api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'get', path: fullPath })
        });
        if (response.error) {
            throw new Error(response.error);
        }
        meta = response.metadata || {};
    } catch (err) {
        customModal({
            title: 'Fehler',
            message: escHtml(err.message || 'Metadaten konnten nicht geladen werden.')
        });
        return;
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:650px;">
            <div class="modal-header">Metadaten: ${escHtml(file.name)}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body">
                <div style="font-size:12px; opacity:0.75; margin-bottom:12px;">
                    Typ: <b>${escHtml(meta.mimeType || 'unbekannt')}</b> - Groesse: <b>${escHtml(meta.sizeFormatted || '-')}</b>
                </div>
                <label style="display:block; margin-bottom:6px;">Datum/Zeit</label>
                <input type="text" id="meta-capturedAt" class="modal-input" placeholder="z. B. 2026-05-31 14:30:00" value="${escHtml(meta.capturedAt || '')}">

                <label style="display:block; margin:12px 0 6px;">Standort</label>
                <input type="text" id="meta-location" class="modal-input" placeholder="z. B. Berlin, Deutschland" value="${escHtml(meta.location || '')}">

                <label style="display:block; margin:12px 0 6px;">Beschreibung</label>
                <textarea id="meta-description" class="modal-input" rows="4" style="resize:vertical;">${escHtml(meta.description || '')}</textarea>

                <p style="font-size:12px; opacity:0.7; margin-top:10px;">Hinweis: Datum aktualisiert zusaetzlich das Dateidatum, Standort/Beschreibung werden systemseitig gespeichert.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="meta-cancel-btn">Abbrechen</button>
                <button type="button" class="btn btn-primary" id="meta-save-btn">Speichern</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    card.find('.modal-close, #meta-cancel-btn').on('click', close);

    card.find('#meta-save-btn').on('click', async () => {
        const payload = {
            action: 'save',
            path: fullPath,
            metadata: {
                capturedAt: card.find('#meta-capturedAt').val().trim(),
                location: card.find('#meta-location').val().trim(),
                description: card.find('#meta-description').val().trim()
            }
        };

        const saveBtn = card.find('#meta-save-btn');
        saveBtn.prop('disabled', true).text('Speichert...');

        try {
            const response = await $.ajax({
                url: 'media_api.php',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(payload)
            });
            if (response.error) {
                throw new Error(response.error);
            }
            close();
            customModal({
                title: 'Gespeichert',
                message: escHtml(response.success || 'Metadaten wurden gespeichert.')
            });
            loadFiles();
        } catch (err) {
            saveBtn.prop('disabled', false).text('Speichern');
            customModal({
                title: 'Fehler',
                message: escHtml(err.message || 'Metadaten konnten nicht gespeichert werden.')
            });
        }
    });
}
let currentEditingPath = "";

function editFile(name, fileMeta = null) {
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + sep + name;
    if ((fileMeta && fileMeta.isSystemBlocked) || systemBlockedFileMap.get(currentEditingPath)) {
        showSystemBlockedMessage();
        return;
    }
    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({
            title: 'Fehler',
            message: escHtml(data.error)
        });
        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();
        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = {
                php: "php",
                js: "javascript",
                css: "css",
                html: "html",
                txt: "plaintext"
            };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => customModal({
        title: 'Fehler',
        message: "Fehler: " + escHtml(jqXHR.responseText)
    }));
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¾ Datei speichern
async function saveFile() {
    if (!editor) return;
    if (systemBlockedFileMap.get(currentEditingPath)) {
        showSystemBlockedMessage();
        return;
    }
    const content = editor.getValue();
    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content
        }),
        success: response => {
            if (response.error) customModal({
                title: 'Fehler',
                message: escHtml(response.error)
            });
            else {
                customModal({
                    title: 'Gespeichert',
                    message: response.success || "Gespeichert."
                });
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: 'Fehler',
            message: "Fehler beim Speichern: " + escHtml(jqXHR.responseText)
        })
    });
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â Modal
function openEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        overlay.classList.remove("hidden");
        $(overlay).fadeIn();
    }
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        $(overlay).fadeOut(() => overlay.classList.add("hidden"));
    }
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â LÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¶schen (Server entscheidet ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¼ber Berechtigung)
async function deleteFile(name) {
    const confirmed = await customModal({
        title: 'Loeschen bestaetigen',
        message: `"${escHtml(name)}" wirklich loeschen?`,
        type: 'confirm',
        confirmText: 'Ja',
        cancelText: 'Nein'
    });
    if (!confirmed) return;

    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + sep + name;

    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) customModal({
            title: 'Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'Geloescht',
                message: response.success || "Geloescht."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: 'Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}
async function renameFile(oldName) {
    const newName = await customModal({
        title: 'Umbenennen',
        message: 'Neuer Name:',
        type: 'prompt',
        defaultValue: oldName
    });
    if (!newName || newName === oldName) return;
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName,
        newName
    }), response => {
        if (response.error) customModal({
            title: 'Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'Umbenannt',
                message: response.success || "Umbenannt."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: 'Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¾ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ Erstellen (Server entscheidet ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¼ber Berechtigung)
async function createFile(isFolder = false) {
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return customModal({
        title: 'Eingabe erforderlich',
        message: "Bitte Namen eingeben!"
    });
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "create",
        path: dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        if (response.error) customModal({
            title: 'Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'Erstellt',
                message: response.success || "Erstellt."
            });
            loadFiles();
            document.getElementById(inputId).value = "";
        }
    }, "json").fail(jqXHR => customModal({
        title: 'Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

function createFolder() {
    createFile(true);
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â Upload
function uploadFile(event) {
    if (event) event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;

    let fileToUpload = null;
    if (fileInput.files.length) {
        fileToUpload = fileInput.files[0];
    } else if (window.droppedFile) {
        fileToUpload = window.droppedFile;
    }

    if (!fileToUpload) {
        return customModal({
            title: 'Auswahl erforderlich',
            message: "Bitte waehle eine Datei aus."
        });
    }

    const maxSize = 2 * 1024 * 1024 * 1024;
    if (fileToUpload.size > maxSize) {
        return customModal({
            title: 'Datei zu gross',
            message: `Die Datei "${escHtml(fileToUpload.name)}" ist zu gross (${(fileToUpload.size / 1024 / 1024 / 1024).toFixed(2)} GB). Das maximale Upload-Limit betraegt 2 GB.`
        });
    }

    const progressContainer = document.getElementById("uploadProgressContainer");
    const progressBar = document.getElementById("uploadProgressBar");
    const uploadBtn = document.getElementById("uploadBtn");

    progressContainer.style.display = "block";
    progressBar.style.width = "0%";
    uploadBtn.disabled = true;
    uploadBtn.textContent = "Laedt...";

    const resetUploadUI = () => {
        progressContainer.style.display = "none";
        progressBar.style.width = "0%";
        uploadBtn.disabled = false;
        uploadBtn.textContent = "Hochladen";
    };

    uploadFileInChunks(fileToUpload, path, progress => {
        progressBar.style.width = `${progress}%`;
        uploadBtn.textContent = `${progress}%`;
    }).then(message => {
        resetUploadUI();
        customModal({
            title: 'Upload-Status',
            message: escHtml(message)
        });
        loadFiles();
        fileInput.value = "";
        window.droppedFile = null;
        const lbl = document.getElementById('selectedFileName');
        if (lbl) lbl.textContent = "Keine Datei ausgewaehlt oder hier ablegen";
    }).catch(err => {
        resetUploadUI();
        customModal({
            title: 'Fehler',
            message: escHtml(err.message || 'Fehler beim Hochladen.')
        });
    });
}

function uploadFileInChunks(file, path, onProgress) {
    const chunkSizes = [512 * 1024, 256 * 1024, 128 * 1024];

    const runWithChunkSize = (chunkSizeIndex) => {
        const chunkSize = chunkSizes[chunkSizeIndex];
        const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
        const uploadId = `up_${Date.now()}_${Math.random().toString(36).slice(2, 10)}_${chunkSize}`;

        return new Promise((resolve, reject) => {
            let chunkIndex = 0;

            const sendNextChunk = () => {
                if (chunkIndex >= totalChunks) {
                    resolve(`Datei erfolgreich hochgeladen: ${file.name}`);
                    return;
                }

                const start = chunkIndex * chunkSize;
                const end = Math.min(start + chunkSize, file.size);
                const chunk = file.slice(start, end);

                const formData = new FormData();
                formData.append('uploadFile', chunk, file.name);
                formData.append('path', path);
                formData.append('chunkIndex', String(chunkIndex));
                formData.append('totalChunks', String(totalChunks));
                formData.append('uploadId', uploadId);
                formData.append('originalName', file.name);
                formData.append('totalFileSize', String(file.size));

                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'upload.php', true);

                xhr.upload.onprogress = function (e) {
                    if (!e.lengthComputable) return;
                    const chunkFraction = e.total > 0 ? (e.loaded / e.total) : 0;
                    const totalProgress = ((chunkIndex + chunkFraction) / totalChunks) * 100;
                    onProgress(Math.max(1, Math.min(100, Math.round(totalProgress))));
                };

                xhr.onload = function () {
                    if (xhr.status === 413) {
                        reject({
                            code: 413,
                            message: xhr.responseText || 'Request Entity Too Large'
                        });
                        return;
                    }

                    if (xhr.status < 200 || xhr.status >= 300) {
                        reject({
                            code: xhr.status,
                            message: xhr.responseText || `Upload fehlgeschlagen (HTTP ${xhr.status}).`
                        });
                        return;
                    }

                    chunkIndex += 1;
                    onProgress(Math.max(1, Math.min(100, Math.round((chunkIndex / totalChunks) * 100))));
                    sendNextChunk();
                };

                xhr.onerror = function () {
                    reject({ code: 0, message: 'Netzwerkfehler beim Hochladen.' });
                };

                xhr.send(formData);
            };

            sendNextChunk();
        });
    };

    const tryAdaptive = (index) => {
        return runWithChunkSize(index).catch(err => {
            if (err && err.code === 413 && index < chunkSizes.length - 1) {
                return tryAdaptive(index + 1);
            }
            throw err;
        });
    };

    return tryAdaptive(0);
}
// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â  Monaco
if (typeof require !== "undefined") {
    require(["vs/editor/editor.main"], function() {
        editor = monaco.editor.create(document.getElementById("editor"), {
            value: "// Warten auf Datei...",
            language: "plaintext",
            theme: darkMode ? "vs-dark" : "vs-light",
            fontSize: 14,
            automaticLayout: true,
            scrollbar: {
                verticalScrollbarSize: 8,
                horizontalScrollbarSize: 8,
                verticalHasArrows: false,
                horizontalHasArrows: false,
                useShadows: false
            }
        });
        
        editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function() {
            saveFile();
        });
    });
}

// ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¦ Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");
    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");
    $("#uploadForm").on("submit", uploadFile);
    const dirInput = document.getElementById("directoryPath");
    if (dirInput) {
        dirInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                loadFiles();
            }
        });
    }

    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.style.border = '2px dashed var(--primary)';
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
            if (e.dataTransfer.files.length) {
                window.droppedFile = e.dataTransfer.files[0];
                const lbl = document.getElementById('selectedFileName');
                if (lbl) lbl.textContent = window.droppedFile.name;
                uploadFile(); // Auto-upload on drop
            }
        });
    }
});

// Search filter
function filterTable() {
    const term = document.getElementById('searchInput').value.toLowerCase();
    $('#fileTable tr').each(function() {
        const rowText = $(this).text().toLowerCase();
        $(this).toggle(rowText.indexOf(term) > -1);
    });
}
window.filterTable = filterTable;

// Global Ctrl-S handler
document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        const editModal = document.getElementById("editModal");
        if (editModal && !editModal.classList.contains("hidden")) {
            saveFile();
        }
    }
});

window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "text" ? "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¾ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â " : "ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â°ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¹Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¸ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â";
}
