let editor = null;
let darkModeVal = localStorage.getItem("darkMode");
let darkMode = darkModeVal === null ? true : (darkModeVal === "true");

// 🌙 Dark Mode
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    applyEditorTheme();
}
// Initialer Check – nur wenn body bereits existiert (script am Ende des body)
if (document.body) {
    if (darkMode) {
        document.body.classList.add("dark-mode");
    } else {
        document.body.classList.remove("dark-mode");
    }
}

// 🎨 Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    const ec = document.getElementById("editor-container");
    if (ec) ec.style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// 📂 Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "📂";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "🌐",
        htm: "🌐",
        php: "🐘",
        js: "📜",
        css: "🎨",
        txt: "📝",
        json: "🔢",
        pdf: "📑",
        ico: "📎",
        zip: "📦",
        rar: "📦",
        png: "🖼️",
        jpg: "🖼️",
        jpeg: "🖼️",
        mp4: "🎞️",
        mov: "🎞️"
    };
    return icons[ext] || "📄";
}

// 🔒 HTML escapen (XSS-Schutz)
function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

// 🖼️ Custom Modal
function customModal({
    title,
    message,
    type = 'alert',
    confirmText = 'OK',
    cancelText = 'Abbrechen',
    inputPlaceholder = '',
    defaultValue = ''
}) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay"></div>');
        const card = $('<div class="modal-card"></div>');
        const header = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close" title="Schließen">×</button>');
        header.append(closeBtn);
        closeBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        const body = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${defaultValue}">`);
            body.append(input);
        }

        const confirmBtn = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const cancelBtn = $(`<button class="btn btn-secondary">${cancelText}</button>`);


        confirmBtn.on('click', () => {
            let result = true;
            if (type === 'prompt') result = input.val();
            overlay.remove();
            resolve(result);
        });
        cancelBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        footer.append(cancelBtn).append(confirmBtn);
        if (type === 'alert') cancelBtn.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').append(overlay);
        if (input) input.focus();
    });
}

// 🔄 Dateien laden
function loadFiles() {
    const dirInput = document.getElementById("directoryPath");
    if (!dirInput) return;
    const dir = dirInput.value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            customModal({
                title: '❌ Fehler',
                message: escHtml(data.error)
            });
            return;
        }

        const table = $("#fileTable").empty();
        const files = data.files || [];
        const separator = dir.includes("\\") ? "\\" : "/";

        if (files.length === 0) {
            table.append(`
                <tr>
                    <td colspan="6" style="text-align:center; padding:60px 20px; color:var(--text-muted);">
                        <div style="font-size:48px; margin-bottom:16px;">📂</div>
                        <h3 style="margin:0 0 8px; color:var(--text);">Dieser Ordner ist leer</h3>
                        <p style="margin:0 0 24px; font-size:14px;">Lade eine Datei hoch oder erstelle einen neuen Ordner.</p>
                    </td>
                </tr>
            `);
            return;
        }

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = (dir === '.' ? '' : dir).replace(/[/\\]$/, "") + (dir === '.' ? '' : separator) + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";
            const isPrivate = !!file.isPrivate;
            const nameEsc = escHtml(file.name);
            const typeEsc = escHtml(file.type);
            const dateEsc = escHtml(file.date);
            // Schloss-Icon für private Elemente (nur Admin sieht es, da normale User private Elemente gar nicht sehen)
            const privBadge = (window.isSystemAdmin && isPrivate) ? ' <span title="Privat – nur Admins" style="font-size:12px; opacity:0.7;">🔒</span>' : '';

            let badgeText = isPrivate ? '🔒 Verborgen' : '🌍 Sichtbar';
            let badgeClass = isPrivate ? 'vis-private' : 'vis-public';
            if (file.isSystemBlocked) {
                badgeText = '🚫 Gesperrt';
                badgeClass = 'vis-system';
            }

            const sizeEsc = escHtml(file.sizeFormatted || '-');

            const row = $(`
                <tr data-type="${typeEsc}" data-name="${nameEsc}" data-path="${escHtml(fullPath)}">
                    <td style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:0;" title="${nameEsc}">${icon} ${nameEsc}</td>
                    <td>
                        <span class="vis-badge ${badgeClass}">
                            ${badgeText}
                        </span>
                    </td>
                    <td>${typeEsc}</td>
                    <td>${sizeEsc}</td>
                    <td>${dateEsc}</td>
                    <td>
                        <div class="action-btn-group">
                            <button class="btn btn-primary  btn-small js-open-folder" title="Öffnen"     style="display:${isFolder?'':'none'}">📂 Öffnen</button>
                            <button class="btn btn-warning  btn-small js-edit-file"   title="Bearbeiten" style="display:${isFolder?'none':''}">✏️ Edit</button>
                            <button class="btn btn-warning  btn-small js-rename"      title="Umbenennen">📄</button>
                            <button class="btn btn-danger   btn-small js-delete"      title="Löschen">🗑️</button>
                            <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-small" title="Herunterladen">⬇️</a>
                            ${window.isSystemAdmin ? `<button class="btn btn-secondary btn-small js-visibility" title="${isPrivate?'Privat – klicken um öffentlich zu setzen':'Öffentlich – klicken um privat zu setzen'}" style="opacity:${isPrivate?'1':'0.5'}; visibility:${file.isSystemBlocked ? 'hidden' : 'visible'};">${isPrivate?'🔒':'🌍'}</button>` : ''}
                        </div>
                    </td>
                </tr>`);

            row.find('.js-open-folder').on('click', () => openFolderByPath(encodeURIComponent(file.name)));
            row.find('.js-edit-file').on('click', () => editFile(file.name));
            row.find('.js-rename').on('click', () => renameFile(file.name));
            row.find('.js-delete').on('click', () => deleteFile(file.name));
            row.find('.js-visibility').on('click', () => showVisibility(fullPath, isFolder, isPrivate));

            table.append(row);
        });
    }).fail(jqXHR => customModal({
        title: '❌ Fehler',
        message: "Ladefehler: " + escHtml(jqXHR.responseText)
    }));
}

// 👁️ Sichtbarkeit verwalten
async function showVisibility(path, isFolder, currentlyPrivate) {
    if (!window.isSystemAdmin) return customModal({
        title: '🔐 Zugriff verweigert',
        message: 'Admin-Rechte erforderlich!'
    });

    const itemName = path.split('/').pop() || path.split('\\').pop() || path;

    if (currentlyPrivate) {
        // Aktuell PRIVAT → auf Öffentlich setzen
        let cascade = false;
        if (isFolder) {
            // Ordner: Abfrage mit Cascade-Option
            const overlay = $('<div class="modal-overlay"></div>');
            const card = $(`
                <div class="modal-card" style="max-width:420px;">
                    <div class="modal-header">🌍 Ordner öffentlich setzen
                        <button class="modal-close">×</button>
                    </div>
                    <div class="modal-body">
                        <p>Ordner <b>${escHtml(itemName)}</b> für alle angemeldeten Nutzer sichtbar machen?</p>
                        <div style="margin-top:15px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px;">
                                <input type="checkbox" id="vis-cascade" style="width:18px; height:18px; flex-shrink:0;">
                                <span>Auch alle Unterordner und Dateien öffentlich setzen (private Einzel-Einstellungen entfernen)</span>
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="vis-cancel">Abbrechen</button>
                        <button class="btn btn-success"   id="vis-confirm">🌍 Öffentlich setzen</button>
                    </div>
                </div>`);
            overlay.append(card);
            $('body').append(overlay);
            card.find('.modal-close, #vis-cancel').on('click', () => {
                overlay.remove();
                return;
            });
            card.find('#vis-confirm').on('click', () => {
                cascade = card.find('#vis-cascade').is(':checked');
                overlay.remove();
                doSetVisibility(path, 'public', cascade);
            });
            return;
        }
        // Einfache Datei
        const ok = await customModal({
            title: '🌍 Öffentlich setzen',
            message: `<b>${escHtml(itemName)}</b> für alle angemeldeten Nutzer sichtbar machen?`,
            type: 'confirm',
            confirmText: 'Öffentlich setzen'
        });
        if (ok) doSetVisibility(path, 'public', false);

    } else {
        // Aktuell ÖFFENTLICH → auf Privat setzen
        let msg = `<b>${escHtml(itemName)}</b> nur für Admins sichtbar machen?`;
        if (isFolder) msg += `<br><br><span style="font-size:12px; color:#94a3b8;">💡 Alle Unterordner und Dateien werden automatisch ausgeblendet – kein einzelnes Setzen nötig.</span>`;
        const ok = await customModal({
            title: '🔒 Privat setzen',
            message: msg,
            type: 'confirm',
            confirmText: 'Privat setzen'
        });
        if (ok) doSetVisibility(path, 'private', false);
    }
}

function doSetVisibility(path, status, cascade) {
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'set_visibility',
            path,
            status,
            cascade
        }),
        success: res => {
            if (res.error) customModal({
                title: '❌ Fehler',
                message: escHtml(res.error)
            });
            else {
                customModal({
                    title: '✅ Gespeichert',
                    message: escHtml(res.success)
                });
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: '❌ Fehler',
            message: 'Fehler: ' + escHtml(jqXHR.responseText)
        })
    });
}

// Ordner öffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    const sep = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + sep + name;
    loadFiles();
}

$(document).on("click", "#fileTable tr", function(e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").replace(/🔒\s*$/, "").trim();
    const type = $(this).attr("data-type");
    if (type === "folder" || type === "Ordner") openFolderByPath(name);
});

// ✏️ Datei bearbeiten
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({
            title: '❌ Fehler',
            message: escHtml(data.error)
        });
        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();
        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = {
                php: "php",
                js: "javascript",
                css: "css",
                html: "html",
                txt: "plaintext"
            };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => customModal({
        title: '❌ Fehler',
        message: "Fehler: " + escHtml(jqXHR.responseText)
    }));
}

// 💾 Datei speichern
async function saveFile() {
    if (!editor) return;
    const content = editor.getValue();
    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content
        }),
        success: response => {
            if (response.error) customModal({
                title: '❌ Fehler',
                message: escHtml(response.error)
            });
            else {
                customModal({
                    title: '✅ Gespeichert',
                    message: response.success || "Gespeichert."
                });
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: '❌ Fehler',
            message: "Fehler beim Speichern: " + escHtml(jqXHR.responseText)
        })
    });
}

// 📁 Modal
function openEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        overlay.classList.remove("hidden");
        $(overlay).fadeIn();
    }
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        $(overlay).fadeOut(() => overlay.classList.add("hidden"));
    }
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// 🗑️ Löschen (Server entscheidet über Berechtigung)
async function deleteFile(name) {
    const confirmed = await customModal({
        title: '🗑️ Löschen bestätigen',
        message: `"${escHtml(name)}" wirklich löschen?`,
        type: 'confirm',
        confirmText: 'Ja',
        cancelText: 'Nein'
    });
    if (!confirmed) return;
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) customModal({
            title: '❌ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: '✅ Gelöscht',
                message: response.success || "Gelöscht."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: '❌ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// 📄 Umbenennen (Server entscheidet über Berechtigung)
async function renameFile(oldName) {
    const newName = await customModal({
        title: '📄 Umbenennen',
        message: 'Neuer Name:',
        type: 'prompt',
        defaultValue: oldName
    });
    if (!newName || newName === oldName) return;
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName,
        newName
    }), response => {
        if (response.error) customModal({
            title: '❌ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: '✅ Umbenannt',
                message: response.success || "Umbenannt."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: '❌ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// ➕ Erstellen (Server entscheidet über Berechtigung)
async function createFile(isFolder = false) {
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return customModal({
        title: '⚠️ Eingabe erforderlich',
        message: "Bitte Namen eingeben!"
    });
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "create",
        path: dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        if (response.error) customModal({
            title: '❌ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: '✅ Erstellt',
                message: response.success || "Erstellt."
            });
            loadFiles();
            document.getElementById(inputId).value = "";
        }
    }, "json").fail(jqXHR => customModal({
        title: '❌ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

function createFolder() {
    createFile(true);
}

// ⬆️ Upload
function uploadFile(event) {
    if (event) event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;
    
    let fileToUpload = null;
    if (fileInput.files.length) {
        fileToUpload = fileInput.files[0];
    } else if (window.droppedFile) {
        fileToUpload = window.droppedFile;
    }

    if (!fileToUpload) {
        return customModal({
            title: '⚠️ Auswahl erforderlich',
            message: "Bitte wähle eine Datei aus."
        });
    }

    const formData = new FormData();
    formData.append('uploadFile', fileToUpload);
    formData.append('path', path);

    const progressContainer = document.getElementById("uploadProgressContainer");
    const progressBar = document.getElementById("uploadProgressBar");
    const uploadBtn = document.getElementById("uploadBtn");
    
    progressContainer.style.display = "block";
    progressBar.style.width = "0%";
    uploadBtn.disabled = true;
    uploadBtn.textContent = "⬆️ Lädt...";

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'upload.php', true);

    xhr.upload.onprogress = function(e) {
        if (e.lengthComputable) {
            const percentComplete = Math.round((e.loaded / e.total) * 100);
            progressBar.style.width = percentComplete + '%';
            uploadBtn.textContent = `⬆️ ${percentComplete}%`;
        }
    };

    xhr.onload = function() {
        progressContainer.style.display = "none";
        progressBar.style.width = "0%";
        uploadBtn.disabled = false;
        uploadBtn.textContent = "⬆️ Hochladen";

        if (xhr.status === 200) {
            customModal({
                title: '⬆️ Upload Status',
                message: escHtml(xhr.responseText)
            });
            loadFiles();
            fileInput.value = "";
            window.droppedFile = null;
            const lbl = document.getElementById('selectedFileName');
            if (lbl) lbl.textContent = "Keine Datei ausgewählt oder hier ablegen";
        } else {
            customModal({
                title: '❌ Fehler',
                message: escHtml(xhr.responseText || "Fehler beim Hochladen.")
            });
        }
    };

    xhr.onerror = function() {
        progressContainer.style.display = "none";
        progressBar.style.width = "0%";
        uploadBtn.disabled = false;
        uploadBtn.textContent = "⬆️ Hochladen";
        customModal({
            title: '❌ Fehler',
            message: "Netzwerkfehler beim Hochladen."
        });
    };

    xhr.send(formData);
}

// 🧠 Monaco
if (typeof require !== "undefined") {
    require(["vs/editor/editor.main"], function() {
        editor = monaco.editor.create(document.getElementById("editor"), {
            value: "// Warten auf Datei...",
            language: "plaintext",
            theme: darkMode ? "vs-dark" : "vs-light",
            fontSize: 14,
            automaticLayout: true,
            scrollbar: {
                verticalScrollbarSize: 8,
                horizontalScrollbarSize: 8,
                verticalHasArrows: false,
                horizontalHasArrows: false,
                useShadows: false
            }
        });
        
        editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function() {
            saveFile();
        });
    });
}

// 📦 Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");
    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");
    $("#uploadForm").on("submit", uploadFile);
    const dirInput = document.getElementById("directoryPath");
    if (dirInput) {
        dirInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                loadFiles();
            }
        });
    }

    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.style.border = '2px dashed var(--primary)';
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
            if (e.dataTransfer.files.length) {
                window.droppedFile = e.dataTransfer.files[0];
                const lbl = document.getElementById('selectedFileName');
                if (lbl) lbl.textContent = window.droppedFile.name;
                uploadFile(); // Auto-upload on drop
            }
        });
    }
});

// Search filter
function filterTable() {
    const term = document.getElementById('searchInput').value.toLowerCase();
    $('#fileTable tr').each(function() {
        const rowText = $(this).text().toLowerCase();
        $(this).toggle(rowText.indexOf(term) > -1);
    });
}
window.filterTable = filterTable;

window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "text" ? "🙈" : "👁️";
}