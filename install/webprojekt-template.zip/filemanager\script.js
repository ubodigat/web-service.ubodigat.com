﻿// ─────────────────────────────────────────────────────────────────────────────
// Web-Dateimanager – script.js  v3.0.0
// ─────────────────────────────────────────────────────────────────────────────

let editor = null;
// Dark-Mode: Standard = dunkel, wenn kein Eintrag vorhanden
let darkModeStored = localStorage.getItem("darkMode");
let darkMode = (darkModeStored === null) ? true : (darkModeStored === "true");

// Dark-Mode sofort anwenden (kein Flackern)
if (document.body) {
    document.body.classList.toggle("dark-mode", darkMode);
}

function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    if (editor) monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
}

// ── Hilfsfunktionen ───────────────────────────────────────────────────────────
function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function formatSize(bytes) {
    if (bytes === null || bytes === undefined || bytes === false) return '—';
    bytes = parseInt(bytes, 10);
    if (isNaN(bytes) || bytes < 0) return '—';
    if (bytes === 0) return '0 B';
    const units = ['B','KB','MB','GB','TB'];
    const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return (bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
}

function getFileIcon(name, type) {
    if (type === "folder") return "📂";
    const ext = (name.split('.').pop() || '').toLowerCase();
    return ({html:'🌐',htm:'🌐',php:'🐘',js:'📜',css:'🎨',txt:'📝',json:'🔢',pdf:'📑',
             zip:'📦',rar:'📦',png:'🖼️',jpg:'🖼️',jpeg:'🖼️',gif:'🖼️',webp:'🖼️',
             mp4:'🎞️',mov:'🎞️',mp3:'🎵',ico:'📎',svg:'🎨'})[ext] || '📄';
}

// ── Toast-Benachrichtigung (kurze Erfolgsmeldung) ─────────────────────────────
function showToast(msg, type = 'success') {
    const t = document.createElement('div');
    t.className = 'fm-toast fm-toast-' + type;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('fm-toast-show'), 10);
    setTimeout(() => { t.classList.remove('fm-toast-show'); setTimeout(() => t.remove(), 400); }, 2800);
}

// ── Custom Modal ──────────────────────────────────────────────────────────────
function customModal({ title, message, type = 'alert', confirmText = 'OK', cancelText = 'Abbrechen', inputPlaceholder = '', defaultValue = '' }) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay"></div>');
        const card    = $('<div class="modal-card"></div>');
        const header  = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close">×</button>');
        header.append(closeBtn);
        closeBtn.on('click', () => { overlay.remove(); resolve(null); });

        const body   = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${escHtml(defaultValue)}">`);
            body.append(input);
        }

        const ok  = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const can = $(`<button class="btn btn-secondary">${cancelText}</button>`);

        ok.on('click',  () => { overlay.remove(); resolve(type === 'prompt' ? input.val() : true); });
        can.on('click', () => { overlay.remove(); resolve(null); });

        footer.append(can).append(ok);
        if (type === 'alert') can.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').append(overlay);
        if (input) setTimeout(() => input.focus(), 50);
    });
}

// ── Dateien laden ─────────────────────────────────────────────────────────────
function loadFiles() {
    const dir = document.getElementById("directoryPath").value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) { customModal({ title: 'Fehler', message: escHtml(data.error) }); return; }

        const table = $("#fileTable").empty();
        const files = data.files || [];
        const sep   = dir.includes("\\") ? "\\" : "/";

        // Suchfeld zurücksetzen
        const searchVal = (document.getElementById('searchInput')?.value || '').toLowerCase();

        // ── Empty State ───────────────────────────────────────────────────────
        if (files.length === 0) {
            table.append(`<tr class="empty-state-row"><td colspan="6">
                <div class="empty-state">
                    <div class="empty-state-icon">📂</div>
                    <div class="empty-state-title">Dieser Ordner ist leer</div>
                    <div class="empty-state-hint">Erstelle eine Datei oder lade etwas hoch.</div>
                </div>
            </td></tr>`);
            return;
        }

        files.forEach(file => {
            const icon      = getFileIcon(file.name, file.type);
            const fullPath  = dir.replace(/[/\\]$/, "") + sep + file.name;
            const isFolder  = file.type === "folder";
            const isPrivate = !!file.isPrivate;
            const nameEsc   = escHtml(file.name);
            const sizeStr   = isFolder ? '—' : formatSize(file.size);

            const row = $(`<tr data-type="${escHtml(file.type)}" data-name="${nameEsc}" data-path="${escHtml(fullPath)}" data-search="${nameEsc.toLowerCase()}">
                <td class="col-name">${icon} ${nameEsc}</td>
                <td><span class="vis-badge ${isPrivate ? 'vis-private' : 'vis-public'}">${isPrivate ? '🔒 Privat' : '🌍 Sichtbar'}</span></td>
                <td>${escHtml(file.type)}</td>
                <td class="col-size">${escHtml(sizeStr)}</td>
                <td>${escHtml(file.date)}</td>
                <td>
                    <div class="action-btn-group">
                        <button class="btn btn-primary  btn-small js-open" title="Öffnen"     style="display:${isFolder?'':'none'}">📂 Öffnen</button>
                        <button class="btn btn-warning  btn-small js-edit" title="Bearbeiten" style="display:${isFolder?'none':''}">✏️ Edit</button>
                        <button class="btn btn-warning  btn-small js-rename icon-btn" title="Umbenennen">📄</button>
                        <button class="btn btn-danger   btn-small js-delete icon-btn" title="Löschen">🗑️</button>
                        ${window.isSystemAdmin ? `<button class="btn btn-secondary btn-small js-vis icon-btn" title="${isPrivate?'Öffentlich setzen':'Privat setzen'}" style="opacity:${isPrivate?'1':'0.5'};">${isPrivate?'🔒':'🌍'}</button>` : ''}
                        <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-small icon-btn" title="Herunterladen">⬇️</a>
                    </div>
                </td>
            </tr>`);

            row.find('.js-open').on('click',   () => openFolder(file.name));
            row.find('.js-edit').on('click',   () => editFile(file.name));
            row.find('.js-rename').on('click', () => renameFile(file.name));
            row.find('.js-delete').on('click', () => deleteFile(file.name));
            row.find('.js-vis').on('click',    () => showVisibility(fullPath, isFolder, isPrivate));

            table.append(row);
        });

        // Suchfilter direkt anwenden (nach Reload)
        if (searchVal) filterFilesInTable(searchVal);

    }).fail(xhr => customModal({ title: 'Fehler', message: escHtml(xhr.responseText || 'Ladefehler') }));
}

// ── Suchfilter ────────────────────────────────────────────────────────────────
function filterFiles(query) {
    filterFilesInTable(query.toLowerCase());
}

function filterFilesInTable(q) {
    let visible = 0;
    $('#fileTable tr[data-name]').each(function() {
        const name = $(this).attr('data-search') || '';
        const show = !q || name.includes(q);
        $(this).toggle(show);
        if (show) visible++;
    });

    // Kein Ergebnis-State
    $('#fileTable .no-result-row').remove();
    if (q && visible === 0 && $('#fileTable tr[data-name]').length > 0) {
        $('#fileTable').append(`<tr class="no-result-row"><td colspan="6" style="text-align:center;padding:30px;opacity:0.5;">Keine Dateien für „${escHtml(q)}" gefunden.</td></tr>`);
    }
}

// ── Ordner öffnen ─────────────────────────────────────────────────────────────
function openFolder(name) {
    const inp = document.getElementById("directoryPath");
    const sep = inp.value.includes("\\") ? "\\" : "/";
    inp.value = inp.value.replace(/[/\\]$/, "") + sep + name;
    document.getElementById('searchInput').value = '';
    loadFiles();
}

$(document).on("click", "#fileTable tr[data-name]", function(e) {
    if ($(e.target).closest("button,a").length) return;
    if ($(this).attr('data-type') === 'folder') openFolder($(this).attr('data-name'));
});

// ── Datei bearbeiten ──────────────────────────────────────────────────────────
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + sep + name;

    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({ title: 'Fehler', message: escHtml(data.error) });
        document.getElementById("editTitle").textContent = "Bearbeite: " + name;
        openEditModal();
        if (editor) {
            editor.setValue(data.content || "");
            const langMap = {php:"php",js:"javascript",css:"css",html:"html",htm:"html",txt:"plaintext",json:"json",md:"markdown"};
            const ext = name.split('.').pop().toLowerCase();
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 200);
        }
    }).fail(xhr => customModal({ title: 'Fehler', message: escHtml(xhr.responseText) }));
}

// ── Datei speichern (Button + Strg+S) ─────────────────────────────────────────
async function saveFile() {
    if (!editor) return;
    const content = editor.getValue();
    try {
        const res  = await fetch('api.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'save',path:currentEditingPath,content}) });
        const data = await res.json();
        if (data.error) {
            customModal({ title: 'Fehler', message: escHtml(data.error) });
        } else {
            showToast('Datei gespeichert');  // Strg+S Erfolgsmeldung als Toast
            loadFiles();
        }
    } catch(e) {
        customModal({ title: 'Fehler', message: 'Netzwerkfehler beim Speichern.' });
    }
}

// Strg+S / Cmd+S Tastenkombination
document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        const modal = document.getElementById('editModal');
        if (modal && modal.classList.contains('show')) {
            e.preventDefault();
            saveFile();
        }
    }
});

// ── Edit-Modal ────────────────────────────────────────────────────────────────
function openEditModal() {
    document.getElementById('editModalOverlay').style.display = 'block';
    const m = document.getElementById("editModal");
    m.classList.remove("hidden");
    m.classList.add("show");
    $(m).fadeIn(200);
}
function closeEditModal() {
    document.getElementById('editModalOverlay').style.display = 'none';
    const m = document.getElementById("editModal");
    m.classList.remove("show");
    $(m).fadeOut(200, () => m.classList.add("hidden"));
}

// ── Löschen ───────────────────────────────────────────────────────────────────
async function deleteFile(name) {
    const ok = await customModal({ title: 'Löschen', message: `"${escHtml(name)}" wirklich löschen?`, type:'confirm', confirmText:'Ja, löschen' });
    if (!ok) return;
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    const fp  = dir.replace(/[/\\]$/, "") + sep + name;
    const res = await fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',path:fp})});
    const d   = await res.json();
    if (d.error) customModal({ title: 'Fehler', message: escHtml(d.error) });
    else { showToast(name + ' gelöscht', 'info'); loadFiles(); }
}

// ── Umbenennen ────────────────────────────────────────────────────────────────
async function renameFile(oldName) {
    const newName = await customModal({ title: 'Umbenennen', message:'Neuer Name:', type:'prompt', defaultValue:oldName });
    if (!newName || newName === oldName) return;
    const dir = document.getElementById("directoryPath").value.trim();
    const res = await fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'rename',path:dir,oldName,newName})});
    const d   = await res.json();
    if (d.error) customModal({ title: 'Fehler', message: escHtml(d.error) });
    else { showToast('Umbenannt in ' + newName); loadFiles(); }
}

// ── Erstellen ─────────────────────────────────────────────────────────────────
async function createFile(isFolder = false) {
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name    = document.getElementById(inputId)?.value.trim();
    if (!name) return customModal({ title: 'Eingabe fehlt', message: "Bitte Namen eingeben!" });
    const dir = document.getElementById("directoryPath").value.trim();
    const res = await fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'create',path:dir,fileName:name,type:isFolder?'folder':'file'})});
    const d   = await res.json();
    if (d.error) customModal({ title: 'Fehler', message: escHtml(d.error) });
    else { showToast((isFolder?'Ordner':'Datei') + ' erstellt'); loadFiles(); document.getElementById(inputId).value = ""; }
}
function createFolder() { createFile(true); }

// ── Upload mit Drag & Drop und Fortschrittsanzeige ────────────────────────────
function doUpload(files) {
    if (!files || !files.length) return;
    const path = document.getElementById("directoryPath").value;
    let idx = 0;

    function uploadNext() {
        if (idx >= files.length) {
            setTimeout(() => {
                document.getElementById('upload-progress-wrap').style.display = 'none';
                document.getElementById('selectedFileName').textContent = 'Keine Datei ausgewaehlt';
            }, 800);
            loadFiles();
            return;
        }
        const file = files[idx++];
        const formData = new FormData();
        formData.append('uploadFile', file);
        formData.append('path', path);

        document.getElementById('upload-progress-wrap').style.display = 'block';
        document.getElementById('selectedFileName').textContent = `Lade hoch: ${file.name} (${idx}/${files.length})`;

        const xhr = new XMLHttpRequest();
        xhr.upload.onprogress = e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 100);
                document.getElementById('upload-progress-bar').style.width = pct + '%';
                document.getElementById('upload-progress-label').textContent = pct + ' %';
            }
        };
        xhr.onload = () => {
            const resp = xhr.responseText || '';
            if (xhr.status !== 200) {
                customModal({ title: 'Upload-Fehler', message: escHtml(resp) });
            } else {
                showToast(file.name + ' hochgeladen');
            }
            document.getElementById('upload-progress-bar').style.width = '0%';
            uploadNext();
        };
        xhr.onerror = () => {
            customModal({ title: 'Fehler', message: 'Netzwerkfehler beim Upload.' });
            uploadNext();
        };
        xhr.open('POST', 'upload.php');
        xhr.send(formData);
    }
    uploadNext();
}

function uploadFile(event) {
    event.preventDefault();
    const fi = document.getElementById("uploadFile");
    if (!fi.files.length) return customModal({ title: 'Kein File', message: 'Bitte zuerst eine Datei auswählen.' });
    doUpload(fi.files);
    fi.value = "";
}

// Drag & Drop
$(function() {
    const zone = document.getElementById('uploadDropZone');
    if (!zone) return;
    let dragCounter = 0;

    zone.addEventListener('dragenter', e => { e.preventDefault(); dragCounter++; zone.classList.add('drag-over'); });
    zone.addEventListener('dragleave', () => { dragCounter--; if (dragCounter <= 0) { dragCounter=0; zone.classList.remove('drag-over'); } });
    zone.addEventListener('dragover',  e => e.preventDefault());
    zone.addEventListener('drop', e => {
        e.preventDefault();
        dragCounter = 0;
        zone.classList.remove('drag-over');
        const files = e.dataTransfer.files;
        if (files.length) {
            const lbl = document.getElementById('selectedFileName');
            lbl.textContent = files.length === 1 ? files[0].name : files.length + ' Dateien';
            doUpload(files);
        }
    });
});

// ── Sichtbarkeit ──────────────────────────────────────────────────────────────
async function showVisibility(path, isFolder, currentlyPrivate) {
    const itemName = path.split('/').pop() || path;

    if (currentlyPrivate) {
        if (isFolder) {
            const overlay = $('<div class="modal-overlay"></div>');
            const card = $(`<div class="modal-card" style="max-width:400px;">
                <div class="modal-header">Ordner öffentlich setzen <button class="modal-close">×</button></div>
                <div class="modal-body">
                    <p><b>${escHtml(itemName)}</b> für alle sichtbar machen?</p>
                    <div style="margin-top:12px;padding:12px;background:rgba(255,255,255,0.05);border-radius:8px;">
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:13px;">
                            <input type="checkbox" id="vis-cascade" style="width:18px;height:18px;">
                            <span>Auch alle Unterordner/Dateien öffentlich setzen</span>
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" id="vis-cancel">Abbrechen</button>
                    <button class="btn btn-success" id="vis-ok">Öffentlich setzen</button>
                </div>
            </div>`);
            overlay.append(card); $('body').append(overlay);
            card.find('.modal-close,#vis-cancel').on('click', () => overlay.remove());
            card.find('#vis-ok').on('click', () => {
                const cascade = card.find('#vis-cascade').is(':checked');
                overlay.remove();
                doSetVisibility(path, 'public', cascade);
            });
            return;
        }
        const ok = await customModal({ title:'Öffentlich setzen', message:`<b>${escHtml(itemName)}</b> für alle sichtbar?`, type:'confirm', confirmText:'Öffentlich setzen' });
        if (ok) doSetVisibility(path, 'public', false);
    } else {
        let msg = `<b>${escHtml(itemName)}</b> nur für Admins sichtbar machen?`;
        if (isFolder) msg += '<br><br><small style="opacity:.6">Unterelemente werden automatisch ausgeblendet.</small>';
        const ok = await customModal({ title:'Privat setzen', message:msg, type:'confirm', confirmText:'Privat setzen' });
        if (ok) doSetVisibility(path, 'private', false);
    }
}

function doSetVisibility(path, status, cascade) {
    fetch('api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set_visibility',path,status,cascade})})
        .then(r=>r.json())
        .then(d => {
            if (d.error) customModal({title:'Fehler', message: escHtml(d.error)});
            else { showToast(d.success || 'Sichtbarkeit gesetzt'); loadFiles(); }
        });
}

// ── Monaco Editor ─────────────────────────────────────────────────────────────
if (typeof require !== 'undefined') {
    require(["vs/editor/editor.main"], function() {
        const el = document.getElementById("editor");
        if (!el) return;
        editor = monaco.editor.create(el, {
            value: "// Wähle eine Datei zum Bearbeiten aus...",
            language: "plaintext",
            theme: darkMode ? "vs-dark" : "vs-light",
            fontSize: 14,
            automaticLayout: true,
            minimap: { enabled: false }
        });
    });
}

// ── Init ──────────────────────────────────────────────────────────────────────
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");
    loadFiles();
    document.body.classList.toggle("dark-mode", darkMode);

    $("#uploadForm").on("submit", uploadFile);

    const dirInput = document.getElementById("directoryPath");
    if (dirInput) {
        dirInput.addEventListener("keydown", e => { if (e.key==="Enter") { e.preventDefault(); loadFiles(); } });
        // Normalnutzer dürfen Basispfad nicht verlassen
        if (!window.isSystemAdmin && window.basePath) {
            dirInput.addEventListener("input", () => {
                if (!dirInput.value.startsWith(window.basePath)) dirInput.value = window.basePath;
            });
        }
    }
});

// Globale Exports
window.toggleDarkMode = toggleDarkMode;
window.createFile     = createFile;
window.createFolder   = createFolder;
window.editFile       = editFile;
window.saveFile       = saveFile;
window.deleteFile     = deleteFile;
window.renameFile     = renameFile;
window.uploadFile     = uploadFile;
window.closeEditModal = closeEditModal;
window.loadFiles      = loadFiles;
window.filterFiles    = filterFiles;

// Passwort-Toggle (Login-Seiten)
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "text" ? "🙈" : "👁️";
}
window.togglePassword = togglePassword;