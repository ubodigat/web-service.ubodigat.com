<?php
declare(strict_types=1);

/* =========================================================
   🎨 ZENTRALE FEHLERSEITE (Darkmode)
   ========================================================= */
function showError(string $title, string $message): void
{
    http_response_code(500);
    $logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Fehler – Installation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="/filemanager/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="/filemanager/favicon.ico" />
<style>
:root{
    --bg1:#0f172a; --bg2:#020617;
    --card:#0b1220; --border:#22304a;
    --text:#e5e7eb; --muted:#cbd5f5;
    --danger:#f87171; --ok1:#22c55e; --ok2:#4ade80;
    --link:#38bdf8;
}
*{box-sizing:border-box}
body{
    margin:0;
    background:radial-gradient(circle at top,var(--bg1),var(--bg2));
    color:var(--text);
    font-family:system-ui,-apple-system,BlinkMacSystemFont,sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:24px;
}
.card{
    background:rgba(11,18,32,.92);
    border:1px solid rgba(34,48,74,.7);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    width:100%;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7);
    backdrop-filter: blur(10px);
}
.logo{width:160px;margin-bottom:22px}
h2{margin:0 0 12px;color:var(--danger);font-size:22px}
p{color:var(--muted);line-height:1.6;margin:0}
.code{
    margin-top:18px;
    padding:12px 14px;
    border-radius:12px;
    background:#020617;
    border:1px solid var(--border);
    color:var(--muted);
    text-align:left;
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    white-space: pre-wrap;
}
a{color:var(--link);text-decoration:none;font-weight:600}
</style>
</head>
<body>
<div class="card">
    <img src="{$logo}" class="logo" alt="ubodigat">
    <h2>❌ {$title}</h2>
    <p>{$message}</p>
</div>
</body>
</html>
HTML;
    exit;
}

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    showError(
        'Installation bereits abgeschlossen',
        'Dieses Setup wurde bereits ausgeführt und ist aus Sicherheitsgründen gesperrt.'
    );
}

/* =========================================================
   🔑 DB-DATEN (Installer oder Formular)
   ========================================================= */
$envFile   = __DIR__ . '/.db.env';
$dbFromEnv = false;

$dbHost = 'localhost';
$dbUser = '';
$dbPass = '';
$dbName = '';

if (file_exists($envFile)) {
    $env = parse_ini_file($envFile);
    $dbHost = $env['DB_HOST'] ?? 'localhost';
    $dbUser = $env['DB_USER'] ?? '';
    $dbPass = $env['DB_PASS'] ?? '';
    $dbName = $env['DB_NAME'] ?? '';
    $dbFromEnv = ($dbUser !== '' && $dbName !== '');
}

/* =========================================================
   🔐 SECURITY-CONFIG FILE (wird vom Setup geschrieben)
   ========================================================= */
$securityDir  = realpath(__DIR__ . '/..') . '/config';
$securityFile = $securityDir . '/security.php';

/* =========================================================
   📩 FORMULARVERARBEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. Neue Felder: Web Access, Filemanager, Timeout
    $webAccessEnabled = ($_POST['web_access_enabled'] ?? '0') === '1';
    $webAccessPass    = $_POST['web_access_pass'] ?? '';

    $filemanagerPass  = $_POST['filemanager_pass'] ?? '';
    $timeoutRaw       = $_POST['filemanager_timeout'] ?? '1800';

    // 2. Alte Felder: Admin & DB
    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';

    $dbHostPost = trim($_POST['db_host'] ?? 'localhost');
    $dbUserPost = trim($_POST['db_user'] ?? '');
    $dbPassPost = $_POST['db_pass'] ?? '';
    $dbNamePost = trim($_POST['db_name'] ?? '');

    $useDbHost = $dbFromEnv ? $dbHost : $dbHostPost;
    $useDbUser = $dbFromEnv ? $dbUser : $dbUserPost;
    $useDbPass = $dbFromEnv ? $dbPass : $dbPassPost;
    $useDbName = $dbFromEnv ? $dbName : $dbNamePost;

    // 3. Validierung
    if ($adminUser === '' || $adminPass === '') {
        showError('Pflichtfelder fehlen', 'Bitte Admin-Benutzername und Admin-Passwort ausfüllen.');
    }
    if ($filemanagerPass === '') {
        showError('Pflichtfelder fehlen', 'Bitte ein Passwort für den Dateimanager vergeben.');
    }
    if ($webAccessEnabled && $webAccessPass === '') {
        showError('Pflichtfelder fehlen', 'Webseiten-Zugriff ist aktiviert – bitte ein Webseiten-Passwort vergeben.');
    }
    if ($useDbUser === '' || $useDbName === '') {
        showError('Datenbankdaten fehlen', 'DB-Benutzer und DB-Name sind erforderlich (entweder aus .db.env oder im Formular).');
    }

    // Timeout berechnen (KORRIGIERT: Variable gefixt)
    $timeout = (int)$timeoutRaw;
    if ($timeout < 0) $timeout = 1800; 

    // Hashes erstellen
    $adminHash       = password_hash($adminPass, PASSWORD_BCRYPT);
    $filemanagerHash = password_hash($filemanagerPass, PASSWORD_BCRYPT);
    $webAccessHash   = $webAccessEnabled ? password_hash($webAccessPass, PASSWORD_BCRYPT) : '';

    // 4. DB Verbindung & Erstellung
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli($useDbHost, $useDbUser, $useDbPass);
        $db->set_charset('utf8mb4');
    } catch (mysqli_sql_exception) {
        showError(
            'Datenbankverbindung fehlgeschlagen',
            'Die Verbindung zur Datenbank konnte nicht hergestellt werden.<br>Prüfe Benutzername, Passwort und Host.'
        );
    }

    try {
        if (!$dbFromEnv) {
            $db->query(
                "CREATE DATABASE IF NOT EXISTS `$useDbName`
                CHARACTER SET utf8mb4
                COLLATE utf8mb4_general_ci"
            );
        }
        $db->select_db($useDbName);
    } catch (mysqli_sql_exception) {
        showError(
            'Datenbankzugriff fehlgeschlagen',
            'Die Datenbank konnte nicht ausgewählt werden. Prüfe Benutzerrechte.'
        );
    }

    // 5. SQL Import
    $sqlFile = __DIR__ . '/../sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        showError(
            'SQL-Struktur fehlt',
            'Die Datei <code>sql/struktur.sql</code> wurde nicht gefunden.'
        );
    }

    $sql = file_get_contents($sqlFile);
    try {
        $db->multi_query($sql);
        while ($db->more_results()) {
            $db->next_result();
        }
    } catch (mysqli_sql_exception) {
        showError(
            'SQL-Import fehlgeschlagen',
            'Beim Import der Datenbankstruktur ist ein Fehler aufgetreten.<br>Prüfe <code>struktur.sql</code>.'
        );
    }

    // 6. Benutzer Tabelle & Admin
    try {
        $db->query("
            CREATE TABLE IF NOT EXISTS benutzer (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nutzername VARCHAR(255) UNIQUE NOT NULL,
                passwort VARCHAR(255) NOT NULL,
                erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB
        ");
    } catch (mysqli_sql_exception) {
        showError(
            'Tabelle konnte nicht erstellt werden',
            'Die Benutzer-Tabelle konnte nicht erstellt werden. Prüfe DB-Rechte.'
        );
    }

    try {
        // KORRIGIERT: INSERT IGNORE um Fehler bei doppeltem Ausführen zu vermeiden
        $stmt = $db->prepare("INSERT IGNORE INTO benutzer (nutzername, passwort) VALUES (?, ?)");
        $stmt->bind_param('ss', $adminUser, $adminHash);
        $stmt->execute();
    } catch (mysqli_sql_exception) {
        showError(
            'Admin konnte nicht angelegt werden',
            'Der Admin-User konnte nicht eingefügt werden.'
        );
    }

    // 7. Config Dateien schreiben (DB)
    $config = "<?php\n"
        . "\$db_host = '" . addslashes($useDbHost) . "';\n"
        . "\$db_user = '" . addslashes($useDbUser) . "';\n"
        . "\$db_pass = '" . addslashes($useDbPass) . "';\n"
        . "\$db_name = '" . addslashes($useDbName) . "';\n";

    $pathProj = __DIR__ . '/../projekt/config.php';
    $pathFm   = __DIR__ . '/../filemanager/config.php';

    @file_put_contents($pathProj, $config, LOCK_EX);
    @chmod($pathProj, 0640); // KORRIGIERT: Rechte setzen

    @file_put_contents($pathFm, $config, LOCK_EX);
    @chmod($pathFm, 0640); // KORRIGIERT: Rechte setzen

    // 8. SECURITY CONFIG SCHREIBEN
    if (!is_dir($securityDir)) {
        @mkdir($securityDir, 0755, true);
    }

    // KORRIGIERT: ADMIN_ACCESS_HASH entfernt (da Admin über DB läuft)
    $security = "<?php\n"
        . "declare(strict_types=1);\n\n"
        . "define('WEB_ACCESS_ENABLED', " . ($webAccessEnabled ? 'true' : 'false') . ");\n"
        . "define('WEB_ACCESS_HASH', '" . addslashes($webAccessHash) . "');\n\n"
        . "define('FILEMANAGER_ACCESS_HASH', '" . addslashes($filemanagerHash) . "');\n"
        . "define('FILEMANAGER_TIMEOUT', " . $timeout . ");\n";

    if (@file_put_contents($securityFile, $security, LOCK_EX) === false) {
        showError(
            'Konnte security.php nicht schreiben',
            'Bitte prüfe Dateirechte: <code>config/</code> muss schreibbar sein.'
        );
    }
    @chmod($securityFile, 0640); // KORRIGIERT: Rechte setzen

    // 9. Abschluss
    file_put_contents($lockFile, date('c'), LOCK_EX);
    @unlink($envFile);
    @unlink(__FILE__);

    $logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Installation abgeschlossen</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:24px;
}
.card{
    background:rgba(11,18,32,.92);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7);
    border:1px solid rgba(34,48,74,.7);
    backdrop-filter: blur(10px);
}
a{
    display:block;
    margin-top:14px;
    color:#38bdf8;
    text-decoration:none;
    font-weight:600
}
.note{
    margin-top:18px;
    color:#f87171;
    font-weight:600;
}
</style>
</head>
<body>
<div class="card">
<img src="{$logo}" width="160" alt="ubodigat"><br><br>
<h2>✅ Einrichtung abgeschlossen</h2>
<p>Das System ist jetzt vollständig einsatzbereit.</p>
<a href="/filemanager/">➡ Dateimanager öffnen</a>
<a href="/projekt/">➡ Projektseite öffnen</a>
<p class="note">🔒 Die Datei <code>setup.php</code> wurde gelöscht und die Installation gesperrt.</p>
</div>
</body>
</html>
HTML;
    exit;
}

// URL/Host Helper
$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
$serverIp = $_SERVER['SERVER_ADDR'] ?? '';
$hostHint = $_SERVER['HTTP_HOST'] ?? '';
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Einrichtung – Webprojekt + Datenbank</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
:root{
    --bg1:#0f172a; --bg2:#020617;
    --card:#0b1220; --border:#22304a;
    --text:#e5e7eb; --muted:#94a3b8;
    --input:#020617; --focus:#38bdf8;
    --ok1:#22c55e; --ok2:#4ade80;
}
*{box-sizing:border-box}
body{
    margin:0;
    background:radial-gradient(circle at top,var(--bg1),var(--bg2));
    color:var(--text);
    font-family:system-ui,-apple-system,BlinkMacSystemFont,sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:24px;
}
form{
    width:100%;
    background:rgba(11,18,32,.92);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    box-shadow:0 30px 80px rgba(0,0,0,.7);
    border:1px solid rgba(34,48,74,.7);
    backdrop-filter: blur(10px);
}
img{display:block;margin:0 auto 18px;width:160px}
h2{margin:0;text-align:center}
.sub{margin:10px 0 26px;text-align:center;color:var(--muted);line-height:1.5}
fieldset{
    border:1px solid rgba(34,48,74,.55);
    border-radius:14px;
    padding:18px 16px;
    margin:18px 0;
}
legend{
    padding:0 10px;
    color:#cbd5f5;
    font-weight:700;
}
label{display:block;margin-top:14px;font-size:14px}
small{display:block;margin-top:6px;color:var(--muted);line-height:1.45}
input,select{
    width:100%;
    margin-top:8px;
    padding:12px 12px;
    background:var(--input);
    color:var(--text);
    border:1px solid rgba(51,65,85,.9);
    border-radius:10px;
}
input:focus,select:focus{outline:none;border-color:var(--focus)}
button{
    width:100%;
    margin-top:18px;
    padding:14px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,var(--ok1),var(--ok2));
    color:#022c22;
    font-size:16px;
    font-weight:800;
    cursor:pointer;
}
.hint{
    margin-top:14px;
    color:var(--muted);
    font-size:13px;
    text-align:center;
}
code{
    background:#020617;
    border:1px solid rgba(34,48,74,.7);
    padding:2px 6px;
    border-radius:8px;
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.grid{
    display:grid;
    gap:14px;
}
@media (min-width: 600px){
    .grid.two{grid-template-columns:1fr 1fr}
}
.badge{
    display:inline-block;
    padding:6px 10px;
    border-radius:999px;
    font-size:12px;
    background:rgba(56,189,248,.12);
    border:1px solid rgba(56,189,248,.25);
    color:#cbd5f5;
}
</style>
</head>

<body>
<form method="post">
<img src="<?= htmlspecialchars($logo) ?>" alt="ubodigat">

<h2>🔧 Einrichtung – Webprojekt</h2>
<p class="sub">
    Hier legst du Zugänge, Timeout und Datenbank fest.<br>
    <?= $hostHint ? '<span class="badge">Host: ' . htmlspecialchars($hostHint) . '</span>' : '' ?>
    <?= $serverIp ? ' <span class="badge">Server-IP: ' . htmlspecialchars($serverIp) . '</span>' : '' ?>
</p>

<fieldset>
    <legend>🔐 Zugriffsschutz (Webseite)</legend>

    <label>Allgemeinen Webseiten-Zugriff aktivieren?
        <select name="web_access_enabled">
            <option value="0" selected>Nein – Webseite ist direkt erreichbar</option>
            <option value="1">Ja – Passwort erforderlich</option>
        </select>
        <small>
            Wenn aktiviert, wird vor der öffentlichen Webseite ein Passwort-Login vorgeschaltet.
        </small>
    </label>

    <label>Webseiten-Passwort (nur wenn aktiviert)
        <input type="password" name="web_access_pass" placeholder="z. B. ein starkes Passwort">
        <small>
            Dieses Passwort schützt den generellen Zugriff auf die Webseite.
        </small>
    </label>
</fieldset>

<fieldset>
    <legend>📂 Dateimanager</legend>

    <label>Dateimanager-Passwort
        <input type="password" name="filemanager_pass" required placeholder="Passwort für den Dateimanager">
        <small>
            Schützt den Login zum Dateimanager. Wird sicher verschlüsselt.
        </small>
    </label>

    <label>Timeout für Dateimanager-Sitzung
        <select name="filemanager_timeout">
            <option value="900">15 Minuten (Sicher)</option>
            <option value="1800" selected>30 Minuten (Standard)</option>
            <option value="3600">60 Minuten (Lang)</option>
            <option value="0">Kein Timeout (Nicht empfohlen)</option>
        </select>
        <small>
            Nach dieser Zeit wird der Benutzer automatisch ausgeloggt.
        </small>
    </label>
</fieldset>

<fieldset>
    <legend>👑 Admin (Datenbank)</legend>

    <div class="grid two">
        <label>Admin-Benutzername
            <input name="admin_user" required placeholder="z. B. admin">
            <small>Wird in Tabelle <code>benutzer</code> angelegt.</small>
        </label>

        <label>Admin-Passwort
            <input type="password" name="admin_pass" required placeholder="starkes Passwort">
            <small>Login für Admin-Bereiche in der Datenbank.</small>
        </label>
    </div>
</fieldset>

<fieldset>
    <legend>🗃️ Datenbank-Verbindung</legend>

    <?php if ($dbFromEnv): ?>
        <p class="sub" style="margin:0 0 6px;text-align:left">
            ✅ Datenbankdaten wurden aus <code>install/.db.env</code> übernommen.
        </p>
        <p class="hint" style="text-align:left;margin:0">
            Host: <code><?= htmlspecialchars($dbHost) ?></code> •
            User: <code><?= htmlspecialchars($dbUser) ?></code> •
            DB: <code><?= htmlspecialchars($dbName) ?></code>
        </p>
    <?php else: ?>
        <label>Datenbank-Host
            <input name="db_host" value="localhost">
            <small>Meistens <code>localhost</code>.</small>
        </label>

        <label>Datenbank-Benutzer
            <input name="db_user" required placeholder="z. B. root oder DB-User">
            <small>Benutzer mit Rechten zum Erstellen von Tabellen.</small>
        </label>

        <label>Datenbank-Passwort
            <input type="password" name="db_pass" placeholder="falls vorhanden">
            <small>Passwort des DB-Benutzers.</small>
        </label>

        <label>Datenbank-Name
            <input name="db_name" required placeholder="z. B. webprojekt">
            <small>Wird automatisch erstellt, falls nicht vorhanden.</small>
        </label>
    <?php endif; ?>
</fieldset>

<button>✅ Einrichtung starten</button>

<p class="hint">
    Nach erfolgreichem Setup wird <code>setup.php</code> automatisch gelöscht.
</p>
</form>
</body>
</html>