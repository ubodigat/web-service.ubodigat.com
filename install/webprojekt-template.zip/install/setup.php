<?php
declare(strict_types=1);

/* =========================================================
   🎨 ZENTRALE FEHLERSEITE (Darkmode)
   ========================================================= */
function showError(string $title, string $message): void
{
    http_response_code(500);
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Fehler – Installation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh
}
.card{
    background:#0b1220;
    padding:40px;
    border-radius:18px;
    max-width:520px;
    width:100%;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7)
}
.logo{
    width:160px;
    margin-bottom:25px
}
h2{
    margin:0 0 10px;
    color:#f87171
}
p{
    color:#cbd5f5;
    line-height:1.5
}
</style>
</head>
<body>
<div class="card">
    <img src="https://web-service.ubodigat.com/ubodigatlogo.svg" class="logo">
    <h2>❌ {$title}</h2>
    <p>{$message}</p>
</div>
</body>
</html>
HTML;
    exit;
}

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    showError(
        'Installation bereits abgeschlossen',
        'Dieses Setup wurde bereits ausgeführt und ist gesperrt.'
    );
}

/* =========================================================
   🔑 DB-DATEN (aus Installer oder Formular)
   ========================================================= */
$envFile = __DIR__ . '/.db.env';

$dbFromEnv = false;
if (file_exists($envFile)) {
    $env = parse_ini_file($envFile);
    $dbHost = $env['DB_HOST'] ?? 'localhost';
    $dbUser = $env['DB_USER'] ?? '';
    $dbPass = $env['DB_PASS'] ?? '';
    $dbName = $env['DB_NAME'] ?? '';
    $dbFromEnv = true;
}

/* =========================================================
   📩 FORMULARVERARBEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';

    $dbHost = $dbFromEnv ? $dbHost : trim($_POST['db_host'] ?? 'localhost');
    $dbUser = $dbFromEnv ? $dbUser : trim($_POST['db_user'] ?? '');
    $dbPass = $dbFromEnv ? $dbPass : ($_POST['db_pass'] ?? '');
    $dbName = $dbFromEnv ? $dbName : trim($_POST['db_name'] ?? '');

    if ($adminUser === '' || $adminPass === '' || $dbUser === '' || $dbName === '') {
        showError(
            'Pflichtfelder fehlen',
            'Bitte fülle alle erforderlichen Felder vollständig aus.'
        );
    }

    $adminHash = password_hash($adminPass, PASSWORD_BCRYPT);

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli($dbHost, $dbUser, $dbPass);
        $db->set_charset('utf8mb4');
    } catch (mysqli_sql_exception) {
        showError(
            'Datenbankverbindung fehlgeschlagen',
            'Die Verbindung zur Datenbank konnte nicht hergestellt werden.<br>
             Prüfe Benutzername, Passwort und Host.'
        );
    }

    try {
        $db->query(
            "CREATE DATABASE IF NOT EXISTS `$dbName`
             CHARACTER SET utf8mb4
             COLLATE utf8mb4_general_ci"
        );
        $db->select_db($dbName);
    } catch (mysqli_sql_exception) {
        showError(
            'Datenbank konnte nicht erstellt werden',
            'Der angegebene Datenbankbenutzer hat nicht genügend Rechte.'
        );
    }

    $sqlFile = __DIR__ . '/../sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        showError(
            'SQL-Struktur fehlt',
            'Die Datei <code>sql/struktur.sql</code> wurde nicht gefunden.'
        );
    }

    $sql = file_get_contents($sqlFile);
    $db->multi_query($sql);
    while ($db->more_results()) {
        $db->next_result();
    }

    $db->query("
        CREATE TABLE IF NOT EXISTS benutzer (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nutzername VARCHAR(255) UNIQUE NOT NULL,
            passwort VARCHAR(255) NOT NULL,
            erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    $stmt = $db->prepare(
        "INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)"
    );
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    $config = "<?php\n"
        . "\$db_host = '$dbHost';\n"
        . "\$db_user = '$dbUser';\n"
        . "\$db_pass = '$dbPass';\n"
        . "\$db_name = '$dbName';\n";

    file_put_contents(__DIR__ . '/../projekt/config.php', $config, LOCK_EX);
    file_put_contents(__DIR__ . '/../filemanager/config.php', $config, LOCK_EX);

    file_put_contents($lockFile, date('c'), LOCK_EX);
    @unlink($envFile);
    @unlink(__FILE__);

    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Installation abgeschlossen</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh
}
.card{
    background:#0b1220;
    padding:40px;
    border-radius:18px;
    max-width:520px;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7)
}
a{
    display:block;
    margin-top:15px;
    color:#38bdf8;
    text-decoration:none;
    font-weight:600
}
</style>
</head>
<body>
<div class="card">
<img src="https://web-service.ubodigat.com/ubodigatlogo.svg" width="160"><br><br>
<h2>✅ Einrichtung abgeschlossen</h2>
<p>Das System ist jetzt vollständig einsatzbereit.</p>
<a href="/filemanager/">➡ Dateimanager öffnen</a>
<a href="/projekt/">➡ Projektseite öffnen</a>
<p style="margin-top:20px;color:#f87171">
🔒 Bitte lösche nun den Ordner <code>/install</code>.
</p>
</div>
</body>
</html>
HTML;
    exit;
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Einrichtung – Webprojekt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh
}
form{
    background:#0b1220;
    padding:40px;
    border-radius:18px;
    max-width:520px;
    width:100%;
    box-shadow:0 30px 80px rgba(0,0,0,.7)
}
img{
    display:block;
    margin:0 auto 20px;
    width:160px
}
label{
    display:block;
    margin-top:18px;
    font-size:14px
}
small{
    display:block;
    margin-top:4px;
    color:#94a3b8
}
input{
    width:100%;
    margin-top:6px;
    padding:12px;
    background:#020617;
    color:#e5e7eb;
    border:1px solid #334155;
    border-radius:10px
}
button{
    width:100%;
    margin-top:30px;
    padding:14px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,#22c55e,#4ade80);
    color:#022c22;
    font-size:16px;
    font-weight:700;
    cursor:pointer
}
</style>
</head>

<body>
<form method="post">
<img src="https://web-service.ubodigat.com/ubodigatlogo.svg">

<h2 style="text-align:center">🔧 Einrichtung – Webprojekt</h2>

<label>Admin-Benutzername
<small>Hauptadministrator für Dateimanager & System</small>
<input name="admin_user" required>
</label>

<label>Admin-Passwort
<small>Wird sicher verschlüsselt gespeichert</small>
<input type="password" name="admin_pass" required>
</label>

<?php if (!$dbFromEnv): ?>
<label>Datenbank-Host
<small>In der Regel <code>localhost</code></small>
<input name="db_host" value="localhost">
</label>

<label>Datenbank-Benutzer
<small>MariaDB Benutzer mit ausreichenden Rechten</small>
<input name="db_user" required>
</label>

<label>Datenbank-Passwort
<small>Passwort des DB-Benutzers</small>
<input type="password" name="db_pass">
</label>

<label>Datenbank-Name
<small>Wird automatisch angelegt</small>
<input name="db_name" required>
</label>
<?php endif; ?>

<button>✅ Einrichtung starten</button>
</form>
</body>
</html>