<?php
declare(strict_types=1);

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    http_response_code(403);
    exit('<h2 style="color:red;text-align:center">❌ Setup bereits abgeschlossen</h2>');
}

/* =========================================================
   📩 FORMULARVERARBEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 🔐 Eingaben sicher lesen
    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';
    $dbHost    = trim($_POST['db_host'] ?? 'localhost');
    $dbUser    = trim($_POST['db_user'] ?? '');
    $dbPass    = $_POST['db_pass'] ?? '';
    $dbName    = trim($_POST['db_name'] ?? '');

    // ❗ Pflichtfelder prüfen
    if ($adminUser === '' || $adminPass === '' || $dbUser === '' || $dbName === '') {
        exit('❌ Bitte alle Pflichtfelder ausfüllen.');
    }

    // 🔐 Passwort sicher hashen
    $adminHash = password_hash($adminPass, PASSWORD_BCRYPT);

    // 🔌 DB-Verbindung
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli($dbHost, $dbUser, $dbPass);
        $db->set_charset('utf8mb4');
    } catch (mysqli_sql_exception $e) {
        exit('❌ Datenbankverbindung fehlgeschlagen.');
    }

    // 🧱 Datenbank anlegen
    $db->query(
        "CREATE DATABASE IF NOT EXISTS `$dbName`
         CHARACTER SET utf8mb4
         COLLATE utf8mb4_general_ci"
    );
    $db->select_db($dbName);

    // 📜 SQL-Struktur importieren
    $sqlFile = __DIR__ . '/../sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        exit('❌ SQL-Strukturdatei fehlt.');
    }

    $sql = file_get_contents($sqlFile);
    $db->multi_query($sql);
    while ($db->more_results()) {
        $db->next_result();
    }

    // 👤 Benutzer-Tabelle
    $db->query("
        CREATE TABLE IF NOT EXISTS benutzer (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nutzername VARCHAR(255) UNIQUE NOT NULL,
            passwort VARCHAR(255) NOT NULL,
            erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    // 👑 Admin anlegen
    $stmt = $db->prepare(
        "INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)"
    );
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    // ⚙️ config.php schreiben
    $config = "<?php\n"
        . "\$db_host = '$dbHost';\n"
        . "\$db_user = '$dbUser';\n"
        . "\$db_pass = '$dbPass';\n"
        . "\$db_name = '$dbName';\n";

    file_put_contents(__DIR__ . '/../projekt/config.php', $config, LOCK_EX);
    file_put_contents(__DIR__ . '/../filemanager/config.php', $config, LOCK_EX);

    // 🔒 Setup sperren
    file_put_contents($lockFile, date('c'), LOCK_EX);

    // 🧹 setup.php selbst löschen
    @unlink(__FILE__);

    // 🎉 Erfolgsseite
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Installation abgeschlossen</title>
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh
}
.card{
    background:#0b1220;
    padding:40px;
    border-radius:18px;
    max-width:520px;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7)
}
a{
    display:block;
    margin-top:15px;
    color:#38bdf8;
    text-decoration:none;
    font-weight:600
}
</style>
</head>
<body>
<div class="card">
<img src="https://web-service.ubodigat.com/ubodigatlogo.svg" width="160"><br><br>
<h2>✅ Einrichtung abgeschlossen</h2>
<p>System ist vollständig einsatzbereit.</p>
<a href="/filemanager/">➡ Dateimanager öffnen</a>
<a href="/projekt/">➡ Projektseite öffnen</a>
<p style="margin-top:20px;color:#f87171">
🔒 Bitte lösche nun den Ordner <code>/install</code>.
</p>
</div>
</body>
</html>
HTML;
    exit;
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Einrichtung – Webprojekt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh
}
form{
    background:#0b1220;
    padding:40px;
    border-radius:18px;
    max-width:520px;
    width:100%;
    box-shadow:0 30px 80px rgba(0,0,0,.7)
}
img{
    display:block;
    margin:0 auto 20px;
    width:160px
}
label{
    display:block;
    margin-top:18px;
    font-size:14px
}
small{
    display:block;
    margin-top:4px;
    color:#94a3b8
}
input{
    width:100%;
    margin-top:6px;
    padding:12px;
    background:#020617;
    color:#e5e7eb;
    border:1px solid #334155;
    border-radius:10px
}
button{
    width:100%;
    margin-top:30px;
    padding:14px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,#22c55e,#4ade80);
    color:#022c22;
    font-size:16px;
    font-weight:700;
    cursor:pointer
}
</style>
</head>

<body>
<form method="post">
<img src="https://web-service.ubodigat.com/ubodigatlogo.svg">

<h2 style="text-align:center">🔧 Einrichtung – Webprojekt</h2>

<label>Admin-Benutzername
<small>Hauptadministrator für Dateimanager & System</small>
<input name="admin_user" required>
</label>

<label>Admin-Passwort
<small>Wird sicher verschlüsselt gespeichert</small>
<input type="password" name="admin_pass" required>
</label>

<label>Datenbank-Host
<small>In der Regel <code>localhost</code></small>
<input name="db_host" value="localhost">
</label>

<label>Datenbank-Benutzer
<small>MariaDB Benutzer mit ausreichenden Rechten</small>
<input name="db_user" required>
</label>

<label>Datenbank-Passwort
<small>Passwort des DB-Benutzers</small>
<input type="password" name="db_pass">
</label>

<label>Datenbank-Name
<small>Wird automatisch angelegt</small>
<input name="db_name" required>
</label>

<button>✅ Einrichtung starten</button>
</form>
</body>
</html>