<?php
declare(strict_types=1);

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    http_response_code(403);
    exit('❌ Setup bereits abgeschlossen.');
}

/* =========================================================
   🎨 ZENTRALE FEHLERSEITE (Darkmode)
   ========================================================= */
function showError(string $title, string $message): void
{
    http_response_code(500);
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Fehler – Installation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    min-height:100vh;
    background:radial-gradient(circle at top,#0f172a,#020617);
    display:flex;
    align-items:center;
    justify-content:center;
    font-family:system-ui;
    color:#e5e7eb;
}
.card{
    background:rgba(11,18,32,.95);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    text-align:center;
    border:1px solid rgba(34,48,74,.7);
    box-shadow:0 30px 80px rgba(0,0,0,.7);
}
h2{color:#f87171;margin-bottom:12px}
p{color:#cbd5f5}
</style>
</head>
<body>
<div class="card">
<h2>❌ {$title}</h2>
<p>{$message}</p>
</div>
</body>
</html>
HTML;
    exit;
}

/* =========================================================
   🔑 DB-DATEN AUS .db.env
   ========================================================= */
$envFile = __DIR__ . '/.db.env';
if (!file_exists($envFile)) {
    showError('Installationsfehler', '.db.env fehlt – bitte install.sh ausführen.');
}

$env = parse_ini_file($envFile);
$dbHost = $env['DB_HOST'] ?? '';
$dbUser = $env['DB_USER'] ?? '';
$dbPass = $env['DB_PASS'] ?? '';
$dbName = $env['DB_NAME'] ?? '';

if ($dbHost === '' || $dbUser === '' || $dbName === '') {
    showError('DB-Fehler', '.db.env ist unvollständig.');
}

/* =========================================================
   📂 PFADE
   ========================================================= */
$baseDir     = realpath(__DIR__ . '/..');
$configDir   = $baseDir . '/config';
$securityFile= $configDir . '/security.php';
$uploadDir   = $baseDir . '/uploads';

/* =========================================================
   📩 FORMULARVERARBEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* ---------- Eingaben ---------- */
    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';

    $filemanagerPass = $_POST['filemanager_pass'] ?? '';
    $timeout = (int)($_POST['filemanager_timeout'] ?? 1800);

    $webAccessEnabled = ($_POST['web_access_enabled'] ?? '0') === '1';
    $webAccessPass    = $_POST['web_access_pass'] ?? '';

    $createMysqlAdmin = ($_POST['create_mysql_admin'] ?? '') === '1';
    $mysqlAdminUser   = trim($_POST['mysql_admin_user'] ?? '');
    $mysqlAdminPass   = $_POST['mysql_admin_pass'] ?? '';

    /* ---------- Validierung ---------- */
    if ($adminUser === '' || $adminPass === '') {
        showError('Pflichtfelder', 'Admin-Benutzer und Passwort sind erforderlich.');
    }

    if ($filemanagerPass === '') {
        showError('Pflichtfelder', 'Dateimanager-Passwort fehlt.');
    }

    if ($webAccessEnabled && $webAccessPass === '') {
        showError('Web-Zugriff', 'Webzugriff aktiviert, aber kein Passwort gesetzt.');
    }

    if ($createMysqlAdmin && ($mysqlAdminUser === '' || $mysqlAdminPass === '')) {
        showError('MySQL-Admin', 'MySQL-Admin aktiviert, aber Daten fehlen.');
    }

    /* ---------- Hashes ---------- */
    $adminHash       = password_hash($adminPass, PASSWORD_BCRYPT);
    $filemanagerHash = password_hash($filemanagerPass, PASSWORD_BCRYPT);
    $webAccessHash   = $webAccessEnabled ? password_hash($webAccessPass, PASSWORD_BCRYPT) : '';

    /* =====================================================
       🗄️ DB VERBINDUNG
       ===================================================== */
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
        $db->set_charset('utf8mb4');
    } catch (mysqli_sql_exception) {
        showError('Datenbankfehler', 'Verbindung zur Datenbank fehlgeschlagen.');
    }

    /* =====================================================
       📥 SQL STRUKTUR IMPORT
       ===================================================== */
    $sqlFile = $baseDir . '/sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        showError('SQL fehlt', 'sql/struktur.sql nicht gefunden.');
    }

    $db->multi_query(file_get_contents($sqlFile));
    while ($db->more_results()) {
        $db->next_result();
    }

    /* =====================================================
       🐘 MySQL-Admin anlegen (optional)
       ===================================================== */
    if ($createMysqlAdmin) {
        $db->query("CREATE USER IF NOT EXISTS `$mysqlAdminUser`@'localhost' IDENTIFIED BY '$mysqlAdminPass'");
        $db->query("GRANT ALL PRIVILEGES ON *.* TO `$mysqlAdminUser`@'localhost' WITH GRANT OPTION");
        $db->query("FLUSH PRIVILEGES");
    }

    /* =====================================================
       👑 ADMIN USER (Applikation)
       ===================================================== */
    $db->query("
        CREATE TABLE IF NOT EXISTS benutzer (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nutzername VARCHAR(255) UNIQUE NOT NULL,
            passwort VARCHAR(255) NOT NULL,
            erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    $stmt = $db->prepare("INSERT IGNORE INTO benutzer (nutzername, passwort) VALUES (?,?)");
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    /* =====================================================
       🎨 HINTERGRUNDBILDER
       ===================================================== */
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    function saveBg(string $key): string {
        if (!isset($_FILES[$key]) || $_FILES[$key]['error'] !== UPLOAD_ERR_OK) {
            return '';
        }
        $name = uniqid('bg_', true) . '.webp';
        move_uploaded_file($_FILES[$key]['tmp_name'], __DIR__ . "/../uploads/{$name}");
        return "/uploads/{$name}";
    }

    $bgWeb = saveBg('bg_web');
    $bgFm  = saveBg('bg_fm');

    /* =====================================================
       🔐 security.php schreiben
       ===================================================== */
    if (!is_dir($configDir)) {
        mkdir($configDir, 0755, true);
    }

    file_put_contents($securityFile, "<?php
declare(strict_types=1);

define('WEB_ACCESS_ENABLED', " . ($webAccessEnabled ? 'true' : 'false') . ");
define('WEB_ACCESS_HASH', '{$webAccessHash}');

define('FILEMANAGER_ACCESS_HASH', '{$filemanagerHash}');
define('FILEMANAGER_TIMEOUT', {$timeout});

define('WEB_LOGIN_BG', '{$bgWeb}');
define('FILEMANAGER_LOGIN_BG', '{$bgFm}');
", LOCK_EX);

    /* =====================================================
       🔒 FINALISIERUNG
       ===================================================== */
    file_put_contents($lockFile, date('c'));
    @unlink($envFile);

    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Installation abgeschlossen</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    min-height:100vh;
    background:radial-gradient(circle at top,#0f172a,#020617);
    display:flex;
    align-items:center;
    justify-content:center;
    font-family:system-ui;
    color:#e5e7eb;
}
.card{
    background:rgba(11,18,32,.95);
    padding:40px;
    border-radius:18px;
    text-align:center;
    border:1px solid rgba(34,48,74,.7);
}
a{display:block;margin-top:12px;color:#38bdf8;text-decoration:none;font-weight:600}
</style>
</head>
<body>
<div class="card">
<h2>✅ Installation abgeschlossen</h2>
<p>Das System ist jetzt einsatzbereit.</p>
<a href="/projekt/">➡ Projekt öffnen</a>
<a href="/filemanager/">➡ Dateimanager öffnen</a>
</div>
</body>
</html>
HTML;
    exit;
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Einrichtung – Webprojekt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:24px;
}
form{
    background:rgba(11,18,32,.95);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    width:100%;
    border:1px solid rgba(34,48,74,.7);
}
h3{margin-top:28px}
p{color:#94a3b8;font-size:14px}
input,select,button{
    width:100%;
    margin-top:10px;
    padding:12px;
    border-radius:10px;
    border:1px solid #334155;
    background:#020617;
    color:#e5e7eb;
}
button{
    background:linear-gradient(135deg,#22c55e,#4ade80);
    color:#022c22;
    font-weight:800;
    margin-top:24px;
}
</style>
</head>
<body>

<form method="post" enctype="multipart/form-data">

<h2>🔧 Einrichtung</h2>

<h3>📂 Dateimanager</h3>
<input type="password" name="filemanager_pass" required placeholder="Dateimanager-Passwort">
<select name="filemanager_timeout">
<option value="900">15 Minuten</option>
<option value="1800" selected>30 Minuten</option>
<option value="3600">60 Minuten</option>
</select>

<h3>👑 Admin</h3>
<input name="admin_user" required placeholder="Admin-Benutzer">
<input type="password" name="admin_pass" required placeholder="Admin-Passwort">

<h3>🐘 MySQL-Admin (optional)</h3>
<label><input type="checkbox" name="create_mysql_admin" value="1"> MySQL-Admin anlegen</label>
<input name="mysql_admin_user" placeholder="MySQL-Admin Benutzer">
<input type="password" name="mysql_admin_pass" placeholder="MySQL-Admin Passwort">

<h3>🔐 Webseiten-Zugriff</h3>
<select name="web_access_enabled">
<option value="0">Öffentlich</option>
<option value="1">Passwortgeschützt</option>
</select>
<input type="password" name="web_access_pass" placeholder="Webseiten-Passwort">

<h3>🎨 Hintergrundbilder</h3>
<label>Webseiten-Login</label>
<input type="file" name="bg_web">
<label>Filemanager-Login</label>
<input type="file" name="bg_fm">

<button>✅ Einrichtung starten</button>
</form>

</body>
</html>