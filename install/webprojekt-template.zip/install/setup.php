<?php
declare(strict_types=1);

/**
 * 🔒 Setup-Schutz: Wenn bereits installiert → abbrechen
 */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    die('<h2>❌ Setup bereits abgeschlossen</h2><p>Die Installation wurde schon durchgeführt.</p>');
}

/**
 * 📨 Formular verarbeitet?
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 🔐 Eingaben absichern
    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';
    $dbHost    = trim($_POST['db_host'] ?? 'localhost');
    $dbUser    = trim($_POST['db_user'] ?? '');
    $dbPass    = $_POST['db_pass'] ?? '';
    $dbName    = trim($_POST['db_name'] ?? '');

    if (!$adminUser || !$adminPass || !$dbUser || !$dbName) {
        die('❌ Bitte alle Pflichtfelder ausfüllen.');
    }

    // 🔐 Passwort hashen
    $adminHash = password_hash($adminPass, PASSWORD_BCRYPT);

    /**
     * 🔌 Verbindung zu MariaDB (Root / Admin-User)
     */
    $mysqli = new mysqli($dbHost, $dbUser, $dbPass);
    if ($mysqli->connect_error) {
        die('❌ Datenbankverbindung fehlgeschlagen: ' . $mysqli->connect_error);
    }

    /**
     * 🧱 Datenbank erstellen
     */
    $mysqli->query("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $mysqli->select_db($dbName);

    /**
     * 📜 SQL-Struktur importieren
     */
    $sqlFile = __DIR__ . '/../sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        die('❌ SQL-Datei nicht gefunden.');
    }

    $sql = file_get_contents($sqlFile);
    if (!$mysqli->multi_query($sql)) {
        die('❌ Fehler beim Import der SQL-Struktur.');
    }
    while ($mysqli->more_results()) {
        $mysqli->next_result();
    }

    /**
     * 🔐 Admin-Benutzer anlegen
     */
    $mysqli->query("
        CREATE TABLE IF NOT EXISTS benutzer (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nutzername VARCHAR(255) UNIQUE NOT NULL,
            passwort VARCHAR(255) NOT NULL
        )
    ");

    $stmt = $mysqli->prepare("INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)");
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    /**
     * 🧾 config.php schreiben
     */
    $config = "<?php\n"
        . "\$db_host = '$dbHost';\n"
        . "\$db_user = '$dbUser';\n"
        . "\$db_pass = '$dbPass';\n"
        . "\$db_name = '$dbName';\n";

    file_put_contents(__DIR__ . '/../projekt/config.php', $config);
    file_put_contents(__DIR__ . '/../filemanager/config.php', $config);

    /**
     * 🔒 Setup sperren
     */
    file_put_contents($lockFile, date('c'));

    /**
     * 🎉 Fertig
     */
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Setup abgeschlossen</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f8; padding: 40px; }
        .box { background: white; padding: 30px; max-width: 600px; margin: auto; border-radius: 10px; }
        a { display: inline-block; margin-top: 15px; }
    </style>
</head>
<body>
<div class="box">
    <h2>✅ Installation erfolgreich</h2>
    <p>Das System wurde vollständig eingerichtet.</p>
    <a href="/filemanager/">➡ Zum Dateimanager</a><br>
    <a href="/projekt/">➡ Zum Projekt</a>
    <p style="margin-top:20px;color:#a00;">
        🔒 Bitte lösche jetzt den Ordner <code>/install</code> aus Sicherheitsgründen.
    </p>
</div>
</body>
</html>
HTML;
    exit;
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Setup – Webprojekt</title>
    <style>
        body { font-family: sans-serif; background: #f4f6f8; padding: 40px; }
        form { background: #fff; padding: 30px; max-width: 600px; margin: auto; border-radius: 10px; }
        label { display: block; margin-top: 15px; }
        input { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px 20px; font-size: 16px; }
    </style>
</head>
<body>

<form method="post">
    <h1>🔧 Einrichtung</h1>

    <label>Admin-Benutzername
        <input name="admin_user" required>
    </label>

    <label>Admin-Passwort
        <input type="password" name="admin_pass" required>
    </label>

    <label>Datenbank-Host
        <input name="db_host" value="localhost" required>
    </label>

    <label>Datenbank-Benutzer
        <input name="db_user" required>
    </label>

    <label>Datenbank-Passwort
        <input type="password" name="db_pass">
    </label>

    <label>Datenbank-Name
        <input name="db_name" required>
    </label>

    <button>✅ Installation starten</button>
</form>

</body>
</html>