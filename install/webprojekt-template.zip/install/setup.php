<?php
declare(strict_types=1);

/* =========================================================
   🎨 ZENTRALE FEHLERSEITE (Darkmode)
   ========================================================= */
function showError(string $title, string $message): void
{
    http_response_code(500);
    $logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Fehler – Installation</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="/filemanager/favicon.ico">
<style>
:root{
    --bg1:#0f172a; --bg2:#020617;
    --card:#0b1220; --border:#22304a;
    --text:#e5e7eb; --muted:#cbd5f5;
    --danger:#f87171; --link:#38bdf8;
}
*{box-sizing:border-box}
body{
    margin:0;
    min-height:100vh;
    background:radial-gradient(circle at top,var(--bg1),var(--bg2));
    color:var(--text);
    font-family:system-ui,-apple-system,BlinkMacSystemFont,sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:24px;
}
.card{
    background:rgba(11,18,32,.92);
    border:1px solid rgba(34,48,74,.7);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    width:100%;
    text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.7);
    backdrop-filter: blur(10px);
}
.logo{width:160px;margin-bottom:22px}
h2{margin:0 0 12px;color:var(--danger)}
p{color:var(--muted);line-height:1.6;margin:0}
a{color:var(--link);font-weight:600;text-decoration:none}
</style>
</head>
<body>
<div class="card">
<img src="$logo" class="logo" alt="ubodigat">
<h2>❌ $title</h2>
<p>$message</p>
</div>
</body>
</html>
HTML;
    exit;
}

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    showError(
        'Installation bereits abgeschlossen',
        'Dieses Setup wurde bereits ausgeführt und ist gesperrt.'
    );
}

/* =========================================================
   🔑 DB-DATEN – AUSSCHLIESSLICH AUS .db.env
   ========================================================= */
$envFile = __DIR__ . '/.db.env';

if (!file_exists($envFile)) {
    showError(
        'Installationsfehler',
        'Die Datei <code>.db.env</code> fehlt.<br>Bitte <code>install.sh</code> erneut ausführen.'
    );
}

$env = parse_ini_file($envFile);

$dbHost = $env['DB_HOST'] ?? '';
$dbUser = $env['DB_USER'] ?? '';
$dbPass = $env['DB_PASS'] ?? '';
$dbName = $env['DB_NAME'] ?? '';

if ($dbHost === '' || $dbUser === '' || $dbName === '') {
    showError(
        'Ungültige DB-Konfiguration',
        'Die Datei <code>.db.env</code> ist unvollständig.'
    );
}

/* =========================================================
   🔐 SECURITY CONFIG
   ========================================================= */
$securityDir  = realpath(__DIR__ . '/..') . '/config';
$securityFile = $securityDir . '/security.php';

/* =========================================================
   📩 FORMULARVERARBEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $webAccessEnabled = ($_POST['web_access_enabled'] ?? '0') === '1';
    $webAccessPass   = $_POST['web_access_pass'] ?? '';

    $filemanagerPass = $_POST['filemanager_pass'] ?? '';
    $timeoutRaw      = $_POST['filemanager_timeout'] ?? '1800';

    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';

    if ($adminUser === '' || $adminPass === '') {
        showError('Pflichtfelder fehlen', 'Admin-Benutzer und Passwort sind erforderlich.');
    }

    if ($filemanagerPass === '') {
        showError('Pflichtfelder fehlen', 'Bitte ein Passwort für den Dateimanager vergeben.');
    }

    if ($webAccessEnabled && $webAccessPass === '') {
        showError('Pflichtfelder fehlen', 'Webseiten-Zugriff ist aktiviert – Passwort fehlt.');
    }

    $timeout = (int)$timeoutRaw;
    if ($timeout < 0) $timeout = 1800;

    $adminHash       = password_hash($adminPass, PASSWORD_BCRYPT);
    $filemanagerHash = password_hash($filemanagerPass, PASSWORD_BCRYPT);
    $webAccessHash   = $webAccessEnabled ? password_hash($webAccessPass, PASSWORD_BCRYPT) : '';

    /* =====================================================
       🗄️ DB VERBINDUNG
       ===================================================== */
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    try {
        $db = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
        $db->set_charset('utf8mb4');
    } catch (mysqli_sql_exception) {
        showError(
            'Datenbankverbindung fehlgeschlagen',
            'Die Verbindung zur Datenbank konnte nicht hergestellt werden.'
        );
    }

    /* =====================================================
       📥 SQL IMPORT
       ===================================================== */
    $sqlFile = __DIR__ . '/../sql/struktur.sql';
    if (!file_exists($sqlFile)) {
        showError('SQL fehlt', 'Die Datei <code>sql/struktur.sql</code> wurde nicht gefunden.');
    }

    $sql = file_get_contents($sqlFile);
    $db->multi_query($sql);
    while ($db->more_results()) {
        $db->next_result();
    }

    /* =====================================================
       👤 ADMIN USER
       ===================================================== */
    $db->query("
        CREATE TABLE IF NOT EXISTS benutzer (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nutzername VARCHAR(255) UNIQUE NOT NULL,
            passwort VARCHAR(255) NOT NULL,
            erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB
    ");

    $stmt = $db->prepare("INSERT IGNORE INTO benutzer (nutzername, passwort) VALUES (?, ?)");
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    /* =====================================================
       🧩 CONFIG DATEIEN
       ===================================================== */
    $config = "<?php\n"
        . "\$db_host='{$dbHost}';\n"
        . "\$db_user='{$dbUser}';\n"
        . "\$db_pass='{$dbPass}';\n"
        . "\$db_name='{$dbName}';\n";

    file_put_contents(__DIR__ . '/../projekt/config.php', $config, LOCK_EX);
    file_put_contents(__DIR__ . '/../filemanager/config.php', $config, LOCK_EX);

    if (!is_dir($securityDir)) {
        mkdir($securityDir, 0755, true);
    }

    $security = "<?php\n"
        . "declare(strict_types=1);\n\n"
        . "define('WEB_ACCESS_ENABLED'," . ($webAccessEnabled ? 'true' : 'false') . ");\n"
        . "define('WEB_ACCESS_HASH','{$webAccessHash}');\n"
        . "define('FILEMANAGER_ACCESS_HASH','{$filemanagerHash}');\n"
        . "define('FILEMANAGER_TIMEOUT',{$timeout});\n";

    file_put_contents($securityFile, $security, LOCK_EX);

    /* =====================================================
       🔒 FINALISIERUNG
       ===================================================== */
    file_put_contents($lockFile, date('c'));
    @unlink($envFile);
    @unlink(__FILE__);

    echo "<h1>✅ Installation abgeschlossen</h1>";
    exit;
}

/* =========================================================
   🖥️ SETUP-FORMULAR
   ========================================================= */
$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>

<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Einrichtung – Webprojekt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{
    margin:0;
    background:radial-gradient(circle at top,#0f172a,#020617);
    color:#e5e7eb;
    font-family:system-ui;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:24px;
}
form{
    background:rgba(11,18,32,.92);
    padding:40px;
    border-radius:18px;
    max-width:560px;
    width:100%;
    border:1px solid rgba(34,48,74,.7);
}
input,select,button{
    width:100%;
    margin-top:10px;
    padding:12px;
    border-radius:10px;
    border:1px solid #334155;
    background:#020617;
    color:#e5e7eb;
}
button{
    background:linear-gradient(135deg,#22c55e,#4ade80);
    color:#022c22;
    font-weight:800;
    margin-top:20px;
}
</style>
</head>
<body>
<form method="post">
<img src="<?= $logo ?>" width="160" style="display:block;margin:0 auto 20px">

<h2>🔧 Einrichtung</h2>

<h3>📂 Dateimanager</h3>
<input type="password" name="filemanager_pass" required placeholder="Dateimanager-Passwort">
<select name="filemanager_timeout">
<option value="900">15 Minuten</option>
<option value="1800" selected>30 Minuten</option>
<option value="3600">60 Minuten</option>
</select>

<h3>👑 Admin</h3>
<input name="admin_user" required placeholder="Admin-Benutzer">
<input type="password" name="admin_pass" required placeholder="Admin-Passwort">

<h3>🔐 Webseiten-Zugriff</h3>
<select name="web_access_enabled">
<option value="0">Öffentlich</option>
<option value="1">Passwortgeschützt</option>
</select>
<input type="password" name="web_access_pass" placeholder="Webseiten-Passwort">

<button>✅ Einrichtung starten</button>
</form>
</body>
</html>
