let editor = null;
let darkModeVal = localStorage.getItem("darkMode");
let darkMode = darkModeVal === null ? true : (darkModeVal === "true");
let currentDirectorySystemBlocked = false;
let currentTableSort = { key: 'name', dir: 'asc' };
let _navHistory = [];
let _mouseOverTable = false;

function _updateLogo(isDark) {
    const logo = document.getElementById('siteLogo');
    if (logo) logo.src = isDark ? 'ubodigatlogo-breit[weiß].png' : 'ubodigatlogo-breit.png';
}

// Dark Mode
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    applyEditorTheme();
    _updateLogo(darkMode);
}
// Initialer Check – nur wenn body bereits existiert (script am Ende des body)
if (document.body) {
    if (darkMode) {
        document.body.classList.add("dark-mode");
    } else {
        document.body.classList.remove("dark-mode");
    }
    _updateLogo(darkMode);
}

// 🎨 Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    const ec = document.getElementById("editor-container");
    if (ec) ec.style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// 📂 Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "📂";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "🌐", htm: "🌐",
        php: "🐘",
        js: "📜",
        css: "🎨",
        txt: "📝",
        json: "🔢",
        pdf: "📑",
        ico: "📎",
        zip: "📦", rar: "📦",
        png: "🖼️", jpg: "🖼️", jpeg: "🖼️", gif: "🖼️", webp: "🖼️", svg: "🖼️",
        mp4: "🎞️", webm: "🎞️", mov: "🎞️",
        mp3: "🎵", wav: "🎵", flac: "🎵", aac: "🎵", m4a: "🎵", ogg: "🎵", opus: "🎵", wma: "🎵",
    };
    return icons[ext] || "📄";
}

// 🔒 HTML escapen (XSS-Schutz)
function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

// ── Passwort-Stärke-Checker ───────────────────────────────────────────────────
(function initPwCheckers() {
    var p = window.PW_POLICY || {};
    var minLen   = p.minLength    || 15;
    var minLower = p.minLowercase || 1;
    var minUpper = p.minUppercase || 1;
    var minNums  = p.minNumbers   || 1;
    var minSpec  = p.minSpecials  || 1;
    var PW_RULES = [{ test: function(v) { return v.length >= minLen; }, label: 'Mindestens ' + minLen + ' Zeichen' }];
    if (p.requireLower  !== false) PW_RULES.push({ test: function(v) { return (v.match(/[a-z]/g)||[]).length >= minLower; }, label: 'Mindestens ' + minLower + ' Kleinbuchstabe' + (minLower > 1 ? 'n' : '') });
    if (p.requireUpper  !== false) PW_RULES.push({ test: function(v) { return (v.match(/[A-Z]/g)||[]).length >= minUpper; }, label: 'Mindestens ' + minUpper + ' Großbuchstabe' + (minUpper > 1 ? 'n' : '') });
    if (p.requireNumber !== false) PW_RULES.push({ test: function(v) { return (v.match(/[0-9]/g)||[]).length >= minNums;  }, label: 'Mindestens ' + minNums  + ' Zahl' + (minNums > 1 ? 'en' : '') });
    if (p.requireSpecial!== false) PW_RULES.push({ test: function(v) { return (v.match(/[^A-Za-z0-9]/g)||[]).length >= minSpec; }, label: 'Mindestens ' + minSpec + ' Sonderzeichen' });

    var STRENGTH_COLORS = ['#ef4444','#f97316','#eab308','#84cc16','#10b981'];

    function buildChecker() {
        var div = document.createElement('div');
        div.className = 'pw-checker';
        div.innerHTML =
            '<p class="pw-checker-title">Passwortrichtlinien</p>' +
            '<div class="pw-strength-bar"><div class="pw-strength-fill"></div></div>' +
            PW_RULES.map(function(r, i) {
                return '<div class="pw-rule" data-idx="' + i + '"><span class="pw-rule-icon"><i class="bi bi-x-circle-fill"></i></span> ' + r.label + '</div>';
            }).join('');
        return div;
    }

    function updateChecker(checker, val) {
        var passed = 0;
        PW_RULES.forEach(function(r, i) {
            var el = checker.querySelector('[data-idx="' + i + '"]');
            if (!el) return;
            var ok = r.test ? r.test(val) : r.re.test(val);
            if (ok) passed++;
            el.querySelector('.pw-rule-icon').innerHTML = ok ? '<i class="bi bi-check-circle-fill"></i>' : '<i class="bi bi-x-circle-fill"></i>';
            el.classList.toggle('ok', ok);
        });
        var fill = checker.querySelector('.pw-strength-fill');
        if (fill) {
            var pct = Math.round((passed / PW_RULES.length) * 100);
            fill.style.width = pct + '%';
            fill.style.background = STRENGTH_COLORS[Math.min(passed, STRENGTH_COLORS.length) - 1] || '#ef4444';
        }
    }

    window.initPwChecker = function(inputEl) {
        if (!inputEl || inputEl._pwCheckerInit) return;
        inputEl._pwCheckerInit = true;
        var checker = buildChecker();
        // Insert OUTSIDE the password-wrapper so the eye button stays in place
        var anchor = inputEl.closest('.password-wrapper') || inputEl.parentNode;
        anchor.parentNode.insertBefore(checker, anchor.nextSibling);
        inputEl.addEventListener('input', function() { updateChecker(checker, inputEl.value); });
        inputEl.addEventListener('focus', function() { checker.classList.add('visible'); updateChecker(checker, inputEl.value); });
        inputEl.addEventListener('blur', function() { if (!inputEl.value) checker.classList.remove('visible'); });

        // Block form submit if password present but rules not all met
        var form = inputEl.closest('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                if (!inputEl.value) return;
                var failing = checker.querySelectorAll('.pw-rule:not(.ok)').length;
                if (failing > 0) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    checker.classList.add('visible');
                    updateChecker(checker, inputEl.value);
                    checker.style.borderColor = 'rgba(239,68,68,0.6)';
                    checker.style.boxShadow = '0 0 0 2px rgba(239,68,68,0.2)';
                    setTimeout(function() {
                        checker.style.borderColor = '';
                        checker.style.boxShadow = '';
                    }, 2000);
                    inputEl.focus();
                }
            }, true); // capture phase → runs before jQuery submit handlers
        }
    };

    // Attach to all pre-existing [data-pwcheck] inputs on DOM ready
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('input[type="password"][data-pwcheck]').forEach(function(el) {
            window.initPwChecker(el);
        });
    });

    // MutationObserver for dynamically added password inputs with data-pwcheck
    var observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(m) {
            m.addedNodes.forEach(function(node) {
                if (node.nodeType !== 1) return;
                var inputs = node.matches('input[type="password"][data-pwcheck]')
                    ? [node]
                    : Array.from(node.querySelectorAll('input[type="password"][data-pwcheck]'));
                inputs.forEach(function(el) { window.initPwChecker(el); });
            });
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });
}());

const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'm4v', 'ogg', 'ogv'];
const AUDIO_EXTENSIONS = ['mp3', 'wav', 'flac', 'aac', 'm4a', 'opus', 'wma'];

function getExtension(name) {
    const parts = String(name || '').toLowerCase().split('.');
    return parts.length > 1 ? parts.pop() : '';
}

function isImageFile(name) {
    return IMAGE_EXTENSIONS.includes(getExtension(name));
}

function isVideoFile(name) {
    return VIDEO_EXTENSIONS.includes(getExtension(name));
}

function isAudioFile(name) {
    return AUDIO_EXTENSIONS.includes(getExtension(name));
}

function isPdfFile(name) {
    return getExtension(name) === 'pdf';
}

function isMediaFile(name) {
    return isImageFile(name) || isVideoFile(name) || isAudioFile(name) || isPdfFile(name);
}

function parseDateForSort(value) {
    if (!value) return 0;
    if (typeof value === 'number') return value;
    const ts = Date.parse(value);
    if (!Number.isNaN(ts)) return ts;
    const match = String(value).match(/(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}):(\d{2})/);
    if (!match) return 0;
    return new Date(`${match[3]}-${match[2]}-${match[1]}T${match[4]}:${match[5]}:00`).getTime() || 0;
}

function compareFilesForSort(a, b, key) {
    const aIsFolder = a.type === 'folder' || a.type === 'Ordner';
    const bIsFolder = b.type === 'folder' || b.type === 'Ordner';

    if (key !== 'status' && aIsFolder !== bIsFolder) {
        return aIsFolder ? -1 : 1;
    }

    const nameA = String(a.name || '').toLowerCase();
    const nameB = String(b.name || '').toLowerCase();

    switch (key) {
        case 'name':
            return nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'status':
            return String(a.isSystemBlocked ? '1' : '0').localeCompare(String(b.isSystemBlocked ? '1' : '0')) || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'type':
            return String(a.type || '').localeCompare(String(b.type || ''), 'de', { sensitivity: 'base' }) || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'size': {
            const sizeA = Number(a.sizeBytes || 0);
            const sizeB = Number(b.sizeBytes || 0);
            return sizeA - sizeB || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        }
        case 'date': {
            const timeA = parseDateForSort(a.modifiedTimestamp || a.date);
            const timeB = parseDateForSort(b.modifiedTimestamp || b.date);
            return timeA - timeB || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        }
        default:
            return nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
    }
}

function sortFilesList(files) {
    const sorted = [...files];
    sorted.sort((a, b) => {
        const result = compareFilesForSort(a, b, currentTableSort.key);
        return currentTableSort.dir === 'asc' ? result : -result;
    });
    return sorted;
}

function updateSortIndicators() {
    document.querySelectorAll('th[data-sort-key]').forEach(th => {
        const key = th.getAttribute('data-sort-key');
        const isActive = key === currentTableSort.key;
        th.dataset.sortDir = isActive ? currentTableSort.dir : '';
        th.title = isActive
            ? `Sortierung: ${currentTableSort.dir === 'asc' ? 'aufsteigend ▲' : 'absteigend ▼'} — klicken zum Umkehren`
            : 'Klicken zum Sortieren';
    });
}

function setTableSort(key) {
    if (!key) return;
    if (currentTableSort.key === key) {
        currentTableSort.dir = currentTableSort.dir === 'asc' ? 'desc' : 'asc';
    } else {
        currentTableSort.key = key;
        currentTableSort.dir = key === 'size' || key === 'date' ? 'desc' : 'asc';
    }
    updateSortIndicators();
    loadFiles();
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('th[data-sort-key]').forEach(th => {
        th.addEventListener('click', () => setTableSort(th.getAttribute('data-sort-key')));
    });
    updateSortIndicators();
});
// 🖼️ Custom Modal
function customModal({
    title,
    message,
    type = 'alert',
    confirmText = 'OK',
    cancelText = 'Abbrechen',
    inputPlaceholder = '',
    defaultValue = ''
}) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay modal-front"></div>');
        const card = $('<div class="modal-card"></div>');
        const header = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close" title="Schlie&szlig;en">✕</button>');
        header.append(closeBtn);
        closeBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        const body = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${defaultValue}">`);
            body.append(input);
        }

        const confirmBtn = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const cancelBtn = $(`<button class="btn btn-secondary">${cancelText}</button>`);


        confirmBtn.on('click', () => {
            let result = true;
            if (type === 'prompt') result = input.val();
            overlay.remove();
            resolve(result);
        });
        cancelBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        footer.append(cancelBtn).append(confirmBtn);
        if (type === 'alert') cancelBtn.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').append(overlay);
        overlay.on('click', e => { if (e.target === overlay[0]) { overlay.remove(); resolve(null); } });
        if (input) input.focus();
    });
}

function showSystemBlockedNotice(itemName = '') {
    const safeName = escHtml(itemName || 'Dieser Eintrag');
    return customModal({
        title: '<i class="bi bi-lock-fill"></i> Gesperrt',
        message: `${safeName} ist durch das System gesperrt und kann nicht bearbeitet werden.`
    });
}

function updateMutationControlsLockState() {
    const lock = !!currentDirectorySystemBlocked;
    const message = lock ? 'Dieser Ordner ist systemgesperrt. Aktualisieren bleibt verfuegbar.' : '';

    const uploadInput = document.getElementById('uploadFile');
    const uploadBtn = document.getElementById('uploadBtn');
    const createFileBtn = document.getElementById('createFileBtn');
    const createFolderBtn = document.getElementById('createFolderBtn');
    const newFileName = document.getElementById('newFileName');
    const newFolderName = document.getElementById('newFolderName');

    if (uploadInput) {
        uploadInput.disabled = lock;
        uploadInput.title = message;
    }
    if (uploadBtn) {
        uploadBtn.disabled = lock;
        uploadBtn.title = message;
    }
    if (createFileBtn) {
        createFileBtn.disabled = lock;
        createFileBtn.title = message;
    }
    if (createFolderBtn) {
        createFolderBtn.disabled = lock;
        createFolderBtn.title = message;
    }
    if (newFileName) {
        newFileName.disabled = lock;
        newFileName.title = message;
    }
    if (newFolderName) {
        newFolderName.disabled = lock;
        newFolderName.title = message;
    }
}

// 🔄 Dateien laden
function loadFiles() {
    const dirInput = document.getElementById("directoryPath");
    if (!dirInput) return;
    const dir = dirInput.value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            customModal({
                title: '<i class="bi bi-x-circle"></i> Fehler',
                message: escHtml(data.error)
            });
            return;
        }

        currentDirectorySystemBlocked = !!data.currentPathBlocked;
        updateMutationControlsLockState();
        updateSortIndicators();

        const table = $("#fileTable").empty();
        const files = sortFilesList(data.files || []);
        const separator = dir.includes("\\") ? "\\" : "/";

        if (files.length === 0) {
            table.append(`
                <tr>
                    <td colspan="6" style="text-align:center; padding:60px 20px; color:var(--text-muted);">
                        <div style="font-size:48px; margin-bottom:16px;">📂</div>
                        <h3 style="margin:0 0 8px; color:var(--text);">Dieser Ordner ist leer</h3>
                        <p style="margin:0 0 24px; font-size:14px;">Lade eine Datei hoch oder erstelle einen neuen Ordner.</p>
                    </td>
                </tr>
            `);
            return;
        }

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = (dir === '.' ? '' : dir).replace(/[/\\]$/, "") + (dir === '.' ? '' : separator) + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";
            const isZip = !isFolder && file.name.toLowerCase().endsWith('.zip');
            const isPrivate = !!file.isPrivate;
            const nameEsc = escHtml(file.name);
            const typeEsc = escHtml(file.type);
            const dateEsc = escHtml(file.date);
            // Schloss-Icon für private Elemente (nur Admin sieht es, da normale User private Elemente gar nicht sehen)
            const privBadge = (window.isSystemAdmin && isPrivate) ? ' <span title="Privat – nur Admins" style="font-size:12px; opacity:0.7;"><i class="bi bi-lock-fill"></i></span>' : '';

            let badgeText = isPrivate ? '<i class="bi bi-lock"></i> Verborgen' : '<i class="bi bi-globe"></i> Sichtbar';
            let badgeClass = isPrivate ? 'vis-private' : 'vis-public';
            if (file.isSystemBlocked) {
                badgeText = '<i class="bi bi-slash-circle"></i> Gesperrt';
                badgeClass = 'vis-system';
            }

            const sizeEsc = escHtml(file.sizeFormatted || '-');

            const row = $(`
                <tr data-type="${typeEsc}" data-name="${nameEsc}" data-path="${escHtml(fullPath)}">
                    <td style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:0;" title="${nameEsc}">${icon} ${nameEsc}</td>
                    <td>
                        <span class="vis-badge ${badgeClass}">
                            ${badgeText}
                        </span>
                    </td>
                    <td>${typeEsc}</td>
                    <td>${sizeEsc}</td>
                    <td>${dateEsc}</td>
                    <td>
                        <div class="action-btn-group">
                            <button class="btn btn-primary  btn-small js-open-folder" title="Öffnen"     style="display:${isFolder?'':'none'}"><i class="bi bi-folder2-open"></i> Öffnen</button>
                            <button class="btn btn-primary  btn-small js-edit-file"   title="Bearbeiten" style="display:${isFolder?'none':''}"><i class="bi bi-pencil-square"></i> Edit</button>
                            <button class="btn btn-secondary btn-small js-rename"     title="Umbenennen"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-danger   btn-small js-delete"      title="Löschen"><i class="bi bi-trash3"></i></button>
                            <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-secondary btn-small" title="Herunterladen"><i class="bi bi-download"></i></a>
                            ${isZip ? `<button class="btn btn-secondary btn-small js-unzip-file" title="ZIP entpacken"><i class="bi bi-file-earmark-zip"></i></button>` : ''}
                            ${window.isSystemAdmin ? `<button class="btn btn-secondary btn-small js-visibility" title="${isPrivate?'Privat – klicken um öffentlich zu setzen':'Öffentlich – klicken um privat zu setzen'}" style="opacity:${isPrivate?'1':'0.5'}; visibility:${file.isSystemBlocked ? 'hidden' : 'visible'};"><i class="${isPrivate?'bi bi-lock':'bi bi-globe'}"></i></button>` : ''}
                        </div>
                    </td>
                </tr>`);

            if (file.isSystemBlocked) {
                row.find('.js-edit-file, .js-rename, .js-delete')
                    .attr('title', 'Durch System gesperrt')
                    .css({ opacity: '0.45', cursor: 'not-allowed' });
            }

            row.find('.js-open-folder').on('click', () => openFolderByPath(encodeURIComponent(file.name)));
            row.find('.js-edit-file').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                handleEditAction(file, fullPath);
            });
            row.find('.js-rename').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                renameFile(file.name);
            });
            row.find('.js-delete').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                deleteFile(file.name);
            });
            row.find('.js-visibility').on('click', () => showVisibility(fullPath, isFolder, isPrivate));
            row.find('.js-unzip-file').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                unzipFile(fullPath);
            });

            row.on('contextmenu', e => {
                e.preventDefault();
                showFileContextMenu(e, file, fullPath, isFolder);
            });

            table.append(row);
        });
    }).fail(jqXHR => customModal({
        title: '<i class="bi bi-x-circle"></i> Fehler',
        message: "Ladefehler: " + escHtml(jqXHR.responseText)
    }));
}

// 👁️ Sichtbarkeit verwalten
async function showVisibility(path, isFolder, currentlyPrivate) {
    if (!window.isSystemAdmin) return customModal({
        title: '<i class="bi bi-lock"></i> Zugriff verweigert',
        message: 'Admin-Rechte erforderlich!'
    });

    const itemName = path.split('/').pop() || path.split('\\').pop() || path;

    if (currentlyPrivate) {
        // Aktuell PRIVAT → auf Öffentlich setzen
        let cascade = false;
        if (isFolder) {
            // Ordner: Abfrage mit Cascade-Option
            const overlay = $('<div class="modal-overlay modal-front"></div>');
            const card = $(`
                <div class="modal-card" style="max-width:420px;">
                    <div class="modal-header"><i class="bi bi-globe"></i> Ordner öffentlich setzen
                        <button class="modal-close">x</button>
                    </div>
                    <div class="modal-body">
                        <p>Ordner <b>${escHtml(itemName)}</b> für alle angemeldeten Nutzer sichtbar machen?</p>
                        <div style="margin-top:15px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px;">
                                <input type="checkbox" id="vis-cascade" style="width:18px; height:18px; flex-shrink:0;">
                                <span>Auch alle Unterordner und Dateien öffentlich setzen (private Einzel-Einstellungen entfernen)</span>
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="vis-cancel">Abbrechen</button>
                        <button class="btn btn-success"   id="vis-confirm"><i class="bi bi-globe"></i> Öffentlich setzen</button>
                    </div>
                </div>`);
            overlay.append(card);
            $('body').append(overlay);
            overlay.on('click', e => { if (e.target === overlay[0]) { overlay.remove(); } });
            card.find('.modal-close, #vis-cancel').on('click', () => {
                overlay.remove();
                return;
            });
            card.find('#vis-confirm').on('click', () => {
                cascade = card.find('#vis-cascade').is(':checked');
                overlay.remove();
                doSetVisibility(path, 'public', cascade);
            });
            return;
        }
        // Einfache Datei
        const ok = await customModal({
            title: '<i class="bi bi-globe"></i> Öffentlich setzen',
            message: `<b>${escHtml(itemName)}</b> für alle angemeldeten Nutzer sichtbar machen?`,
            type: 'confirm',
            confirmText: 'Öffentlich setzen'
        });
        if (ok) doSetVisibility(path, 'public', false);

    } else {
        // Aktuell ÖFFENTLICH → auf Privat setzen
        let msg = `<b>${escHtml(itemName)}</b> nur für Admins sichtbar machen?`;
        if (isFolder) msg += `<br><br><span style="font-size:12px; color:#94a3b8;"><i class="bi bi-lightbulb"></i> Alle Unterordner und Dateien werden automatisch ausgeblendet – kein einzelnes Setzen nötig.</span>`;
        const ok = await customModal({
            title: '<i class="bi bi-lock"></i> Privat setzen',
            message: msg,
            type: 'confirm',
            confirmText: 'Privat setzen'
        });
        if (ok) doSetVisibility(path, 'private', false);
    }
}

function doSetVisibility(path, status, cascade) {
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'set_visibility',
            path,
            status,
            cascade
        }),
        success: res => {
            if (res.error) customModal({
                title: '<i class="bi bi-x-circle"></i> Fehler',
                message: escHtml(res.error)
            });
            else {
                customModal({
                    title: '<i class="bi bi-check-circle-fill" style="color:#10b981;"></i> Gespeichert',
                    message: escHtml(res.success)
                });
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: '<i class="bi bi-x-circle"></i> Fehler',
            message: 'Fehler: ' + escHtml(jqXHR.responseText)
        })
    });
}

// Ordner öffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    _navHistory.push(pathInput.value);
    const sep = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + sep + name;
    loadFiles();
}

$(document).on("click", "#fileTable tr", function(e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").replace(/🔒\s*$/, "").trim();
    const type = $(this).attr("data-type");
    if (type === "folder" || type === "Ordner") openFolderByPath(name);
});

// ✏️ Datei bearbeiten
function handleEditAction(file, fullPath) {
    if (file && file.isSystemBlocked) {
        showSystemBlockedNotice(file.name || 'Dieser Eintrag');
        return;
    }
    if (isMediaFile(file.name)) {
        showMediaActionModal(file, fullPath);
        return;
    }
    editFile(file.name);
}

function showMediaActionModal(file, fullPath) {
    const fileName = escHtml(String(file.name || "").replace(/\uFFFD/g, "").replace(/[\u0000-\u001F\u007F]/g, ""));
    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:520px;">
            <div class="modal-header">Medien-Aktionen: ${fileName}
                <button class="modal-close" type="button">✕</button>
            </div>
            <div class="modal-body">
                <p>Diese Datei kann nicht als Text bearbeitet werden. W&auml;hle stattdessen eine Aktion:</p>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                    <button type="button" class="btn btn-primary" id="media-meta-btn">📝 Metadaten bearbeiten</button>
                    <button type="button" class="btn btn-success" id="media-view-btn">👁️ Datei anzeigen</button>
                </div>
            </div>
        </div>
    `);
    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    overlay.on('click', e => { if (e.target === overlay[0]) close(); });
    card.find('.modal-close').on('click', close);
    card.find('#media-view-btn').on('click', () => {
        close();
        showMediaViewer(file, fullPath);
    });
    card.find('#media-meta-btn').on('click', () => {
        close();
        showMediaMetadataEditor(file, fullPath);
    });
}

function showMediaViewer(file, fullPath) {
    const encodedPath = encodeURIComponent(fullPath);
    const url = `download.php?path=${encodedPath}&inline=1`;
    const fileName = escHtml(String(file.name || "").replace(/\uFFFD/g, "").replace(/[\u0000-\u001F\u007F]/g, ""));

    let viewerHtml = '';
    if (isImageFile(file.name)) {
        viewerHtml = `<img src="${url}" alt="${fileName}" style="max-width:100%; max-height:70vh; border-radius:10px; display:block; margin:0 auto;">`;
    } else if (isVideoFile(file.name)) {
        viewerHtml = `<video controls style="width:100%; max-height:70vh; border-radius:10px; background:black;"><source src="${url}">Dein Browser unterst&uuml;tzt dieses Videoformat nicht.</video>`;
    } else if (isAudioFile(file.name)) {
        viewerHtml = `<div style="padding:30px 0 20px;"><audio controls style="width:100%; border-radius:10px;"><source src="${url}">Dein Browser unterst&uuml;tzt dieses Audioformat nicht.</audio></div>`;
    } else if (isPdfFile(file.name)) {
        viewerHtml = `<iframe src="${url}" style="width:100%; height:75vh; border:none; border-radius:10px;" title="${fileName}"></iframe>`;
    } else {
        window.open(url, '_blank', 'noopener');
        return;
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:900px; width:min(900px, 95vw);">
            <div class="modal-header">Vorschau: ${fileName}
                <button class="modal-close" type="button">✕</button>
            </div>
            <div class="modal-body" style="text-align:center;">
                ${viewerHtml}
                <p style="margin-top:12px; font-size:12px; opacity:0.75;">Falls die Vorschau blockiert ist, &ouml;ffnet der Link die Datei direkt.</p>
            </div>
            <div class="modal-footer">
                <a href="${url}" target="_blank" rel="noopener" class="btn btn-success">In neuem Tab &ouml;ffnen</a>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);
    overlay.on('click', e => { if (e.target === overlay[0]) overlay.remove(); });
    card.find('.modal-close').on('click', () => overlay.remove());
}

async function showMediaMetadataEditor(file, fullPath) {
    let meta = null;
    let responseData = null;
    try {
        responseData = await $.ajax({
            url: 'media_api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'get', path: fullPath })
        });
        if (responseData.error) {
            throw new Error(responseData.error);
        }
        meta = responseData.metadata || {};
    } catch (err) {
        customModal({
            title: 'Fehler',
            message: escHtml(err.message || 'Metadaten konnten nicht geladen werden.')
        });
        return;
    }

    const canEditMediaMeta = responseData && responseData.canEdit !== false;
    const blockedReason = responseData && responseData.metadata && responseData.metadata.systemBlocked
        ? 'Dieser Eintrag ist durch das System gesperrt und kann nicht bearbeitet werden.'
        : (!canEditMediaMeta ? 'Metadaten bearbeiten ist fuer diesen Eintrag nicht erlaubt.' : '');

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:650px;">
            <div class="modal-header">Metadaten: ${escHtml(file.name)}
                <button class="modal-close" type="button">✕</button>
            </div>
            <div class="modal-body">
                <div style="font-size:12px; opacity:0.75; margin-bottom:12px;">
                    Typ: <b>${escHtml(meta.mimeType || 'unbekannt')}</b> - Gr&ouml;&szlig;e: <b>${escHtml(meta.sizeFormatted || '-')}</b>
                </div>
                ${blockedReason ? `<div class="alert alert-warning" style="margin-bottom:12px;">${escHtml(blockedReason)}</div>` : ''}
                <label style="display:block; margin-bottom:6px;">Datum/Zeit</label>
                <input type="text" id="meta-capturedAt" class="modal-input" placeholder="z. B. 2026-05-31 14:30:00" value="${escHtml(meta.capturedAt || '')}">

                <label style="display:block; margin:12px 0 6px;">Standort</label>
                <input type="text" id="meta-location" class="modal-input" placeholder="z. B. Berlin, Deutschland" value="${escHtml(meta.location || '')}">

                <label style="display:block; margin:12px 0 6px;">Beschreibung</label>
                <textarea id="meta-description" class="modal-input" rows="4" style="resize:vertical;">${escHtml(meta.description || '')}</textarea>

                <p style="font-size:12px; opacity:0.7; margin-top:10px;">Hinweis: Datum aktualisiert zus&auml;tzlich das Dateidatum, Standort/Beschreibung werden systemseitig gespeichert.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="meta-cancel-btn">Abbrechen</button>
                <button type="button" class="btn btn-primary" id="meta-save-btn" ${canEditMediaMeta ? '' : 'disabled'}>Speichern</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    overlay.on('click', e => { if (e.target === overlay[0]) close(); });
    card.find('.modal-close, #meta-cancel-btn').on('click', close);
    if (!canEditMediaMeta) {
        card.find('#meta-capturedAt, #meta-location, #meta-description').prop('disabled', true);
    }

    card.find('#meta-save-btn').on('click', async () => {
        if (!canEditMediaMeta) {
            customModal({
                title: 'Gesperrt',
                message: escHtml(blockedReason || 'Dieser Eintrag kann nicht bearbeitet werden.')
            });
            return;
        }
        const payload = {
            action: 'save',
            path: fullPath,
            metadata: {
                capturedAt: card.find('#meta-capturedAt').val().trim(),
                location: card.find('#meta-location').val().trim(),
                description: card.find('#meta-description').val().trim()
            }
        };

        const saveBtn = card.find('#meta-save-btn');
        saveBtn.prop('disabled', true).text('Speichert...');

        try {
            const response = await $.ajax({
                url: 'media_api.php',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(payload)
            });
            if (response.error) {
                throw new Error(response.error);
            }
            close();
            customModal({
                title: 'Gespeichert',
                message: escHtml(response.success || 'Metadaten wurden gespeichert.')
            });
            loadFiles();
        } catch (err) {
            saveBtn.prop('disabled', false).text('Speichern');
            customModal({
                title: 'Fehler',
                message: escHtml(err.message || 'Metadaten konnten nicht gespeichert werden.')
            });
        }
    });
}
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({
            title: '<i class="bi bi-x-circle"></i> Fehler',
            message: escHtml(data.error)
        });
        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();
        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = {
                php: "php",
                js: "javascript",
                css: "css",
                html: "html",
                txt: "plaintext"
            };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => customModal({
        title: '<i class="bi bi-x-circle"></i> Fehler',
        message: "Fehler: " + escHtml(jqXHR.responseText)
    }));
}

// 💾 Datei speichern
async function saveFile() {
    if (!editor) return;
    const content = editor.getValue();
    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content
        }),
        success: response => {
            if (response.error) customModal({
                title: '<i class="bi bi-x-circle"></i> Fehler',
                message: escHtml(response.error)
            });
            else {
                customModal({
                    title: '<i class="bi bi-check-circle-fill" style="color:#10b981;"></i> Gespeichert',
                    message: response.success || "Gespeichert."
                });
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: '<i class="bi bi-x-circle"></i> Fehler',
            message: "Fehler beim Speichern: " + escHtml(jqXHR.responseText)
        })
    });
}

// 📁 Modal
function openEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        overlay.classList.remove("hidden");
        $(overlay).fadeIn();
    }
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        $(overlay).fadeOut(() => overlay.classList.add("hidden"));
    }
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// 🗑️ Löschen (Server entscheidet über Berechtigung)
async function deleteFile(name) {
    const confirmed = await customModal({
        title: '🗑️ Löschen bestätigen',
        message: `"${escHtml(name)}" wirklich löschen?`,
        type: 'confirm',
        confirmText: 'Ja',
        cancelText: 'Nein'
    });
    if (!confirmed) return;
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) customModal({
            title: '<i class="bi bi-x-circle"></i> Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: '✅ Gelöscht',
                message: response.success || "Gelöscht."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: '<i class="bi bi-x-circle"></i> Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// 📦 ZIP entpacken
async function unzipFile(fullPath) {
    const name = fullPath.split(/[\/\\]/).pop();
    const confirmed = await customModal({
        title: '📦 ZIP entpacken',
        message: `<b>${escHtml(name)}</b> hier entpacken?`,
        type: 'confirm',
        confirmText: '📦 Entpacken',
        cancelText: 'Abbrechen'
    });
    if (!confirmed) return;
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ action: 'unzip_file', path: fullPath }),
        dataType: 'json',
        success: res => {
            if (res.error) {
                customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: escHtml(res.error) });
            } else {
                customModal({ title: '✅ Erfolg', message: escHtml(res.success) });
                loadFiles();
            }
        },
        error: jqXHR => customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: 'Verbindungsfehler: ' + escHtml(jqXHR.responseText) })
    });
}

async function showTrashManager() {
    if (!window.isSystemAdmin) {
        return customModal({
            title: 'Zugriff verweigert',
            message: 'Admin-Rechte erforderlich.'
        });
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:860px; width:min(860px, 96vw); display:flex; flex-direction:column; max-height:90vh;">
            <div class="modal-header">🗑️ Papierkorb
                <button class="modal-close" type="button">✕</button>
            </div>
            <div class="modal-body" style="flex:1; overflow-y:auto; min-height:0;">
                <div id="trash-status" style="margin-bottom:12px; opacity:0.8;">Lade Papierkorb...</div>
                <div id="trash-content"></div>
            </div>
            <div class="modal-footer" style="gap:10px; flex-wrap:wrap; flex-shrink:0;">
                <button type="button" class="btn btn-danger" id="trash-empty-btn">🧹 Papierkorb leeren</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    overlay.on('click', e => { if (e.target === overlay[0]) close(); });
    card.find('.modal-close').on('click', close);

    const renderTrash = (items) => {
        const content = card.find('#trash-content').empty();
        const status = card.find('#trash-status');

        if (!items.length) {
            status.text('Der Papierkorb ist leer.');
            content.append('<p style="margin:0; color:var(--text-muted);">Keine gelöschten Elemente vorhanden.</p>');
            return;
        }

        status.text(`${items.length} Element(e) gefunden.`);
        const table = $(`
            <div style="overflow-x:auto; border:1px solid var(--border); border-radius:12px;">
                <table style="width:100%; border-collapse:collapse; min-width:480px;">
                    <thead>
                        <tr style="background:rgba(255,255,255,0.04);">
                            <th style="text-align:left; padding:10px 12px;">Name / Pfad</th>
                            <th style="text-align:left; padding:10px 12px; white-space:nowrap;">Gelöscht</th>
                            <th style="text-align:left; padding:10px 12px;">Typ</th>
                            <th style="text-align:left; padding:10px 12px;">Größe</th>
                            <th style="text-align:right; padding:10px 12px;">Aktionen</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        `);
        const tbody = table.find('tbody');

        items.forEach(item => {
            const rawDate = item.deletedAt || '-';
            const niceDate = rawDate.replace('T', ' ').replace(/(\d{2}:\d{2}):\d{2}.*$/, '$1');
            const originPath = item.originalPath || '-';
            const row = $(`
                <tr>
                    <td style="padding:10px 12px; border-top:1px solid var(--border); max-width:220px;">
                        <div style="font-weight:500; word-break:break-all;">${escHtml(item.originalName || item.trashName)}</div>
                        <div style="font-size:11px; opacity:0.55; margin-top:2px; word-break:break-all;">${escHtml(originPath)}</div>
                    </td>
                    <td style="padding:10px 12px; border-top:1px solid var(--border); white-space:nowrap; font-size:13px;">${escHtml(niceDate)}</td>
                    <td style="padding:10px 12px; border-top:1px solid var(--border); white-space:nowrap;">${item.isDir ? '📁 Ordner' : '📄 Datei'}</td>
                    <td style="padding:10px 12px; border-top:1px solid var(--border); white-space:nowrap; font-size:13px;">${escHtml(item.sizeFormatted || '-')}</td>
                    <td style="padding:10px 12px; border-top:1px solid var(--border); text-align:right;">
                        <div style="display:flex; gap:6px; justify-content:flex-end;">
                            <button type="button" class="btn btn-secondary btn-small js-trash-restore" title="Wiederherstellen"><i class="bi bi-arrow-counterclockwise"></i></button>
                            <button type="button" class="btn btn-danger btn-small js-trash-delete" title="Endgültig löschen"><i class="bi bi-trash3"></i></button>
                        </div>
                    </td>
                </tr>
            `);

            row.find('.js-trash-restore').on('click', async () => {
                const confirmed = await customModal({
                    title: '↩️ Wiederherstellen',
                    message: `"<b>${escHtml(item.originalName || item.trashName)}</b>" wiederherstellen?`,
                    type: 'confirm',
                    confirmText: 'Wiederherstellen',
                    cancelText: 'Abbrechen'
                });
                if (!confirmed) return;
                $.ajax({
                    url: 'api.php',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({ action: 'trash_restore', trashName: item.trashName }),
                    success: res => {
                        if (res.error) {
                            customModal({ title: 'Fehler', message: escHtml(res.error) });
                        } else {
                            showTrashManager();
                        }
                    },
                    error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
                });
            });

            row.find('.js-trash-delete').on('click', async () => {
                const confirmed = await customModal({
                    title: '🗑️ Endgültig löschen',
                    message: `"<b>${escHtml(item.originalName || item.trashName)}</b>" endgültig löschen?`,
                    type: 'confirm',
                    confirmText: 'Löschen',
                    cancelText: 'Abbrechen'
                });
                if (!confirmed) return;
                $.ajax({
                    url: 'api.php',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({ action: 'trash_delete', trashName: item.trashName }),
                    success: res => {
                        if (res.error) {
                            customModal({ title: 'Fehler', message: escHtml(res.error) });
                        } else {
                            showTrashManager();
                        }
                    },
                    error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
                });
            });

            tbody.append(row);
        });

        content.append(table);
    };

    const loadTrash = () => {
        card.find('#trash-status').text('Lade Papierkorb...');
        $.ajax({
            url: 'api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'trash_list' }),
            success: res => {
                if (res.error) {
                    card.find('#trash-status').text('Fehler beim Laden des Papierkorbs.');
                    card.find('#trash-content').html(`<div style="color:#ffb4b4;">${escHtml(res.error)}</div>`);
                    return;
                }
                renderTrash(res.items || []);
            },
            error: jqXHR => {
                card.find('#trash-status').text('Fehler beim Laden des Papierkorbs.');
                card.find('#trash-content').html(`<div style="color:#ffb4b4;">${escHtml(jqXHR.responseText || 'Unbekannter Fehler')}</div>`);
            }
        });
    };

    card.find('#trash-empty-btn').on('click', async () => {
        const confirmed = await customModal({
            title: '🧹 Papierkorb leeren',
            message: 'Alle Elemente im Papierkorb endgültig löschen?',
            type: 'confirm',
            confirmText: 'Leeren',
            cancelText: 'Abbrechen'
        });
        if (!confirmed) return;
        $.ajax({
            url: 'api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'trash_empty' }),
            success: res => {
                if (res.error) {
                    customModal({ title: 'Fehler', message: escHtml(res.error) });
                } else {
                    showTrashManager();
                }
            },
            error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
        });
    });

    loadTrash();
}

// 📄 Umbenennen (Server entscheidet über Berechtigung)
async function renameFile(oldName) {
    const newName = await customModal({
        title: '📄 Umbenennen',
        message: 'Neuer Name:',
        type: 'prompt',
        defaultValue: oldName
    });
    if (!newName || newName === oldName) return;
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName,
        newName
    }), response => {
        if (response.error) customModal({
            title: '<i class="bi bi-x-circle"></i> Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: '✅ Umbenannt',
                message: response.success || "Umbenannt."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: '<i class="bi bi-x-circle"></i> Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// ➕ Erstellen (Server entscheidet über Berechtigung)
function _showOverwriteDialog(filename, onOverwrite, onRename) {
    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $('<div class="modal-card"></div>');
    const header = $('<div class="modal-header">&#x26A0;&#xFE0F; Datei existiert bereits</div>');
    const closeBtn = $('<button class="modal-close" title="Schließen">x</button>');
    header.append(closeBtn);
    closeBtn.on('click', () => overlay.remove());
    const body = $('<div class="modal-body"></div>');
    body.append($('<p></p>').text('Datei \'' + filename + '\' existiert bereits. Was möchtest du tun?'));
    const renameArea = $('<div style="margin-top:10px;display:none;"></div>');
    const renameInput = $('<input type="text" class="modal-input" placeholder="Neuer Dateiname">');
    const renameConfirm = $('<button class="btn btn-primary" style="margin-top:6px;">Bestätigen</button>');
    renameArea.append(renameInput).append(renameConfirm);
    body.append(renameArea);
    const footer = $('<div class="modal-footer"></div>');
    const btnOverwrite = $('<button class="btn btn-danger">Überschreiben</button>');
    const btnRename = $('<button class="btn btn-secondary">Umbenennen</button>');
    const btnCancel = $('<button class="btn btn-secondary">Abbrechen</button>');
    btnOverwrite.on('click', () => { overlay.remove(); onOverwrite(); });
    btnRename.on('click', () => { renameArea.show(); renameInput.val(filename).focus().select(); footer.hide(); });
    renameConfirm.on('click', () => {
        const newName = renameInput.val().trim();
        if (!newName) { renameInput.focus(); return; }
        overlay.remove(); onRename(newName);
    });
    renameInput.on('keydown', e => { if (e.key === 'Enter') renameConfirm.trigger('click'); });
    btnCancel.on('click', () => overlay.remove());
    footer.append(btnCancel).append(btnRename).append(btnOverwrite);
    card.append(header).append(body).append(footer);
    overlay.append(card);
    $('body').append(overlay);
    overlay.on('click', e => { if (e.target === overlay[0]) overlay.remove(); });
}

async function createFile(isFolder = false) {
    if (currentDirectorySystemBlocked) {
        showSystemBlockedNotice('Dieser Ordner');
        return;
    }
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return customModal({
        title: '⚠️ Eingabe erforderlich',
        message: "Bitte Namen eingeben!"
    });
    const dir = document.getElementById("directoryPath").value.trim();
    const doCreate = (overwrite, newName) => {
        $.post("api.php", JSON.stringify({
            action: "create",
            path: dir,
            fileName: newName || name,
            type: isFolder ? "folder" : "file",
            overwrite: overwrite || false
        }), response => {
            if (response.error && response.error.startsWith("DATEI_EXISTIERT:")) {
                const existName = response.error.replace("DATEI_EXISTIERT:", "");
                _showOverwriteDialog(existName,
                    () => doCreate(true, newName),
                    n => doCreate(false, n)
                );
            } else if (response.error) {
                customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: escHtml(response.error) });
            } else {
                loadFiles();
                document.getElementById(inputId).value = "";
            }
        }, "json").fail(jqXHR => customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: escHtml(jqXHR.responseText) }));
    };
    doCreate(false);
}

function createFolder() {
    createFile(true);
}

// ⬆️ Upload
function uploadFile(event) {
    if (event) event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;

    if (currentDirectorySystemBlocked) {
        showSystemBlockedNotice('Dieser Ordner');
        return;
    }

    let fileToUpload = null;
    if (fileInput.files.length) {
        fileToUpload = fileInput.files[0];
    } else if (window.droppedFile) {
        fileToUpload = window.droppedFile;
    }

    if (!fileToUpload) {
        return customModal({
            title: 'Auswahl erforderlich',
            message: "Bitte w\u00e4hle eine Datei aus."
        });
    }

    const maxSize = 2 * 1024 * 1024 * 1024;
    if (fileToUpload.size > maxSize) {
        return customModal({
            title: 'Datei zu gro\u00df',
            message: `Die Datei "${escHtml(fileToUpload.name)}" ist zu gro\u00df (${(fileToUpload.size / 1024 / 1024 / 1024).toFixed(2)} GB). Das maximale Upload-Limit betr\u00e4gt 2 GB.`
        });
    }

    const progressContainer = document.getElementById("uploadProgressContainer");
    const progressBar = document.getElementById("uploadProgressBar");
    const uploadBtn = document.getElementById("uploadBtn");

    progressContainer.style.display = "block";
    progressBar.style.width = "0%";
    uploadBtn.disabled = true;
    uploadBtn.textContent = "L\u00e4dt...";

    const resetUploadUI = () => {
        progressContainer.style.display = "none";
        progressBar.style.width = "0%";
        uploadBtn.disabled = false;
        uploadBtn.textContent = "Hochladen";
    };

    const doUpload = (opts) => {
        uploadFileInChunks(fileToUpload, path, p => {
            progressBar.style.width = p + '%';
            uploadBtn.textContent = p + '%';
        }, opts).then(message => {
            resetUploadUI();
            customModal({ title: 'Upload-Status', message: escHtml(message) });
            loadFiles();
            fileInput.value = '';
            window.droppedFile = null;
            const lbl = document.getElementById('selectedFileName');
            if (lbl) lbl.textContent = 'Keine Datei ausgewÃ¤hlt oder hier ablegen';
        }).catch(err => {
            resetUploadUI();
            if (err.file_exists) {
                _showOverwriteDialog(err.filename,
                    () => doUpload({ overwrite: true }),
                    newName => doUpload({ renameTo: newName })
                );
            } else {
                customModal({ title: 'Fehler', message: escHtml(err.message || 'Fehler beim Hochladen.') });
            }
        });
    };
    doUpload({});
}

function uploadFileInChunks(file, path, onProgress, opts) {
    opts = opts || {};
    const chunkSize = 8 * 1024 * 1024;
    const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
    const uploadId = `up_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

    return new Promise((resolve, reject) => {
        let chunkIndex = 0;

        const sendNextChunk = () => {
            if (chunkIndex >= totalChunks) {
                resolve(`Datei erfolgreich hochgeladen: ${file.name}`);
                return;
            }

            const start = chunkIndex * chunkSize;
            const end = Math.min(start + chunkSize, file.size);
            const chunk = file.slice(start, end);

            const formData = new FormData();
            formData.append('uploadFile', chunk, file.name);
            formData.append('path', path);
            formData.append('chunkIndex', String(chunkIndex));
            formData.append('totalChunks', String(totalChunks));
            formData.append('uploadId', uploadId);
            formData.append('originalName', file.name);
            formData.append('totalFileSize', String(file.size));
            if (opts.overwrite) formData.append('overwrite', '1');
            if (opts.renameTo) { formData.append('renameTo', opts.renameTo); formData.set('originalName', opts.renameTo); }

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload.php', true);

            xhr.upload.onprogress = function (e) {
                if (!e.lengthComputable) return;
                const chunkFraction = e.total > 0 ? (e.loaded / e.total) : 0;
                const totalProgress = ((chunkIndex + chunkFraction) / totalChunks) * 100;
                onProgress(Math.max(1, Math.min(100, Math.round(totalProgress))));
            };

            xhr.onload = function () {
                if (xhr.status === 409) {
                    try { var r = JSON.parse(xhr.responseText); if (r.file_exists) { var fe = new Error('file_exists'); fe.file_exists = true; fe.filename = r.filename; reject(fe); return; } } catch(ex) {}
                }
                if (xhr.status < 200 || xhr.status >= 300) {
                    reject(new Error(xhr.responseText || `Upload fehlgeschlagen (HTTP ${xhr.status}).`));
                    return;
                }

                chunkIndex += 1;
                onProgress(Math.max(1, Math.min(100, Math.round((chunkIndex / totalChunks) * 100))));
                sendNextChunk();
            };

            xhr.onerror = function () {
                reject(new Error('Netzwerkfehler beim Hochladen.'));
            };

            xhr.send(formData);
        };

        sendNextChunk();
    });
}
// 🧠 Monaco
if (typeof require !== "undefined") {
    require(["vs/editor/editor.main"], function() {
        editor = monaco.editor.create(document.getElementById("editor"), {
            value: "// Warten auf Datei...",
            language: "plaintext",
            theme: darkMode ? "vs-dark" : "vs-light",
            fontSize: 14,
            automaticLayout: true,
            scrollbar: {
                verticalScrollbarSize: 8,
                horizontalScrollbarSize: 8,
                verticalHasArrows: false,
                horizontalHasArrows: false,
                useShadows: false
            }
        });
        
        editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function() {
            saveFile();
        });
    });
}

// 📦 Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");
    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");
    $("#uploadForm").on("submit", uploadFile);
    const dirInput = document.getElementById("directoryPath");
    if (dirInput) {
        dirInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                _navHistory.push(dirInput.value);
                loadFiles();
            }
        });
    }

    document.addEventListener('mousedown', function(e) {
        if (e.button === 3 && _mouseOverTable) {
            e.preventDefault();
            if (_navHistory.length > 0) {
                const prev = _navHistory.pop();
                const di = document.getElementById('directoryPath');
                if (di) { di.value = prev; loadFiles(); }
            }
        }
    }, { capture: true });

    const _tableEl = document.querySelector('.table-responsive');
    if (_tableEl) {
        _tableEl.addEventListener('mouseenter', () => { _mouseOverTable = true; });
        _tableEl.addEventListener('mouseleave', () => { _mouseOverTable = false; });
    }

    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.style.border = '2px dashed var(--primary)';
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
            if (e.dataTransfer.files.length) {
                window.droppedFile = e.dataTransfer.files[0];
                const lbl = document.getElementById('selectedFileName');
                if (lbl) lbl.textContent = window.droppedFile.name;
                uploadFile(); // Auto-upload on drop
            }
        });
    }
});

// Search filter
// ── Datei-Filter ─────────────────────────────────────────────────
const FM_FILE_CATS = {
    video:    ['mp4','webm','mov','avi','mkv','wmv','flv','m4v','ogv'],
    audio:    ['mp3','wav','ogg','flac','aac','m4a','opus','wma'],
    image:    ['png','jpg','jpeg','gif','webp','svg','bmp','ico','tiff','avif'],
    web:      ['html','htm','css','js','ts','tsx','jsx','php','vue','svelte','aspx','jsp','py','rb','sh','go','rs','java','c','cpp','cs'],
    document: ['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','rtf','odt','ods'],
    archive:  ['zip','rar','tar','gz','7z','bz2','xz','br'],
    folder:   ['__folder__']
};

window._activeFileFilter = 'all';

function _getExt(name) {
    var p = name.lastIndexOf('.');
    return p >= 0 ? name.slice(p + 1).toLowerCase() : '';
}

function setFileFilter(cat) {
    window._activeFileFilter = cat;
    document.querySelectorAll('.filter-chip').forEach(function(el) {
        el.classList.toggle('active', el.dataset.filter === cat);
    });
    if (cat === 'all') {
        // Normale Ansicht wiederherstellen
        loadFiles();
    } else {
        _runSearchFilter(cat);
    }
}
window.setFileFilter = setFileFilter;

function _runSearchFilter(cat) {
    var dirInput = document.getElementById('directoryPath');
    if (!dirInput) return;
    var dir = dirInput.value.trim();
    if (!dir) return;

    var exts = (FM_FILE_CATS[cat] || []).join(',');
    var tbody = document.getElementById('fileTable');
    if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:var(--text-muted);">🔍 Suche...</td></tr>';

    $.getJSON('api.php?action=search&dir=' + encodeURIComponent(dir) + '&exts=' + encodeURIComponent(exts), function(data) {
        if (!tbody) return;
        if (data.error) {
            tbody.innerHTML = '<tr><td colspan="6" style="color:var(--danger);padding:12px;">' + data.error + '</td></tr>';
            return;
        }
        var files = data.files || [];
        if (files.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:var(--text-muted);">Keine Dateien gefunden.</td></tr>';
            return;
        }
        var html = '';
        for (var i = 0; i < files.length; i++) {
            var f = files[i];
            var icon = getFileIcon(f.name, f.type);
            var folderBadge = '';
            if (f.folder) {
                var fPath = encodeURIComponent(data.base + '/' + f.folder);
                folderBadge = ' <span class="search-folder-badge" onclick="setFileFilter(\'all\'); navigateToFolder(\'' + f.folder.replace(/'/g, "\\'") + '\', data.base);" title="In Ordner navigieren">&#128193; ' + escHtml(f.folder) + ' &rsaquo;</span>';
            }
            html += '<tr data-type="' + escHtml(f.type) + '" data-name="' + escHtml(f.name) + '" data-path="' + escHtml(data.base + (f.folder ? '/' + f.folder : '') + '/' + f.name) + '">'
                  + '<td style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:0;" title="' + escHtml(f.name) + '">'
                  + icon + ' ' + escHtml(f.name) + '</td>'
                  + '<td>' + (f.folder ? '<span class="search-folder-badge" onclick="navigateToFolder(\'' + f.folder.replace(/'/g, "\\'") + '\', \'' + escHtml(data.base).replace(/'/g, "\\'") + '\')">&#128193; ' + escHtml(f.folder) + ' &rsaquo;</span>' : '<span style="color:var(--text-muted);font-size:11px;">/ (Wurzel)</span>') + '</td>'
                  + '<td>' + escHtml(f.type) + '</td>'
                  + '<td>' + escHtml(f.sizeFormatted) + '</td>'
                  + '<td>' + escHtml(f.date) + '</td>'
                  + '<td></td>'
                  + '</tr>';
        }
        tbody.innerHTML = html;
    }).fail(function() {
        if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="color:var(--danger);padding:12px;">Fehler bei der Suche.</td></tr>';
    });
}
window._runSearchFilter = _runSearchFilter;

function navigateToFolder(relFolder, base) {
    var dirInput = document.getElementById('directoryPath');
    if (dirInput) {
        dirInput.value = base.replace(/[/\\]+$/, '') + '/' + relFolder;
    }
    setFileFilter('all');
}
window.navigateToFolder = navigateToFolder;

function filterTable() {
    var term = document.getElementById('searchInput').value.toLowerCase();
    if (!term) return;
    $('#fileTable tr').each(function() {
        var rowText = $(this).text().toLowerCase();
        $(this).toggle(rowText.indexOf(term) >= 0);
    });
}
window.filterTable = filterTable;

// Global Ctrl-S handler
document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        const editModal = document.getElementById("editModal");
        if (editModal && !editModal.classList.contains("hidden")) {
            saveFile();
        }
    }
});

// ── Mein Konto / 2FA-Verwaltung für normale Nutzer ───────────────────────────
function _profileTheme() {
    const dark = document.body.classList.contains('dark-mode');
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim() || '#3b82f6';
    const m = accent.match(/^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
    const accentBg = m
        ? `rgba(${parseInt(m[1],16)},${parseInt(m[2],16)},${parseInt(m[3],16)},${dark ? 0.22 : 0.13})`
        : (dark ? 'rgba(59,130,246,0.22)' : 'rgba(59,130,246,0.13)');
    return {
        dark,
        accent,
        accentBg,
        panel:       dark ? '#1e293b'                    : '#f8fafc',
        border:      dark ? '1px solid rgba(255,255,255,0.1)' : '1px solid #e2e8f0',
        headerBorder:dark ? 'rgba(255,255,255,0.08)'    : '#e2e8f0',
        closeColor:  dark ? '#94a3b8'                   : '#64748b',
        inputBg:     dark ? 'rgba(0,0,0,0.3)'           : '#fff',
        inputColor:  dark ? 'white'                     : '#1e293b',
        inputBorder: dark ? 'rgba(255,255,255,0.1)'     : '#cbd5e1',
        mutedColor:  dark ? '#94a3b8'                   : '#64748b',
        subpanelBg:  dark ? 'rgba(255,255,255,0.04)'    : 'rgba(0,0,0,0.03)',
        codeBg:      dark ? 'rgba(0,0,0,0.3)'           : '#f1f5f9',
    };
}

async function showMyProfile() {
    // Recreate on each open so theme changes apply immediately
    const old = document.getElementById('myProfileOverlay');
    if (old) old.remove();

    const t = _profileTheme();
    const overlay = document.createElement('div');
    overlay.id = 'myProfileOverlay';
    overlay.style.cssText = `position:fixed;inset:0;background:${t.dark ? 'rgba(0,0,0,0.75)' : 'rgba(0,0,0,0.4)'};z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;`;
    overlay.innerHTML = `
        <div style="background:${t.panel};border-radius:16px;border:${t.border};width:100%;max-width:480px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:20px 24px;border-bottom:1px solid ${t.headerBorder};flex-shrink:0;">
                <h2 style="margin:0;font-size:18px;">👤 Mein Konto</h2>
                <button onclick="document.getElementById('myProfileOverlay').remove()" style="background:none;border:none;color:${t.closeColor};font-size:22px;cursor:pointer;line-height:1;">✕</button>
            </div>
            <div style="display:flex;gap:4px;padding:10px 16px;border-bottom:1px solid ${t.headerBorder};flex-shrink:0;">
                <button id="profileTabSecurity" onclick="_switchProfileTab('security')"
                    style="flex:1;padding:8px 10px;border-radius:8px;border:none;cursor:pointer;font-size:13px;font-weight:500;transition:all 0.2s;background:${t.accentBg};color:${t.accent};">🔐 Sicherheit</button>
                <button id="profileTabDesign" onclick="_switchProfileTab('design')"
                    style="flex:1;padding:8px 10px;border-radius:8px;border:none;cursor:pointer;font-size:13px;font-weight:500;transition:all 0.2s;background:transparent;color:${t.mutedColor};">🎨 Design</button>
            </div>
            <div id="myProfileBody" style="overflow-y:auto;flex:1;padding:24px;">
                <div style="text-align:center;padding:30px;opacity:0.6;">Wird geladen…</div>
            </div>
        </div>`;
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    document.body.appendChild(overlay);

    await _loadProfileBody();
}

async function _loadProfileBody() {
    const body = document.getElementById('myProfileBody');
    if (!body) return;
    try {
        const res = await fetch('api.php?action=my_2fa_get_secret', { credentials: 'same-origin' });
        const data = await res.json();
        if (data.error) {
            body.innerHTML = `<div style="color:#f87171;padding:20px;text-align:center;">${escHtml(data.error)}</div>`;
            return;
        }
        if (data.has2fa) {
            _renderProfile2FAActive(body);
        } else {
            _renderProfile2FASetup(body, data.uri, data.secret);
        }
    } catch (e) {
        body.innerHTML = '<div style="color:#f87171;padding:20px;text-align:center;">Fehler beim Laden.</div>';
    }
}

function _renderProfile2FAActive(body) {
    const t = _profileTheme();
    const req2fa = !!(window.PW_POLICY && window.PW_POLICY.require2fa);
    const disableSection = req2fa
        ? `<div style="font-size:12px;color:${t.mutedColor};padding:10px 12px;background:rgba(0,0,0,0.2);border-radius:8px;border:1px solid rgba(255,255,255,0.06);">🔒 2FA ist vom Administrator für alle Benutzer erzwungen und kann nicht deaktiviert werden.</div>`
        : `<div style="margin-bottom:12px;">
            <label style="color:${t.mutedColor};font-size:12px;display:block;margin-bottom:6px;">Passwort zur Bestätigung</label>
            <input type="password" id="profile2faDisablePw" placeholder="Dein aktuelles Passwort"
                style="width:100%;padding:10px;border-radius:8px;background:${t.inputBg};color:${t.inputColor};border:1px solid ${t.inputBorder};box-sizing:border-box;">
        </div>
        <button onclick="profileDisable2FA()" class="btn btn-danger" style="width:100%;">🔓 2FA deaktivieren</button>`;
    body.innerHTML = `
        <div style="margin-bottom:20px;padding:16px;background:rgba(16,185,129,0.1);border-radius:10px;border:1px solid rgba(16,185,129,0.3);">
            <div style="color:#10b981;font-weight:500;margin-bottom:4px;">✅ 2FA ist aktiv</div>
            <div style="font-size:12px;color:${t.mutedColor};">Dein Account ist mit Zwei-Faktor-Authentifizierung gesichert.</div>
        </div>
        ${disableSection}`;
}

function _renderProfile2FASetup(body, qrUri, secret) {
    const t = _profileTheme();
    const qrSection = qrUri ? `
        <div style="text-align:center;margin-bottom:16px;">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(qrUri)}"
                 style="border-radius:8px;border:3px solid ${t.dark ? 'white' : '#cbd5e1'};" width="180" height="180" alt="QR-Code">
        </div>
        <div style="margin-bottom:16px;padding:12px;background:${t.codeBg};border-radius:8px;text-align:center;border:1px solid ${t.inputBorder};">
            <div style="font-size:11px;color:${t.mutedColor};margin-bottom:4px;">Manueller Code</div>
            <code style="font-size:13px;letter-spacing:2px;">${escHtml(secret || '')}</code>
        </div>` : `
        <div style="margin-bottom:16px;padding:16px;background:${t.subpanelBg};border-radius:10px;border:1px solid ${t.inputBorder};">
            <div style="font-size:13px;color:${t.mutedColor};">2FA ist noch nicht aktiviert. Scanne den QR-Code mit deiner Authenticator-App und bestätige mit einem Code.</div>
        </div>`;
    body.innerHTML = `
        <div style="margin-bottom:20px;padding:12px 16px;background:${t.accentBg};border-radius:10px;border:1px solid ${t.accent}40;">
            <div style="font-size:13px;color:${t.accent};font-weight:500;">🔐 Zwei-Faktor-Authentifizierung einrichten</div>
        </div>
        ${qrSection}
        <div style="margin-bottom:12px;">
            <label style="color:${t.mutedColor};font-size:12px;display:block;margin-bottom:6px;">Code aus der Authenticator-App eingeben</label>
            <input type="text" id="profile2faCode" maxlength="6" placeholder="000000" inputmode="numeric"
                style="width:100%;padding:10px;border-radius:8px;background:${t.inputBg};color:${t.inputColor};border:1px solid ${t.inputBorder};box-sizing:border-box;text-align:center;letter-spacing:4px;font-size:18px;">
        </div>
        <button onclick="profileConfirm2FA()" class="btn btn-success" style="width:100%;">✅ 2FA aktivieren</button>`;
}

async function profileConfirm2FA() {
    const code = (document.getElementById('profile2faCode')?.value || '').trim();
    if (!/^\d{6}$/.test(code)) {
        await customModal({ title: '⚠️ Ungültig', message: 'Bitte einen 6-stelligen Code eingeben.' });
        return;
    }
    try {
        const fd = new FormData();
        fd.append('action', 'my_2fa_confirm');
        fd.append('code', code);
        const res = await fetch('api.php', { method: 'POST', credentials: 'same-origin', body: fd });
        const data = await res.json();
        if (data.success) {
            await customModal({ title: '✅ Erfolg', message: '2FA wurde erfolgreich aktiviert.' });
            _loadProfileBody();
        } else {
            await customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: data.error || 'Code ungültig oder abgelaufen.' });
        }
    } catch (e) {
        await customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: 'Verbindungsfehler.' });
    }
}

async function profileDisable2FA() {
    const pw = (document.getElementById('profile2faDisablePw')?.value || '').trim();
    if (!pw) {
        await customModal({ title: '⚠️ Hinweis', message: 'Bitte zuerst dein Passwort eingeben.' });
        return;
    }
    const ok = await customModal({ title: '🔓 2FA deaktivieren', message: '2FA wirklich deaktivieren?', type: 'confirm', confirmText: 'Ja, deaktivieren', cancelText: 'Abbrechen' });
    if (!ok) return;
    try {
        const fd = new FormData();
        fd.append('action', 'my_2fa_disable');
        fd.append('password', pw);
        const res = await fetch('api.php', { method: 'POST', credentials: 'same-origin', body: fd });
        const data = await res.json();
        if (data.success) {
            await customModal({ title: '✅ Deaktiviert', message: '2FA wurde deaktiviert.' });
            _loadProfileBody();
        } else {
            await customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: data.error || 'Passwort falsch oder Fehler aufgetreten.' });
        }
    } catch (e) {
        await customModal({ title: '<i class="bi bi-x-circle"></i> Fehler', message: 'Verbindungsfehler.' });
    }
}


// ── Personalisierung / Akzentfarbe ────────────────────────────────────────────
const FM_ACCENT_SWATCHES = [
    ['#3b82f6', '#2563eb', 'Blau (Standard)'],
    ['#0ea5e9', '#0284c7', 'Himmelblau'],
    ['#06b6d4', '#0891b2', 'Cyan'],
    ['#14b8a6', '#0d9488', 'Türkis'],
    ['#10b981', '#059669', 'Smaragd'],
    ['#22c55e', '#16a34a', 'Grün'],
    ['#84cc16', '#65a30d', 'Limette'],
    ['#eab308', '#ca8a04', 'Gelb'],
    ['#f97316', '#ea580c', 'Orange'],
    ['#ef4444', '#dc2626', 'Rot'],
    ['#f43f5e', '#e11d48', 'Rose'],
    ['#ec4899', '#db2777', 'Pink'],
    ['#8b5cf6', '#7c3aed', 'Violett'],
    ['#6366f1', '#4f46e5', 'Indigo'],
    ['#a855f7', '#9333ea', 'Lila'],
    ['#64748b', '#475569', 'Schiefer'],
];

function _darkenHex(hex, amount) {
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(function(c) { return c + c; }).join('');
    const r = Math.max(0, Math.round(parseInt(h.substr(0, 2), 16) * (1 - amount)));
    const g = Math.max(0, Math.round(parseInt(h.substr(2, 2), 16) * (1 - amount)));
    const b = Math.max(0, Math.round(parseInt(h.substr(4, 2), 16) * (1 - amount)));
    return '#' + [r, g, b].map(function(v) { return v.toString(16).padStart(2, '0'); }).join('');
}

function _applyAccentColor(color, hover) {
    if (!hover) hover = _darkenHex(color, 0.15);
    document.documentElement.style.setProperty('--primary', color);
    document.documentElement.style.setProperty('--primary-hover', hover);
    localStorage.setItem('fm_accent_color', color);
    localStorage.setItem('fm_accent_hover', hover);
}

function _loadSavedAccentColor() {
    const color = localStorage.getItem('fm_accent_color');
    const hover = localStorage.getItem('fm_accent_hover');
    if (color) {
        document.documentElement.style.setProperty('--primary', color);
        if (hover) document.documentElement.style.setProperty('--primary-hover', hover);
    }
}
_loadSavedAccentColor();

function _selectAccentSwatch(color, hover) {
    _applyAccentColor(color, hover);
    _renderPersonalization(document.getElementById('myProfileBody'));
}

function _accentHexChange() {
    const inp = document.getElementById('accentHexInput');
    const val = inp ? inp.value.trim() : '';
    const preview = document.getElementById('accentPreview');
    if (/^#[0-9a-f]{6}$/i.test(val) && preview) preview.style.background = val;
}

function _applyCustomAccent() {
    const inp = document.getElementById('accentHexInput');
    const val = inp ? inp.value.trim() : '';
    if (!/^#[0-9a-f]{6}$/i.test(val)) {
        customModal({ title: '⚠️ Ungültig', message: 'Bitte einen gültigen Hex-Code eingeben (z.B. #3b82f6).' });
        return;
    }
    _applyAccentColor(val);
    _renderPersonalization(document.getElementById('myProfileBody'));
}

function _resetAccentColor() {
    _applyAccentColor('#3b82f6', '#2563eb');
    _renderPersonalization(document.getElementById('myProfileBody'));
}

function _switchProfileTab(tab) {
    const t = _profileTheme();
    const secBtn = document.getElementById('profileTabSecurity');
    const desBtn = document.getElementById('profileTabDesign');
    const body = document.getElementById('myProfileBody');
    const setActive = function(btn) { btn.style.background = t.accentBg; btn.style.color = t.accent; };
    const setInactive = function(btn) { btn.style.background = 'transparent'; btn.style.color = t.mutedColor; };
    if (tab === 'security') { setActive(secBtn); setInactive(desBtn); _loadProfileBody(); }
    else { setActive(desBtn); setInactive(secBtn); _renderPersonalization(body); }
}

function _renderPersonalization(body) {
    if (!body) return;
    const t = _profileTheme();
    const current = (localStorage.getItem('fm_accent_color') || '#3b82f6').toLowerCase();
    const swatchesHtml = FM_ACCENT_SWATCHES.map(function(item) {
        const c = item[0], h = item[1], label = item[2];
        const active = c.toLowerCase() === current;
        const shadow = active
            ? ('0 0 0 2px ' + (t.dark ? '#1e293b' : '#ffffff') + ',0 0 0 4px ' + c)
            : '0 2px 8px rgba(0,0,0,0.35)';
        const outerStyle = [
            'width:42px', 'height:42px', 'border-radius:50%',
            'background:' + c, 'cursor:pointer', 'position:relative',
            'transition:transform 0.15s,box-shadow 0.15s',
            'box-shadow:' + shadow,
            'transform:' + (active ? 'scale(1.15)' : 'scale(1)'),
            'flex-shrink:0'
        ].join(';') + ';';
        const check = active
            ? '<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:white;font-size:16px;font-weight:700;text-shadow:0 1px 3px rgba(0,0,0,0.6);">✓</span>'
            : '';
        return '<div onclick="_selectAccentSwatch(\'' + c + '\',\'' + h + '\')" title="' + label + '" style="' + outerStyle + '">' + check + '</div>';
    }).join('');
    body.innerHTML =
        '<div style="font-size:13px;font-weight:600;color:' + (t.dark ? '#e2e8f0' : '#1e293b') + ';margin-bottom:4px;">Akzentfarbe</div>' +
        '<div style="font-size:12px;color:' + t.mutedColor + ';margin-bottom:16px;">Farbe für Buttons und interaktive Elemente.</div>' +
        '<div style="display:grid;grid-template-columns:repeat(8,42px);gap:12px;margin-bottom:24px;">' + swatchesHtml + '</div>' +
        '<div style="height:1px;background:' + t.inputBorder + ';margin-bottom:16px;"></div>' +
        '<div style="font-size:12px;color:' + t.mutedColor + ';font-weight:500;margin-bottom:8px;">Eigener Hex-Code</div>' +
        '<div style="display:flex;gap:8px;align-items:center;margin-bottom:20px;">' +
            '<div id="accentPreview" style="width:38px;height:38px;border-radius:8px;background:' + current + ';flex-shrink:0;border:1px solid ' + t.inputBorder + ';transition:background 0.2s;"></div>' +
            '<input id="accentHexInput" type="text" value="' + current + '" maxlength="7" placeholder="#3b82f6" oninput="_accentHexChange()"' +
            ' style="flex:1;padding:9px 12px;border-radius:8px;background:' + t.inputBg + ';color:' + t.inputColor + ';border:1px solid ' + t.inputBorder + ';font-size:14px;font-family:monospace;box-sizing:border-box;">' +
            '<button onclick="_applyCustomAccent()" class="btn btn-primary" style="padding:9px 14px;font-size:13px;white-space:nowrap;">Übernehmen</button>' +
        '</div>' +
        '<button onclick="_resetAccentColor()" style="width:100%;background:none;border:1px solid ' + t.inputBorder + ';color:' + t.mutedColor + ';border-radius:8px;padding:9px;cursor:pointer;font-size:13px;transition:border-color 0.2s,color 0.2s;">↺ Standard zurücksetzen</button>';
}
// ── Kontextmenü (Rechtsklick) ──────────────────────────────────────────────────
let _ctxMenu = null;

function _closeCtx() {
    if (_ctxMenu) { _ctxMenu.remove(); _ctxMenu = null; }
}

document.addEventListener('click', _closeCtx);
document.addEventListener('keydown', e => { if (e.key === 'Escape') _closeCtx(); });

function _buildCtxMenu(items) {
    _closeCtx();
    const dark = document.body.classList.contains('dark-mode');
    const menu = document.createElement('div');
    menu.id = 'fm-ctx-menu';
    menu.style.cssText = [
        'position:fixed', 'z-index:9990', 'min-width:200px', 'padding:5px 0',
        'border-radius:10px', 'box-shadow:0 8px 32px rgba(0,0,0,0.4)',
        `background:${dark ? '#1e293b' : '#ffffff'}`,
        `border:1px solid ${dark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}`,
        'user-select:none'
    ].join(';');

    items.forEach(item => {
        if (item === '---') {
            const hr = document.createElement('div');
            hr.style.cssText = 'margin:4px 8px; height:1px; background:rgba(128,128,128,0.2);';
            menu.appendChild(hr);
            return;
        }
        const el = document.createElement('div');
        el.style.cssText = [
            'padding:9px 16px', 'cursor:pointer', 'font-size:13px',
            'display:flex', 'align-items:center', 'gap:9px',
            `color:${item.danger ? '#f87171' : (dark ? '#e2e8f0' : '#1e293b')}`,
            'transition:background 0.12s', 'border-radius:6px', 'margin:0 3px'
        ].join(';');
        el.innerHTML = `<span style="width:18px;text-align:center;">${item.icon}</span><span>${item.label}</span>`;
        el.addEventListener('mouseenter', () => { el.style.background = dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.07)'; });
        el.addEventListener('mouseleave', () => { el.style.background = 'transparent'; });
        if (item.disabled) {
            el.style.opacity = '0.4';
            el.style.cursor = 'default';
        } else {
            el.addEventListener('click', () => { _closeCtx(); item.action(); });
        }
        menu.appendChild(el);
    });

    document.body.appendChild(menu);
    _ctxMenu = menu;
    return menu;
}

function _showCtxAt(e, items) {
    const menu = _buildCtxMenu(items);
    const mw = 210, mh = items.filter(i => i !== '---').length * 38 + items.filter(i => i === '---').length * 13 + 10;
    let x = e.clientX + 4, y = e.clientY + 2;
    if (x + mw > window.innerWidth - 8) x = window.innerWidth - mw - 8;
    if (y + mh > window.innerHeight - 8) y = window.innerHeight - mh - 8;
    if (y < 8) y = 8;
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
}

function showFileContextMenu(e, file, fullPath, isFolder) {
    const isBlocked = !!file.isSystemBlocked;
    const canPreview = !isFolder && isMediaFile(file.name);
    const items = [];

    if (isFolder) {
        items.push({ icon: '📂', label: 'Öffnen', action: () => openFolderByPath(encodeURIComponent(file.name)) });
        items.push('---');
    } else {
        if (canPreview) {
            items.push({ icon: '👁️', label: 'Vorschau', action: () => showMediaViewer(file, fullPath) });
        }
        items.push({ icon: '✏️', label: 'Bearbeiten', disabled: isBlocked, action: () => handleEditAction(file, fullPath) });
        items.push({ icon: '⬇️', label: 'Herunterladen', action: () => {
            const a = document.createElement('a');
            a.href = `download.php?path=${encodeURIComponent(fullPath)}`;
            a.download = file.name;
            document.body.appendChild(a); a.click(); a.remove();
        }});
        items.push('---');
    }

    items.push({ icon: '📋', label: 'Kopieren nach…', disabled: isBlocked, action: () => showCopyMoveDialog('copy', file, fullPath) });
    items.push({ icon: '✂️', label: 'Verschieben nach…', disabled: isBlocked, action: () => showCopyMoveDialog('move', file, fullPath) });
    items.push({ icon: '📄', label: 'Umbenennen', disabled: isBlocked, action: () => renameFile(file.name) });
    items.push('---');
    items.push({ icon: '🗑️', label: 'Löschen', danger: true, disabled: isBlocked, action: () => deleteFile(file.name) });

    _showCtxAt(e, items);
}

function showCopyMoveDialog(mode, file, srcPath) {
    const isCopy = mode === 'copy';
    const title = isCopy ? '📋 Kopieren nach' : '✂️ Verschieben nach';
    const apiAction = isCopy ? 'copy_file' : 'move_file';
    const btnLabel = isCopy ? 'Kopieren' : 'Verschieben';
    const currentDir = document.getElementById('directoryPath').value.trim();

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:480px;">
            <div class="modal-header">${title}: ${escHtml(file.name)}
                <button class="modal-close" type="button">✕</button>
            </div>
            <div class="modal-body">
                <label style="display:block; margin-bottom:6px; font-size:13px; color:#94a3b8;">Zielpfad (vollständiger Serverpfad)</label>
                <div id="cm-dest-wrap" style="display:flex; align-items:stretch; margin-top:10px;">
                    <span id="cm-dest-prefix" style="display:none; padding:0 10px; background:rgba(0,0,0,0.25); border:1px solid rgba(255,255,255,0.1); border-right:none; border-radius:8px 0 0 8px; font-size:13px; white-space:nowrap; flex-shrink:0; opacity:0.75; align-items:center;"></span>
                    <input type="text" id="cm-dest" class="modal-input" placeholder="Zielpfad eingeben…" value="${escHtml(currentDir)}" style="flex:1; margin-top:0;">
                </div>
                <p style="font-size:12px; opacity:0.6; margin-top:8px;">Tipp: Den aktuellen Pfad aus dem Pfadfeld oben kopieren und anpassen.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="cm-cancel">Abbrechen</button>
                <button type="button" class="btn btn-primary" id="cm-ok">${btnLabel}</button>
            </div>
        </div>
    `);
    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    overlay.on('click', e => { if (e.target === overlay[0]) close(); });
    card.find('.modal-close, #cm-cancel').on('click', close);

    // basePath prefix-lock for regular users
    const destInput  = card.find('#cm-dest');
    const destPrefix = card.find('#cm-dest-prefix');
    let effectiveBasePath = null;
    if (!window.isSystemAdmin && typeof basePath !== 'undefined' && basePath) {
        effectiveBasePath = basePath.replace(/\/$/, '');
        destPrefix.text(effectiveBasePath + '/').css({ display: 'flex', 'align-items': 'center' });
        destInput.css({ 'border-radius': '0 8px 8px 0' });
        const rel = currentDir.startsWith(effectiveBasePath) ? currentDir.slice(effectiveBasePath.length) : '';
        destInput.val(rel.replace(/^\//, '') || '');
    } else {
        destInput[0].select();
    }

    const getDestPath = () => {
        const v = destInput.val().trim();
        if (effectiveBasePath) {
            return effectiveBasePath + '/' + v.replace(/^\/+/, '');
        }
        return v;
    };

    const showLoading = () => {
        card.find('.modal-footer').html(
            `<div style="display:flex;align-items:center;gap:10px;justify-content:center;width:100%;padding:2px 0;">` +
            `<div class="fm-spinner"></div>` +
            `<span style="font-size:13px;color:#94a3b8;">${mode === 'copy' ? 'Wird kopiert…' : 'Wird verschoben…'}</span>` +
            `</div>`
        );
    };

    const restoreOkBtn = () => {
        card.find('.modal-footer').html(
            `<button type="button" class="btn btn-primary" id="cm-ok">${btnLabel}</button>`
        );
        card.find('#cm-ok').on('click', () => {
            const d = getDestPath();
            if (!d) { destInput.focus(); return; }
            doAction(d, false, null);
        });
    };

    const doAction = (dest, overwrite, renameTo) => {
        showLoading();
        const payload = { action: apiAction, path: srcPath, dest_dir: dest };
        if (overwrite) payload.overwrite = true;
        if (renameTo)  payload.rename_to = renameTo;
        $.ajax({
            url: 'api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(payload),
            success: res => {
                if (res.file_exists) {
                    restoreOkBtn();
                    const fn = escHtml(res.filename || '');
                    if (!card.find('#cm-conflict').length) {
                        card.find('.modal-body').append(
                            `<div id="cm-conflict" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;padding:10px 14px;margin-top:12px;font-size:13px;color:#f87171;">` +
                            `<i class="bi bi-exclamation-triangle"></i> <b>${fn}</b> existiert bereits im Zielordner.</div>`
                        );
                    }
                    card.find('.modal-footer').html(
                        `<button type="button" class="btn btn-secondary" id="cm-conflict-cancel">Abbrechen</button>` +
                        `<button type="button" class="btn btn-warning" id="cm-conflict-rename"><i class="bi bi-pencil"></i> Umbenennen</button>` +
                        `<button type="button" class="btn btn-danger" id="cm-conflict-overwrite"><i class="bi bi-arrow-repeat"></i> Überschreiben</button>`
                    );
                    card.find('#cm-conflict-cancel').on('click', close);
                    card.find('#cm-conflict-overwrite').on('click', () => doAction(dest, true, null));
                    card.find('#cm-conflict-rename').on('click', async () => {
                        const newName = await customModal({
                            title: 'Umbenennen',
                            message: 'Gib einen neuen Dateinamen für das Ziel ein:',
                            type: 'prompt',
                            defaultValue: res.filename || ''
                        });
                        if (newName && newName.trim()) doAction(dest, false, newName.trim());
                    });
                    return;
                }
                close();
                if (res.error) {
                    customModal({ title: 'Fehler', message: escHtml(res.error) });
                } else {
                    customModal({ title: 'Fertig', message: escHtml(res.success || 'Fertig.') });
                    loadFiles();
                }
            },
            error: () => {
                close();
                customModal({ title: 'Fehler', message: 'Netzwerkfehler.' });
            }
        });
    };

    destInput.on('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); card.find('#cm-ok').trigger('click'); } });

    card.find('#cm-ok').on('click', () => {
        const dest = getDestPath();
        if (!dest) { destInput.focus(); return; }
        doAction(dest, false, null);
    });
}

window.showMyProfile = showMyProfile;
window.profileConfirm2FA = profileConfirm2FA;
window.profileDisable2FA = profileDisable2FA;

window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.showTrashManager = showTrashManager;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "text" ? "🙈" : "👁️";
}



