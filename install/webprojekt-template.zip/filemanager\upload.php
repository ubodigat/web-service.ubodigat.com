<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    exit('Fehler: Konfigurationsdateien fehlen.');
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    exit('Fehler: Zugriff verweigert.');
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    exit('Fehler: Sitzung abgelaufen.');
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Konfiguration & Admin Check
$baseDir = realpath(__DIR__ . '/..');
if ($baseDir === false) {
    http_response_code(500);
    exit('Fehler: Basisverzeichnis nicht erreichbar (Server-Config Fehler).');
}
$isAdmin = !empty($_SESSION['admin_access']);

$maxUploadSize = 2 * 1024 * 1024 * 1024; // 2 GB
$maxUploadSizeLabel = '2 GB';

function canUploadToPath(string $path, string $baseDir, bool $isAdmin): bool
{
    if ($isAdmin) {
        return true;
    }

    $relPath = $path;
    if (strpos($relPath, $baseDir) === 0) {
        $relPath = substr($relPath, strlen($baseDir));
    }
    $relPath = str_replace('\\', '/', $relPath);
    $relPath = trim($relPath, '/');

    $canUpload = defined('USER_CAN_UPLOAD') ? USER_CAN_UPLOAD : true;
    $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];

    $bestMatch = '';
    foreach ($folderPerms as $p => $rules) {
        if ($relPath === $p || (strpos($relPath, $p . '/') === 0)) {
            if (strlen($p) >= strlen($bestMatch)) {
                $bestMatch = $p;
            }
        }
    }

    if ($bestMatch !== '' && isset($folderPerms[$bestMatch])) {
        $canUpload = isset($folderPerms[$bestMatch]['upload']) ? $folderPerms[$bestMatch]['upload'] : $canUpload;
    }

    return $canUpload;
}

function validateExtension(string $filename, bool $isAdmin): void
{
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    $globalBlocked = ['phar', 'pl', 'py', 'cgi'];
    if (in_array($extension, $globalBlocked, true)) {
        http_response_code(403);
    exit("Fehler: Sicherheitswarnung: Skript-Dateien (.$extension) sind strikt verboten.");
    }

    $userBlocked = ['exe', 'sh', 'bat', 'cmd', 'htaccess', 'env', 'ini', 'sql'];
    if (!$isAdmin && in_array($extension, $userBlocked, true)) {
        http_response_code(403);
    exit("Fehler: Dateityp .$extension ist für normale Benutzer nicht erlaubt.");
    }
}

function validateMime(string $path): void
{
    if (!class_exists('finfo')) {
        return;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($path);

    $blockedMimes = [
        'application/x-php',
        'text/x-php',
        'application/x-httpd-php',
        'application/x-sh',
        'application/x-csh'
    ];

    if (in_array($mime, $blockedMimes, true)) {
        http_response_code(403);
    exit('Fehler: Unerlaubter Datei-Inhalt erkannt (MIME-Check).');
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Fehler: Ungültige Anfrage-Methode.');
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > 0 && empty($_POST) && empty($_FILES)) {
    http_response_code(413);
    exit("Fehler: Die Anfrage überschreitet das maximale Upload-Limit von {$maxUploadSizeLabel}. Bitte lade eine Datei bis maximal {$maxUploadSizeLabel} hoch.");
}

if (!isset($_POST['path']) || !isset($_FILES['uploadFile'])) {
    http_response_code(400);
    exit('Fehler: Kein Datei-Upload empfangen.');
}

$targetPathRaw = (string) $_POST['path'];
$targetDir = realpath($targetPathRaw);
if ($targetDir === false || !is_dir($targetDir)) {
    http_response_code(400);
    exit('Fehler: Zielverzeichnis existiert nicht.');
}

if (!$isAdmin && strpos($targetDir, $baseDir) !== 0) {
    http_response_code(403);
    exit('Fehler: Zugriff verweigert: Upload außerhalb des Projektordners verboten.');
}

if (!canUploadToPath($targetDir, $baseDir, $isAdmin)) {
    http_response_code(403);
    exit('Fehler: Zugriff verweigert (Upload in diesen Ordner nicht erlaubt).');
}

$uploadError = $_FILES['uploadFile']['error'] ?? UPLOAD_ERR_NO_FILE;
if ($uploadError !== UPLOAD_ERR_OK) {
    switch ($uploadError) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            http_response_code(413);
    exit("Fehler: Die Datei überschreitet das maximale Upload-Limit von {$maxUploadSizeLabel}. Bitte lade eine kleinere Datei hoch.");
        case UPLOAD_ERR_PARTIAL:
            http_response_code(400);
    exit('Fehler: Die Datei wurde nur teilweise hochgeladen. Bitte versuche es erneut.');
        case UPLOAD_ERR_NO_FILE:
            http_response_code(400);
    exit('Fehler: Es wurde keine Datei zum Hochladen ausgewählt.');
        default:
            http_response_code(500);
    exit('Fehler: Unbekannter Upload-Fehler (Code: ' . $uploadError . ').');
    }
}

$file = $_FILES['uploadFile'];

$chunkIndexRaw = $_POST['chunkIndex'] ?? null;
$totalChunksRaw = $_POST['totalChunks'] ?? null;
$uploadIdRaw = $_POST['uploadId'] ?? null;
$originalNameRaw = $_POST['originalName'] ?? ($file['name'] ?? 'upload.bin');
$totalFileSizeRaw = $_POST['totalFileSize'] ?? null;

$isChunkUpload = $chunkIndexRaw !== null && $totalChunksRaw !== null && $uploadIdRaw !== null;

$safeFilename = preg_replace('/[^a-zA-Z0-9_\-.]/', '_', basename((string) $originalNameRaw));
if ($safeFilename === '' || $safeFilename === '.' || $safeFilename === '..') {
    http_response_code(400);
    exit('Fehler: Ungültiger Dateiname.');
}
validateExtension($safeFilename, $isAdmin);

$finalPath = $targetDir . DIRECTORY_SEPARATOR . $safeFilename;

if ($isChunkUpload) {
    $chunkIndex = filter_var($chunkIndexRaw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    $totalChunks = filter_var($totalChunksRaw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $totalFileSize = ($totalFileSizeRaw !== null)
        ? filter_var($totalFileSizeRaw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]])
        : null;

    if ($chunkIndex === false || $totalChunks === false || $chunkIndex >= $totalChunks) {
        http_response_code(400);
    exit('Fehler: Ungültige Chunk-Parameter.');
    }

    if ($totalFileSize !== null && $totalFileSize !== false && $totalFileSize > $maxUploadSize) {
        http_response_code(413);
    exit("Fehler: Die Datei ist zu groß (Max. {$maxUploadSizeLabel}). Bitte lade eine kleinere Datei hoch.");
    }

    $uploadId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $uploadIdRaw);
    if ($uploadId === '') {
        http_response_code(400);
    exit('Fehler: Ungültige Upload-ID.');
    }

    $chunkDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'ws_upload_chunks';
    if (!is_dir($chunkDir) && !mkdir($chunkDir, 0700, true)) {
        http_response_code(500);
    exit('Fehler: Temporärer Upload-Ordner konnte nicht erstellt werden.');
    }

    $tempPartPath = $chunkDir . DIRECTORY_SEPARATOR . $uploadId . '.part';

    if ($chunkIndex === 0 && file_exists($tempPartPath)) {
        @unlink($tempPartPath);
    }

    $in = @fopen($file['tmp_name'], 'rb');
    $out = @fopen($tempPartPath, 'ab');
    if (!$in || !$out) {
        if (is_resource($in)) fclose($in);
        if (is_resource($out)) fclose($out);
        http_response_code(500);
    exit('Fehler: Fehler beim Schreiben der Chunks.');
    }

    stream_copy_to_stream($in, $out);
    fclose($in);
    fclose($out);

    clearstatcache(true, $tempPartPath);
    $currentSize = @filesize($tempPartPath);
    if ($currentSize === false || $currentSize > $maxUploadSize) {
        @unlink($tempPartPath);
        http_response_code(413);
    exit("Fehler: Die Datei ist zu groß (Max. {$maxUploadSizeLabel}). Bitte lade eine kleinere Datei hoch.");
    }

    if ($chunkIndex < $totalChunks - 1) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => true,
            'chunk_received' => $chunkIndex + 1,
            'total_chunks' => $totalChunks
        ]);
        exit;
    }

    // Letzter Chunk: Integritätschecks + finalisieren
    if ($totalFileSize !== null && $totalFileSize !== false && $currentSize !== $totalFileSize) {
        @unlink($tempPartPath);
        http_response_code(400);
    exit('Fehler: Upload unvollständig: Dateigröße stimmt nicht mit den Chunks überein.');
    }

    validateMime($tempPartPath);

    if (file_exists($finalPath) && !@unlink($finalPath)) {
        @unlink($tempPartPath);
        http_response_code(500);
    exit('Fehler: Ziel-Datei konnte nicht überschrieben werden.');
    }

    if (!@rename($tempPartPath, $finalPath)) {
        @unlink($tempPartPath);
        http_response_code(500);
    exit('Fehler: Server-Fehler beim finalen Speichern der Datei.');
    }

    http_response_code(200);
    exit("Datei erfolgreich hochgeladen: {$safeFilename}");
}

// Normaler Single-Request Upload
if ($file['size'] > $maxUploadSize) {
    http_response_code(413);
    exit("Fehler: Die Datei ist zu groß (Max. {$maxUploadSizeLabel}). Bitte lade eine kleinere Datei hoch.");
}

validateMime($file['tmp_name']);

if (move_uploaded_file($file['tmp_name'], $finalPath)) {
    http_response_code(200);
    exit("Datei erfolgreich hochgeladen: {$safeFilename}");
}

http_response_code(500);
    exit('Fehler: Server-Fehler beim Speichern der Datei.');
?>
