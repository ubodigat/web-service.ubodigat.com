<?php
declare(strict_types=1);

define('WEB_ACCESS_ENABLED', false);
define('WEB_ACCESS_HASH', '');

define('FILEMANAGER_ACCESS_HASH', '');
define('FILEMANAGER_TIMEOUT', 1800);

define('WEB_LOGIN_BG', '');
define('FILEMANAGER_LOGIN_BG', '');

// ACL für Normalnutzer (Admins dürfen immer alles)
define('USER_CAN_DELETE', false);
define('USER_CAN_RENAME', true);
define('USER_CAN_UPLOAD', true);
define('USER_CAN_CREATE', true);

// Ordnerspezifische Rechte (JSON-Array)
define('FOLDER_PERMISSIONS', '[]');

// Sichtbarkeitseinstellungen (JSON-Array)
define('VISIBILITY_SETTINGS', '[]');
