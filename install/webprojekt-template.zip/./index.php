<?php
declare(strict_types=1);

// --------------------------------------------------
// 1. INSTALLATIONS-CHECK
// --------------------------------------------------
$lockFile = __DIR__ . '/install/.installed';
if (!file_exists($lockFile)) {
    if (file_exists(__DIR__ . '/install/setup.php')) {
        header('Location: install/setup.php', true, 302);
        exit;
    }
    http_response_code(500);
    die('❌ System nicht installiert und setup.php fehlt.');
}

// --------------------------------------------------
// 2. WEB-ACCESS SCHUTZ (Besucher-Login)
// --------------------------------------------------
$securityFile = __DIR__ . '/config/security.php';
if (file_exists($securityFile)) {
    require_once $securityFile;

    if (
        defined('WEB_ACCESS_ENABLED') &&
        WEB_ACCESS_ENABLED === true &&
        (empty($_COOKIE['web_access']) || $_COOKIE['web_access'] !== '1')
    ) {
        header('Location: web_login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Erfolgreich</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --bg: #070A12;
            --accent: #2DE2E6;
            --accent2: #7C5CFF;
        }

        body {
            margin: 0;
            background: radial-gradient(circle at top, #111827, #070A12);
            color: #EAF0FF;
            font-family: ui-sans-serif, system-ui;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            background: rgba(255, 255, 255, .05);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 28px;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: 0 40px 100px rgba(0, 0, 0, 0.6);
        }

        h1 {
            background: linear-gradient(90deg, var(--accent), var(--accent2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 20px;
        }

        .admin-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-top: 30px;
        }

        .btn {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            padding: 20px;
            border-radius: 20px;
            text-decoration: none;
            color: inherit;
            transition: all 0.2s;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .btn:hover {
            border-color: var(--accent);
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.05);
        }

        .icon {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .label {
            font-weight: bold;
            color: var(--accent);
        }

        .footer-info {
            margin-top: 30px;
            font-size: 13px;
            opacity: 0.5;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>🚀 Setup Erfolgreich</h1>
        <p>Dein Web-Service wurde eingerichtet. Dies ist die Startseite deines Projekts im Hauptverzeichnis.</p>

        <div class="admin-grid">
            <a href="filemanager/" class="btn">
                <span class="icon">📁</span>
                <span class="label">Dateimanager</span>
            </a>
            <a href="/phpmyadmin" target="_blank" class="btn">
                <span class="icon">🗄️</span>
                <span class="label">Datenbank</span>
            </a>
        </div>

        <div class="footer-info">
            <p>Du kannst diese Seite direkt in <code>index.php</code> bearbeiten.</p>
        </div>
    </div>
</body>

</html>