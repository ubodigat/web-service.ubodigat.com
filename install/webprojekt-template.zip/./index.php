<?php
declare(strict_types=1);

// --------------------------------------------------
// ZENTRALER EINSTIEGSPUNKT DER VORLAGE
// --------------------------------------------------

// Pfade relativ zum aktuellen Verzeichnis definieren
$installDir  = __DIR__ . '/install';
$lockFile    = $installDir . '/.installed';
$setupFile   = $installDir . '/setup.php';

// 🔹 Fall 1: Installation noch NICHT durchgeführt (Lockfile fehlt)
if (!file_exists($lockFile)) {
    
    // Prüfen, ob Setup-Datei existiert
    if (file_exists($setupFile)) {
        // WICHTIG: Relativer Pfad (ohne / am Anfang), 
        // damit es auch in Unterordnern funktioniert!
        header('Location: install/setup.php', true, 302);
        exit;
    }

    // Setup ist weg, aber System nicht installiert -> Kritischer Fehler
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo '<div style="font-family:sans-serif; text-align:center; padding:50px;">';
    echo '<h1 style="color:red">❌ Fehler</h1>';
    echo '<p>Das System ist nicht installiert, aber die <code>setup.php</code> wurde nicht gefunden.</p>';
    echo '<p>Bitte laden Sie den <code>install/</code> Ordner erneut hoch.</p>';
    echo '</div>';
    exit;
}

// 🔹 Fall 2: Installation fertig -> Weiterleitung zum Projekt
// Auch hier: Relativ bleiben.
header('Location: projekt/', true, 302);
exit;