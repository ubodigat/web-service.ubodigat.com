<?php
declare(strict_types=1);

/* =========================================================
   🔒 SETUP-SPERRE
   ========================================================= */
$lockFile = __DIR__ . '/.installed';
if (file_exists($lockFile)) {
    http_response_code(403);
    exit('❌ Setup bereits abgeschlossen.');
}

/* =========================================================
   🎨 ZENTRALE FEHLERSEITE (Premium Darkmode)
   ========================================================= */
function showError(string $title, string $message): void
{
    http_response_code(500);
    echo <<<HTML
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Fehler – Einrichtung</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            background: radial-gradient(circle at 50% 0%, #1e293b, #070a12);
            color: #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: ui-sans-serif, system-ui, sans-serif;
        }
        .error-card {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(20px);
            padding: 40px;
            border-radius: 24px;
            max-width: 500px;
            text-align: center;
            border: 1px solid rgba(248, 113, 113, 0.4);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        h2 { color: #f87171; margin-top: 0; }
        p { color: #94a3b8; line-height: 1.6; }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #334155;
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="error-card">
        <h2>❌ {$title}</h2>
        <p>{$message}</p>
        <a href="javascript:history.back()" class="back-btn">Zurück</a>
    </div>
</body>
</html>
HTML;
    exit;
}

/* =========================================================
   🔑 DB-DATEN AUS .db.env
   ========================================================= */
$envFile = __DIR__ . '/.db.env';
if (!file_exists($envFile)) {
    showError('Systemfehler', 'Die Konfigurationsdatei <code>.db.env</code> fehlt. Bitte führe zuerst das Installations-Skript im Terminal aus.');
}

$env = parse_ini_file($envFile);
$dbHost = $env['DB_HOST'] ?? '';
$dbUser = $env['DB_USER'] ?? '';
$dbPass = $env['DB_PASS'] ?? '';
$dbName = $env['DB_NAME'] ?? '';

if (!$dbHost || !$dbUser || !$dbName) {
    showError('Datenfehler', 'Die <code>.db.env</code> ist unvollständig oder beschädigt.');
}

/* =========================================================
   📂 PFADE & KONFIG
   ========================================================= */
$baseDir = realpath(__DIR__ . '/..');
$configDir = $baseDir . '/config';
$securityFile = $configDir . '/security.php';
$uploadDir = $baseDir . '/uploads';

/* =========================================================
   📩 FORMULARVERARVEITUNG
   ========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $adminUser = trim($_POST['admin_user'] ?? '');
    $adminPass = $_POST['admin_pass'] ?? '';
    $fmPass = $_POST['filemanager_pass'] ?? '';
    $fmTimeout = (int) ($_POST['filemanager_timeout'] ?? 1800);
    $webAccessActive = ($_POST['web_access_enabled'] ?? '0') === '1';
    $webAccessPass = $_POST['web_access_pass'] ?? '';

    // MySQL-Admin Option
    $createMysqlAdmin = ($_POST['create_mysql_admin'] ?? '') === '1';
    $mysqlUser = trim($_POST['mysql_admin_user'] ?? '');
    $mysqlPass = $_POST['mysql_admin_pass'] ?? '';

    /* Validierung */
    if (!$adminUser || !$adminPass || !$fmPass) {
        showError('Eingabe fehlt', 'Bitte fülle alle erforderlichen Felder aus (Benutzer & Passwörter).');
    }

    if ($webAccessActive && !$webAccessPass) {
        showError('Sicherheit', 'Du hast den Webschutz aktiviert, aber kein Passwort vergeben.');
    }

    /* Hashes */
    $adminHash = password_hash($adminPass, PASSWORD_BCRYPT);
    $fmHash = password_hash($fmPass, PASSWORD_BCRYPT);
    $webAccessHash = $webAccessActive ? password_hash($webAccessPass, PASSWORD_BCRYPT) : '';

    /* DB Verbindung */
    mysqli_report(MYSQLI_REPORT_OFF);
    $db = @new mysqli($dbHost, $dbUser, $dbPass, $dbName);
    if ($db->connect_error) {
        showError('DB-Verbindung', 'Konnte keine Verbindung zur Datenbank herstellen: ' . $db->connect_error);
    }
    $db->set_charset('utf8mb4');

    /* SQL Import */
    $sqlContent = @file_get_contents($baseDir . '/sql/struktur.sql');
    if ($sqlContent === false) {
        showError('Datei fehlt', 'Die <code>sql/struktur.sql</code> wurde nicht gefunden.');
    }

    if (!$db->multi_query($sqlContent)) {
        showError('SQL-Fehler', 'Fehler beim Importieren der Tabellen: ' . $db->error);
    }
    while ($db->more_results()) {
        $db->next_result();
    }

    /* Admin Erstellung */
    $db->query("CREATE TABLE IF NOT EXISTS benutzer (id INT AUTO_INCREMENT PRIMARY KEY, nutzername VARCHAR(255) UNIQUE NOT NULL, passwort VARCHAR(255) NOT NULL, erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB");
    $stmt = $db->prepare("INSERT IGNORE INTO benutzer (nutzername, passwort) VALUES (?,?)");
    $stmt->bind_param('ss', $adminUser, $adminHash);
    $stmt->execute();

    /* MySQL Admin (optional) */
    if ($createMysqlAdmin && $mysqlUser && $mysqlPass) {
        $q1 = "CREATE USER IF NOT EXISTS ?@'localhost' IDENTIFIED BY ?";
        $q2 = "GRANT ALL PRIVILEGES ON *.* TO ?@'localhost' WITH GRANT OPTION";
        $stmt1 = $db->prepare($q1);
        $stmt1->bind_param('ss', $mysqlUser, $mysqlPass);
        $stmt1->execute();
        $stmt2 = $db->prepare($q2);
        $stmt2->bind_param('s', $mysqlUser);
        $stmt2->execute();
        $db->query("FLUSH PRIVILEGES");
    }

    /* Hintergrundbilder */
    if (!is_dir($uploadDir))
        mkdir($uploadDir, 0755, true);
    function handleBg(string $key): string
    {
        if (!isset($_FILES[$key]) || $_FILES[$key]['error'] !== UPLOAD_ERR_OK)
            return '';
        $name = 'bg_' . bin2hex(random_bytes(8)) . '.webp';
        move_uploaded_file($_FILES[$key]['tmp_name'], __DIR__ . "/../uploads/{$name}");
        return "/uploads/" . $name;
    }
    $bgWeb = handleBg('bg_web');
    $bgFm = handleBg('bg_fm');

    /* security.php */
    if (!is_dir($configDir))
        mkdir($configDir, 0755, true);
    $secContent = "<?php\ndeclare(strict_types=1);\n\ndefine('WEB_ACCESS_ENABLED', " . ($webAccessActive ? 'true' : 'false') . ");\ndefine('WEB_ACCESS_HASH', '{$webAccessHash}');\n\ndefine('FILEMANAGER_ACCESS_HASH', '{$fmHash}');\ndefine('FILEMANAGER_TIMEOUT', {$fmTimeout});\n\ndefine('WEB_LOGIN_BG', '{$bgWeb}');\ndefine('FILEMANAGER_LOGIN_BG', '{$bgFm}');\n";
    file_put_contents($securityFile, $secContent);

    /* Dateimanager config.php erstellen */
    $fmConfigFile = $baseDir . '/filemanager/config.php';
    $fmConfigContent = "<?php\n\$db_host = '{$dbHost}';\n\$db_user = '{$dbUser}';\n\$db_pass = '{$dbPass}';\n\$db_name = '{$dbName}';\n?>";
    file_put_contents($fmConfigFile, $fmConfigContent);

    /* Finalisierung */
    file_put_contents($lockFile, date('c'));
    @unlink($envFile);

    /* LANDING PAGE RESULT */
    $serverIP = $_SERVER['SERVER_ADDR'] ?? $_SERVER['HTTP_HOST'];
    ?>
    <!DOCTYPE html>
    <html lang="de">

    <head>
        <meta charset="UTF-8">
        <title>Setup Erfolgreich – Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            :root {
                --bg: #070A12;
                --card: rgba(255, 255, 255, .05);
                --accent: #2DE2E6;
                --accent2: #7C5CFF;
            }

            body {
                margin: 0;
                background: radial-gradient(circle at top, #111827, #070A12);
                color: #EAF0FF;
                font-family: ui-sans-serif, system-ui;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }

            .container {
                background: var(--card);
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                padding: 40px;
                border-radius: 28px;
                max-width: 700px;
                width: 90%;
                box-shadow: 0 40px 100px rgba(0, 0, 0, 0.6);
            }

            h1 {
                background: linear-gradient(90deg, var(--accent), var(--accent2));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                margin-bottom: 30px;
            }

            .grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-top: 30px;
            }

            .item {
                background: rgba(255, 255, 255, 0.02);
                border: 1px solid rgba(255, 255, 255, 0.05);
                padding: 20px;
                border-radius: 20px;
                text-decoration: none;
                color: inherit;
                transition: all 0.2s;
            }

            .item:hover {
                border-color: var(--accent);
                transform: translateY(-5px);
                background: rgba(255, 255, 255, 0.05);
            }

            .item h3 {
                margin: 0 0 10px;
                color: var(--accent);
            }

            .item p {
                margin: 0;
                opacity: 0.7;
                font-size: 14px;
            }

            .badge {
                display: inline-block;
                padding: 4px 10px;
                border-radius: 99px;
                background: rgba(45, 226, 230, 0.1);
                color: var(--accent);
                font-size: 12px;
                font-weight: bold;
                margin-bottom: 8px;
            }

            .info-box {
                margin-top: 30px;
                padding: 20px;
                border-radius: 15px;
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.1);
                font-size: 14px;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <h1>✅ Setup abgeschlossen</h1>
            <p>Dein Server wurde erfolgreich konfiguriert. Alle Funktionen sind ab sofort einsatzbereit.</p>

            <div class="grid">
                <a href="/" class="item">
                    <span class="badge">Aktiv</span>
                    <h3>🌐 Webseite</h3>
                    <p>Besuche deine neue Landingpage und prüfe das Projekt.</p>
                </a>
                <a href="/filemanager/" class="item">
                    <span class="badge">Sicher</span>
                    <h3>📁 Dateimanager</h3>
                    <p>Verwalte deine Dateien direkt im Browser (Upload/Edit).</p>
                </a>
                <a href="/phpmyadmin" target="_blank" class="item">
                    <span class="badge">Datenbank</span>
                    <h3>🗄️ phpMyAdmin</h3>
                    <p>Verwalte deine MySQL-Tabellen und Datenbanken.</p>
                </a>
            </div>

            <div class="info-box">
                <strong>🔐 Zusammenfassung:</strong><br>
                • Haupt-Administrator: <b><?php echo htmlspecialchars($adminUser); ?></b><br>
                • Web-Schutz: <b><?php echo $webAccessActive ? 'Aktiviert' : 'Deaktiviert'; ?></b><br>
                • Dateimanager-Passwort: <b>Ist gesetzt</b><br>
                <hr style="opacity:0.1; margin: 15px 0;">
                <strong>🗄️ Datenbank-Zugang:</strong><br>
                • Host: <b><?php echo htmlspecialchars($dbHost); ?></b><br>
                • DB/User: <b><?php echo htmlspecialchars($dbName); ?></b><br>
                • Passwort: <b style="color:var(--accent)"><?php echo htmlspecialchars($dbPass); ?></b><br>
                <br>
                <small style="opacity:0.5">Hinweis: Bitte notiere dir die Zugangsdaten. Die Datei <code>.db.env</code> wurde
                    zur Sicherheit gelöscht.</small>
            </div>
        </div>
    </body>

    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>Einrichtung – web-service</title>
    <link rel="icon" type="image/png" href="/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --bg: #070A12;
            --accent: #2DE2E6;
            --accent2: #7C5CFF;
            --line: rgba(255, 255, 255, 0.1);
        }

        body {
            margin: 0;
            background: radial-gradient(circle at 50% 0%, #1a1e2e, #070A12);
            color: #EAF0FF;
            font-family: ui-sans-serif, system-ui, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 40px 20px;
        }

        .main-card {
            background: rgba(15, 23, 42, 0.7);
            backdrop-filter: blur(25px);
            border: 1px solid var(--line);
            padding: 50px;
            border-radius: 32px;
            max-width: 650px;
            width: 100%;
            box-shadow: 0 50px 100px rgba(0, 0, 0, 0.8);
        }

        h1 {
            margin: 0 0 10px;
            font-size: 32px;
            font-weight: 900;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .subtitle {
            color: #94a3b8;
            margin-bottom: 40px;
            font-size: 16px;
        }

        .section-title {
            margin-top: 35px;
            margin-bottom: 15px;
            font-size: 14px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--accent);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title::after {
            content: "";
            height: 1px;
            background: var(--line);
            flex: 1;
        }

        .field {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #94a3b8;
        }

        input,
        select {
            width: 100%;
            box-sizing: border-box;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 14px 16px;
            color: white;
            font-size: 15px;
            transition: all 0.2s;
            outline: none;
        }

        input:focus,
        select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(45, 226, 230, 0.1);
        }

        .help {
            font-size: 12px;
            color: #64748b;
            margin-top: 6px;
            line-height: 1.4;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        button {
            width: 100%;
            margin-top: 40px;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
            border: none;
            padding: 18px;
            border-radius: 16px;
            color: #070A12;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
            transition: transform 0.2s, filter 0.2s;
        }

        button:hover {
            transform: translateY(-2px);
            filter: brightness(1.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            user-select: none;
        }

        .checkbox-group input {
            width: auto;
        }
    </style>
</head>

<body>
    <div class="main-card">
        <h1>🔧 Final Setup</h1>
        <p class="subtitle">Konfiguriere hier deinen administrativen Zugriff und grundlegende Sicherheitseinstellungen
            für deinen neuen Web-Service.</p>

        <form method="post" enctype="multipart/form-data">

            <div class="section-title">📂 Dateimanager-Zugriff</div>
            <div class="field">
                <label for="fm_pass">Master-Passwort</label>
                <input type="password" id="fm_pass" name="filemanager_pass" required
                    placeholder="Sicheres Passwort wählen">
                <p class="help">Dieses Kennwort wird für den Login in den browserbasierten Dateimanager benötigt.</p>
            </div>
            <div class="field">
                <label for="fm_timeout">Automatischer Logout</label>
                <select id="fm_timeout" name="filemanager_timeout">
                    <option value="900">15 Minuten Inaktivität</option>
                    <option value="1800" selected>30 Minuten Inaktivität</option>
                    <option value="3600">60 Minuten Inaktivität</option>
                </select>
            </div>

            <div class="section-title">👑 System-Administrator</div>
            <div class="grid">
                <div class="field">
                    <label for="admin_user">Benutzername</label>
                    <input type="text" id="admin_user" name="admin_user" required placeholder="z.B. admin">
                </div>
                <div class="field">
                    <label for="admin_pass">Passwort</label>
                    <input type="password" id="admin_pass" name="admin_pass" required placeholder="Passwort">
                </div>
            </div>
            <p class="help">Der Administrator-Account für CMS oder interne Tools deines Projekts.</p>

            <div class="section-title">🐘 MariaDB-Optionen</div>
            <div class="field">
                <label class="checkbox-group">
                    <input type="checkbox" name="create_mysql_admin" value="1"
                        onchange="document.getElementById('mysql_fields').style.display = this.checked ? 'block' : 'none'">
                    Eigenen MySQL-Admin Benutzer anlegen
                </label>
            </div>
            <div id="mysql_fields" style="display:none">
                <div class="grid">
                    <div class="field">
                        <label>MySQL Nutzername</label>
                        <input name="mysql_admin_user" placeholder="Zusatznutzer">
                    </div>
                    <div class="field">
                        <label>MySQL Passwort</label>
                        <input type="password" name="mysql_admin_pass" placeholder="Passwort">
                    </div>
                </div>
                <p class="help" style="color:#fbbf24">Achtung: Dieser Nutzer erhält volle globale Rechte (GRANT ALL)
                    über MySQL.</p>
            </div>

            <div class="section-title">🔐 Webseiten-Schutz</div>
            <div class="field">
                <label>Zugriffsbeschränkung</label>
                <select name="web_access_enabled"
                    onchange="document.getElementById('web_pass_field').style.display = this.value == '1' ? 'block' : 'none'">
                    <option value="0">Offen (Jeder kann die Webseite sehen)</option>
                    <option value="1">Geschützt (Passwortabfrage vor Aufruf)</option>
                </select>
            </div>
            <div id="web_pass_field" class="field" style="display:none">
                <label>Web-Zugangspasswort</label>
                <input type="password" name="web_access_pass" placeholder="Passwort für Besucher">
            </div>

            <div class="section-title">🎨 Individualisierung</div>
            <div class="grid">
                <div class="field">
                    <label>Web-Login Background</label>
                    <input type="file" name="bg_web" accept="image/*">
                </div>
                <div class="field">
                    <label>FM-Login Background</label>
                    <input type="file" name="bg_fm" accept="image/*">
                </div>
            </div>

            <button type="submit">Einrichtung abschließen & Build starten</button>
        </form>
    </div>
</body>

</html>