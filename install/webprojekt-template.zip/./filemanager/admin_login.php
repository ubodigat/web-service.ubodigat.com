<?php
declare(strict_types=1);
session_start();

// 1. DB-Konfiguration laden
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    die('❌ Konfigurationsdatei fehlt. Bitte erst das Setup ausführen.');
}
require_once $configFile;

// 2. Security-Konfiguration laden (für Timeout)
$securityFile = __DIR__ . '/../config/security.php';
if (file_exists($securityFile)) {
    require_once $securityFile;
}

// 3. Wenn schon eingeloggt, weiterleiten
if (!empty($_SESSION['admin_access'])) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';

    if ($user !== '' && $pass !== '') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            $db->set_charset('utf8mb4');

            $stmt = $db->prepare("SELECT passwort FROM benutzer WHERE nutzername = ?");
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($hash);

            if ($stmt->fetch() && password_verify($pass, $hash)) {

                // ✅ SICHERHEIT: Session-ID regenerieren (Gegen Session Fixation)
                session_regenerate_id(true);

                // Session-Variablen setzen
                $_SESSION['admin_access'] = true;
                $_SESSION['filemanager_access'] = true; // Damit .htaccess/PHP zufrieden ist
                $_SESSION['filemanager_last_action'] = time();

                // ✅ TIMEOUT: Wert aus Setup oder Standard 30 Min
                $timeoutDuration = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
                    ? FILEMANAGER_TIMEOUT
                    : 1800;

                // ✅ HTTPS: Automatische Erkennung
                $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

                // Cookie setzen (Wichtig für .htaccess Whitelist)
                setcookie(
                    'filemanager_access',
                    '1',
                    [
                        'expires' => time() + $timeoutDuration,
                        'path' => '/filemanager',
                        'secure' => $isSecure,
                        'httponly' => true,
                        'samesite' => 'Strict'
                    ]
                );

                // Aufräumen
                $stmt->close();
                $db->close();

                header('Location: file_manager.php');
                exit;
            }
        } catch (mysqli_sql_exception $e) {
            // Fehler stillschweigend behandeln (Sicherheit)
        }
    }

    $error = '❌ Ungültige Zugangsdaten';
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Admin Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: radial-gradient(circle at top, #0f172a, #020617);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            color: #e5e7eb;
            padding: 24px;
        }

        .card {
            width: 100%;
            max-width: 380px;
            background: rgba(15, 23, 42, .92);
            backdrop-filter: blur(16px);
            border-radius: 18px;
            padding: 36px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, .7);
            border: 1px solid rgba(34, 48, 74, .7);
            text-align: center;
        }

        .logo {
            width: 150px;
            margin-bottom: 18px
        }

        h2 {
            margin: 10px 0 18px;
            font-size: 20px
        }

        input {
            width: 100%;
            padding: 14px;
            margin-bottom: 12px;
            border-radius: 10px;
            border: 1px solid #334155;
            background: #020617;
            color: #e5e7eb;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #38bdf8
        }

        button {
            width: 100%;
            margin-top: 10px;
            padding: 14px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #22c55e, #4ade80);
            color: #022c22;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
        }

        .error {
            margin-top: 14px;
            color: #f87171;
            font-weight: 700;
        }

        small {
            display: block;
            margin-top: 16px;
            color: #94a3b8;
            font-size: 0.85rem;
        }
    </style>
</head>

<body>

    <form method="post" class="card">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
        <h2>👑 Admin-Zugriff</h2>

        <input type="text" name="username" placeholder="Benutzername" required autofocus>
        <input type="password" name="password" placeholder="Passwort" required>

        <button type="submit">Admin Login</button>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <small>Verwendet die Datenbank-Tabelle <code>benutzer</code>.</small>
    </form>

</body>

</html>