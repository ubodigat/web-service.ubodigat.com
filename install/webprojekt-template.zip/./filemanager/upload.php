<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile   = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    exit('❌ Konfigurationsdateien fehlen.');
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    exit('❌ Zugriff verweigert.');
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    exit('❌ Sitzung abgelaufen.');
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Konfiguration & Admin Check
$baseDirRaw = '/var/www/html/webseite/aeup-projekt'; 
$baseDir = realpath($baseDirRaw);

// Sicherheits-Check: Existiert das Basis-Verzeichnis überhaupt?
if ($baseDir === false) {
    http_response_code(500);
    exit('❌ Basisverzeichnis nicht erreichbar (Server-Config Fehler).');
}

$isAdmin = !empty($_SESSION['admin_access']);

// ---------------------------------------------------------
// Validierung des Requests
// ---------------------------------------------------------

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('❌ Ungültige Anfrage-Methode.');
}

if (empty($_POST['path']) || !isset($_FILES['uploadFile']) || $_FILES['uploadFile']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    exit('❌ Kein Datei-Upload empfangen oder Upload-Fehler.');
}

// ---------------------------------------------------------
// Pfad-Sicherheit (Path Traversal Schutz)
// ---------------------------------------------------------

$targetPathRaw = $_POST['path'];
$targetDir = realpath($targetPathRaw);

// Existiert das Ziel?
if ($targetDir === false || !is_dir($targetDir)) {
    http_response_code(400);
    exit('❌ Zielverzeichnis existiert nicht.');
}

// Sandbox-Check: Nur Admins dürfen außerhalb des Projekts hochladen
if (!$isAdmin) {
    if (strpos($targetDir, $baseDir) !== 0) {
        http_response_code(403);
        exit('❌ Zugriff verweigert: Upload außerhalb des Projektordners verboten.');
    }
}

// ---------------------------------------------------------
// Datei-Validierung (Inhalt & Typ)
// ---------------------------------------------------------

$file = $_FILES['uploadFile'];
$filename = basename($file['name']);
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

// A. Dateinamen bereinigen
$safeFilename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $filename);

// B. Globale Sperrliste (Gilt für USER UND ADMIN!)
// PHP-Dateien dürfen niemals hochgeladen werden, um RCE (Remote Code Execution) zu verhindern.
$globalBlocked = ['php', 'php3', 'php4', 'php5', 'phtml', 'phar', 'pl', 'py', 'cgi'];

if (in_array($extension, $globalBlocked, true)) {
    http_response_code(403);
    exit("❌ Sicherheitswarnung: Skript-Dateien (.$extension) sind strikt verboten.");
}

// C. Erweiterte Sperrliste für normale User
// Normale User dürfen keine Systemdateien oder Executables hochladen
$userBlocked = ['exe', 'sh', 'bat', 'cmd', 'htaccess', 'env', 'ini', 'sql'];

if (!$isAdmin && in_array($extension, $userBlocked, true)) {
    http_response_code(403);
    exit("❌ Dateityp .$extension ist für normale Benutzer nicht erlaubt.");
}

// D. MIME-Type Prüfung (Deep Inspection)
// Wir schauen in die Datei hinein, um versteckte PHP-Dateien zu finden (z.B. bild.jpg, das eigentlich PHP ist)
if (class_exists('finfo')) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    $blockedMimes = [
        'application/x-php',
        'text/x-php',
        'application/x-httpd-php',
        'application/x-sh',
        'application/x-csh'
    ];

    if (in_array($mime, $blockedMimes, true)) {
        http_response_code(403);
        exit('❌ Unerlaubter Datei-Inhalt erkannt (MIME-Check).');
    }
}

// E. Dateigröße (50 MB)
$maxSize = 50 * 1024 * 1024; 
if ($file['size'] > $maxSize) {
    http_response_code(413);
    exit('❌ Datei ist zu groß (Max 50MB).');
}

// ---------------------------------------------------------
// Datei speichern
// ---------------------------------------------------------

$finalPath = $targetDir . DIRECTORY_SEPARATOR . $safeFilename;

if (move_uploaded_file($file['tmp_name'], $finalPath)) {
    http_response_code(200);
    echo "✅ Datei erfolgreich hochgeladen: $safeFilename";
} else {
    http_response_code(500);
    exit('❌ Server-Fehler beim Speichern der Datei.');
}
?>