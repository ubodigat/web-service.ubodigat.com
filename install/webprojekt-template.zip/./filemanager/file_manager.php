<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration & Sicherheit laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    die('❌ Konfigurationsdateien fehlen. Bitte Setup ausführen.');
}
require_once $securityFile;
require_once $configFile;

// 2. Variablen definieren
$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';
// Timeout aus Security-Config oder Standard 30 Min
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

// 3. Zugriffsprüfung (Session UND Cookie für .htaccess Konsistenz)
if (
    (empty($_SESSION[$session_key]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookie_name])
) {
    $url = urlencode($_SERVER['REQUEST_URI']);
    header("Location: login_filemanager.php?redirect=$url");
    exit;
}

// 4. Timeout prüfen
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    // Timeout abgelaufen -> Universal-Logout
    header("Location: logout_admin.php?timeout=1");
    exit;
}

// 5. Keep-Alive: Session & Cookie aktualisieren
$_SESSION['filemanager_last_action'] = time();

// WICHTIG: Cookie bei jeder Aktivität verlängern, 
// damit die .htaccess den User nicht blockiert, solange er aktiv ist.
setcookie(
    $cookie_name,
    '1',
    [
        'expires' => time() + $timeout,
        'path' => '/filemanager',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict'
    ]
);

// 6. Admin-Status & Pfad
$isAdmin = !empty($_SESSION['admin_access']);
$rootDir = realpath(__DIR__ . '/..');
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>📂 Web-Dateimanager</title>
    <link rel="icon" type="image/svg+xml" href="https://web-service.ubodigat.com/ubodigatlogo.svg">
    <link rel="stylesheet" href="style.css?v=208" />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
    <script>
        require.config({
            paths: {
                vs: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.1/min/vs"
            }
        });
    </script>
</head>

<body>
    <div class="container">

        <div class="top-controls">
            <h2>📂 Web-Dateimanager</h2>
            <div class="right-buttons">
                <?php if ($isAdmin): ?>
                    <button class="btn btn-info" onclick="window.location.href='admin_settings.php'">⚙️ Einstellungen</button>
                    <form method="post" action="logout_admin.php" style="display:inline;">
                        <button type="submit" class="btn btn-danger">🚪 Admin-Logout</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-warning" onclick="window.location.href='logout_admin.php'">🚪 Logout</button>
                    <button class="btn btn-info" onclick="window.location.href='admin_login.php'">🔐 Admin-Login</button>
                <?php endif; ?>
                <button class="dark-mode-toggle" onclick="toggleDarkMode()">🌙 Dark Mode</button>
            </div>
        </div>

        <div class="upload-box">
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="upload-row">
                    <label class="custom-upload">
                        📤 Datei auswählen
                        <input type="file" id="uploadFile" name="uploadFile" onchange="showFileName()" hidden>
                    </label>
                    <span id="selectedFileName" class="file-name">Keine Datei ausgewählt</span>
                    <button type="submit" class="btn btn-warning" id="uploadBtn">⬆️ Hochladen</button>
                </div>
            </form>
        </div>

        <div class="input-group">
            <input type="text" id="directoryPath" value="<?= htmlspecialchars($rootDir) ?>">
            <button id="aktualisieren" class="btn btn-success" onclick="loadFiles()">🔄 Aktualisieren</button>
        </div>

        <script>
            const inputPath = document.getElementById("directoryPath");
            const isAdmin = <?= $isAdmin ? "true" : "false" ?>;
            const basePath = "<?= addslashes($rootDir) ?>";  // Frontend-Pfadschutz
            if (!isAdmin) {
                inputPath.addEventListener("input", () => {
                    if (!inputPath.value.startsWith(basePath)) {
                        inputPath.value = basePath;
                    }
                });
                inputPath.addEventListener("keydown", function (e) {
                    const start = inputPath.selectionStart;
                    const baseLength = basePath.length;
                    if (start < baseLength) {
                        const allowed = ["ArrowRight", "ArrowDown", "End", "Tab"];
                        if (!allowed.includes(e.key)) {
                            e.preventDefault();
                            inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                        }
                    }
                });
                inputPath.addEventListener("click", function () {
                    const baseLength = basePath.length;
                    if (inputPath.selectionStart < baseLength) {
                        inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                    }
                });
            }
        </script>

        <div class="input-group">
            <input type="text" id="newFileName" class="input-half" placeholder="Dateiname">
            <button class="btn btn-primary buttonbreite" onclick="createFile()">➕ Datei erstellen</button>

            <input type="text" id="newFolderName" class="input-half" placeholder="Ordnername">
            <button class="btn btn-secondary buttonbreite" onclick="createFolder()">📁 Ordner erstellen</button>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Typ</th>
                    <th>Letzte Änderung</th>
                    <th>Aktionen</th>
                </tr>
            </thead>
            <tbody id="fileTable"></tbody>
        </table>
    </div>

    <div id="editModal" class="edit-modal">
        <h3 id="editTitle">Datei bearbeiten</h3>
        <div id="editor-container">
            <div id="editor"></div>
        </div>
        <div class="modal-buttons">
            <button class="btn btn-danger" onclick="closeEditModal()">❌ Schließen</button>
            <button class="btn btn-success" onclick="saveFile()">💾 Speichern</button>
        </div>
    </div>

    <script src="script.js?v=208"></script>
    <script>
        function showFileName() {
            const input = document.getElementById('uploadFile');
            const label = document.getElementById('selectedFileName');
            label.textContent = input.files.length > 0 ? input.files[0].name : "Keine Datei ausgewählt";
        }

        function downloadFile() {
            const path = document.getElementById("directoryPath").value.trim();
            if (!path) {
                alert("❗ Bitte wähle erst eine Datei oder einen Ordner aus.");
                return;
            }
            const fileName = path.split("/").pop();
            const link = document.createElement('a');
            link.href = 'download.php?path=' + encodeURIComponent(path);
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>

</html>