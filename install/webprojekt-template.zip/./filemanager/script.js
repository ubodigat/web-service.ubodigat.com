let editor = null;
let darkMode = localStorage.getItem("darkMode") === "true";

// 🌙 Dark Mode umschalten
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode);
    applyEditorTheme();
}

// 🎨 Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    document.getElementById("editor-container").style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// 📂 Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "📂";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "🌐", htm: "🌐", php: "🐘", js: "📜", css: "🎨", txt: "📝", json: "🔢", pdf: "📑",
        ico: "📎", zip: "📦", rar: "📦", png: "🖼️", jpg: "🖼️", jpeg: "🖼️", mp4: "🎞️", mov: "🎞️"
    };
    return icons[ext] || "📄";
}

// 🔄 Dateien laden
function loadFiles() {
    const dir = document.getElementById("directoryPath").value.trim();
    if (!dir) return alert("Verzeichnis ist leer!");

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            alert("Fehler: " + data.error);
            return;
        }

        const table = $("#fileTable").empty();
        const files = data.files || [];
        const separator = dir.includes("\\") ? "\\" : "/";
        const isAdmin = data.isAdmin || false; // Backend liefert Admin-Status mit
        window.isSystemAdmin = isAdmin; // Global merken

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = dir.replace(/[/\\]$/, "") + separator + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";

            const actionBtn = isFolder
                ? `<button class="btn btn-primary btn-small" onclick="openFolderByPath('${encodeURIComponent(file.name)}')">📂 Öffnen</button>`
                : `<button class="btn btn-warning btn-small" onclick="editFile('${file.name}')">✏️ Bearbeiten</button>`;

            table.append(`
                <tr data-type="${file.type}">
                    <td>${icon} ${file.name}</td>
                    <td>${file.type}</td>
                    <td>${file.date}</td>
                    <td>
                        ${actionBtn}
                        <button class="btn btn-info btn-small" onclick="renameFile('${file.name}')">📄 Umbenennen</button>
                        <button class="btn btn-danger btn-small" onclick="deleteFile('${file.name}')">🗑️ Löschen</button>
                        <button class="btn btn-secondary btn-small" onclick="setPermissions('${file.name}')">🔐 Rechte</button>
                        <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-icon-only" title="Download">⬇️</a>
                    </td>
                </tr>
            `);
        });
    }).fail(jqXHR => alert("Fehler beim Laden: " + jqXHR.responseText));
}

// 🔐 Berechtigungen setzen (chmod)
function setPermissions(name) {
    if (!window.isSystemAdmin) return alert("🔐 Admin-Rechte erforderlich!");
    const mode = prompt(`Berechtigungen für "${name}" setzen (z.B. 0644 oder 0755):`, "0644");
    if (!mode) return;

    const dir = document.getElementById("directoryPath").value.trim();
    const separator = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + separator + name;

    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "chmod",
            path: fullPath,
            mode: mode
        }),
        success: response => {
            if (response.error) alert("Fehler: " + response.error);
            else alert(response.success || "Berechtigungen geändert.");
        },
        error: jqXHR => alert("Fehler: " + jqXHR.responseText)
    });
}

// Hilfsfunktion zum Öffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    const separator = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + separator + name;
    loadFiles();
}

// 📂 Ordner öffnen beim Klick auf die Zeile (außer auf Buttons)
$(document).on("click", "#fileTable tr", function (e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").trim();
    const type = $(this).attr("data-type");

    if (type === "folder" || type === "Ordner") {
        openFolderByPath(name);
    }
});

// ✏️ Datei bearbeiten
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const separator = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + separator + name;

    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return alert(data.error);

        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();

        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = { php: "php", js: "javascript", css: "css", html: "html", txt: "plaintext" };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => alert("Fehler: " + jqXHR.responseText));
}

// 💾 Datei speichern
function saveFile() {
    if (!window.isSystemAdmin) return alert("🔐 Admin-Rechte erforderlich!\nNur Administratoren können Dateien bearbeiten.");
    if (!editor) return;
    const content = editor.getValue();

    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content: content
        }),
        success: response => {
            if (response.error) alert("Fehler: " + response.error);
            else {
                alert(response.success || "Gespeichert.");
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => alert("Fehler beim Speichern: " + jqXHR.responseText)
    });
}

// 📁 Modal ein-/ausblenden
function openEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}
function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// 🗑️ Löschen
function deleteFile(name) {
    if (!window.isSystemAdmin) return alert("🔐 Admin-Rechte erforderlich!\nLöschen ist nur für Administratoren erlaubt.");
    if (!confirm(`Möchtest du "${name}" wirklich löschen?`)) return;

    const dir = document.getElementById("directoryPath").value.trim();
    const separator = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + separator + name;

    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) alert("Fehler: " + response.error);
        else {
            alert(response.success || "Gelöscht.");
            loadFiles();
        }
    }, "json");
}

// 📄 Umbenennen
function renameFile(oldName) {
    if (!window.isSystemAdmin) return alert("🔐 Admin-Rechte erforderlich!\nUmbenennen ist nur für Administratoren erlaubt.");
    const newName = prompt("Neuer Name:", oldName);
    if (!newName || newName === oldName) return;

    const dir = document.getElementById("directoryPath").value.trim();

    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName: oldName,
        newName: newName
    }), response => {
        if (response.error) alert("Fehler: " + response.error);
        else {
            alert(response.success || "Umbenannt.");
            loadFiles();
        }
    }, "json");
}

// ➕ Datei / Ordner erstellen
function createFile(isFolder = false) {
    if (!window.isSystemAdmin) return alert("🔐 Admin-Rechte erforderlich!\nErstellen von Dateien/Ordnern ist Administratoren vorbehalten.");
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return alert("Bitte Namen eingeben!");

    const dir = document.getElementById("directoryPath").value.trim();

    $.post("api.php", JSON.stringify({
        action: "create",
        path: dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        if (response.error) {
            alert("Fehler: " + response.error);
        } else {
            alert(response.success || "Erfolgreich erstellt.");
            loadFiles();
            document.getElementById(inputId).value = "";
        }
    }, "json").fail(jqXHR => alert("Fehler: " + jqXHR.responseText));
}
function createFolder() { createFile(true); }

// ⬆️ Datei hochladen
function uploadFile(event) {
    event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;
    const formData = new FormData();

    if (!fileInput.files.length) return alert("Bitte wähle eine Datei aus.");

    formData.append('uploadFile', fileInput.files[0]);
    formData.append('path', path);

    fetch('upload.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(response => {
            alert(response);
            loadFiles();
            fileInput.value = "";
            document.getElementById('selectedFileName').textContent = "Keine Datei ausgewählt";
        })
        .catch(error => {
            console.error("Upload-Fehler:", error);
            alert("Fehler beim Hochladen.");
        });
}

// 🧠 Monaco laden
require(["vs/editor/editor.main"], function () {
    editor = monaco.editor.create(document.getElementById("editor"), {
        value: "// Warten auf Datei...",
        language: "plaintext",
        theme: darkMode ? "vs-dark" : "vs-light",
        fontSize: 14,
        automaticLayout: true
    });
    console.log("✅ Monaco Editor geladen");
});

// 📦 Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");

    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");

    $("#uploadForm").on("submit", uploadFile);
    document.getElementById("directoryPath").addEventListener("keydown", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            loadFiles();
        }
    });
});

// 🌐 Global exportieren
window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;
