let editor = null;
let darkMode = localStorage.getItem("darkMode") === "true";

// 🌙 Dark Mode umschalten
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    applyEditorTheme();
}

// Initialer Check
if (localStorage.getItem("darkMode") === "true") {
    document.body.classList.add("dark-mode");
    darkMode = true;
} else if (localStorage.getItem("darkMode") === "false") {
    document.body.classList.remove("dark-mode");
    darkMode = false;
}

// 🎨 Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    document.getElementById("editor-container").style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// 📂 Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "📂";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "🌐", htm: "🌐", php: "🐘", js: "📜", css: "🎨", txt: "📝", json: "🔢", pdf: "📑",
        ico: "📎", zip: "📦", rar: "📦", png: "🖼️", jpg: "🖼️", jpeg: "🖼️", mp4: "🎞️", mov: "🎞️"
    };
    return icons[ext] || "📄";
}

// 🖼️ Custom Modal System
function customModal({ title, message, type = 'alert', confirmText = 'OK', cancelText = 'Abbrechen', inputPlaceholder = '', defaultValue = '', permGrid = false }) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay"></div>');
        const card = $('<div class="modal-card"></div>');
        const header = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close" title="Schließen">×</button>');
        header.append(closeBtn);

        closeBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        const body = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${defaultValue}">`);
            body.append(input);
        }

        if (permGrid) {
            const grid = ($('<div class="perm-grid"></div>'));
            const perms = ['Lesen', 'Schreiben', 'Ausführen'];
            const groups = ['Besitzer', 'Gruppe', 'Andere'];

            // Info-Leiste
            body.append('<div style="font-size:11px; color:#94a3b8; margin-bottom:10px; padding:8px; background:rgba(255,255,255,0.05); border-radius:6px;"><b>💡 Info:</b> 4=Lesen, 2=Schreiben, 1=Ausführen. Die Summe ergibt die jeweilige Ziffer (z.B. 4+2=6).</div>');

            groups.forEach(g => {
                grid.append(`<div style="grid-column: span 3; font-weight: bold; margin-top: 5px; color:var(--accent);">${g}</div>`);
                perms.forEach(p => {
                    grid.append(`<div class="perm-item"><input type="checkbox" id="perm_${g}_${p}"> ${p}</div>`);
                });
            });
            body.append(grid);
        }

        const confirmBtn = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const cancelBtn = $(`<button class="btn btn-secondary">${cancelText}</button>`);

        confirmBtn.on('click', () => {
            let result = true;
            if (type === 'prompt') result = input.val();
            if (permGrid) {
                // Berechne Oktal-Mode aus Checkboxes
                let mode = 0;
                // Logik für Rechte... (vereinfacht für das UI)
                result = "0644"; // Platzhalter für Logik
            }
            overlay.remove();
            resolve(result);
        });

        cancelBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        footer.append(cancelBtn).append(confirmBtn);
        if (type === 'alert') cancelBtn.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').last().append(overlay); // Sicherstellen, dass es im Body ist
        if (input) input.focus();

        // Live-Event für Chmod-Grid
        if (permGrid) {
            const updateOctal = () => {
                let u = 0, g = 0, o = 0;
                if ($('#perm_Besitzer_Lesen').is(':checked')) u += 4;
                if ($('#perm_Besitzer_Schreiben').is(':checked')) u += 2;
                if ($('#perm_Besitzer_Ausführen').is(':checked')) u += 1;

                if ($('#perm_Gruppe_Lesen').is(':checked')) g += 4;
                if ($('#perm_Gruppe_Schreiben').is(':checked')) g += 2;
                if ($('#perm_Gruppe_Ausführen').is(':checked')) g += 1;

                if ($('#perm_Andere_Lesen').is(':checked')) o += 4;
                if ($('#perm_Andere_Schreiben').is(':checked')) o += 2;
                if ($('#perm_Andere_Ausführen').is(':checked')) o += 1;

                overlay.find('.modal-header').text(`${title} (${u}${g}${o})`);
            };
            overlay.find('input[type="checkbox"]').on('change', updateOctal);

            // Standards setzen (0644)
            $('#perm_Besitzer_Lesen, #perm_Besitzer_Schreiben, #perm_Gruppe_Lesen, #perm_Andere_Lesen').prop('checked', true);
            updateOctal();
        }
    });
}

// 🔄 Dateien laden
function loadFiles() {
    const dir = document.getElementById("directoryPath").value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            customModal({ title: '❌ Fehler', message: data.error });
            return;
        }

        const table = $("#fileTable").empty();
        const files = data.files || [];
        const separator = dir.includes("\\") ? "\\" : "/";
        const isAdmin = data.isAdmin || false; // Backend liefert Admin-Status mit
        window.isSystemAdmin = isAdmin; // Global merken

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = (dir === '.' ? '' : dir).replace(/[/\\]$/, "") + (dir === '.' ? '' : separator) + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";

            const actionBtn = isFolder
                ? `<button class="btn btn-primary btn-small" onclick="openFolderByPath('${encodeURIComponent(file.name)}')">📂 Öffnen</button>`
                : `<button class="btn btn-warning btn-small" onclick="editFile('${file.name}')">✏️ Edit</button>`;

            table.append(`
                <tr data-type="${file.type}">
                    <td>${icon} ${file.name}</td>
                    <td>${file.type}</td>
                    <td>${file.date}</td>
                    <td>
                        <div style="display:flex; justify-content: flex-end; align-items:center; gap:5px;">
                            ${actionBtn}
                            <button class="btn btn-warning btn-small" onclick="renameFile('${file.name}')">📄 Umbenennen</button>
                            <button class="btn btn-danger btn-small" onclick="deleteFile('${file.name}')">🗑️ Löschen</button>
                            <button class="btn btn-secondary btn-small" onclick="showVisibility('${fullPath}')">👁️ Rechte</button>
                            <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-icon-only" title="Download">⬇️</a>
                        </div>
                    </td>
                </tr>
            `);
        });
    }).fail(jqXHR => customModal({ title: '❌ Fehler', message: "Ladefehler: " + jqXHR.responseText }));
}

// 👁️ Sichtbarkeit verwalten (Public/Private)
async function showVisibility(path) {
    if (!window.isSystemAdmin) return customModal({ title: '🔐 Zugriff verweigert', message: "Admin-Rechte erforderlich!" });

    // Status abfragen
    const response = await fetch(`api.php?action=get_visibility&path=${encodeURIComponent(path)}`);
    const data = await response.json();
    const isPrivate = data.status === 'private';

    const result = await customModal({
        title: '🔒 Sichtbarkeit verwalten',
        message: `<div style="text-align:center;">
            <p>Festlegen, ob normale Benutzer dieses Element sehen können:</p>
            <div style="font-size:32px; margin:20px 0;">${isPrivate ? '🚫 Privat' : '🌍 Öffentlich'}</div>
            <p style="font-size:14px; opacity:0.8;">Aktueller Status: <b>${isPrivate ? 'Versteckt' : 'Sichtbar'}</b></p>
            <p style="font-size:11px; margin-top:10px; opacity:0.6;">💡 Wenn ein Ordner auf "Privat" gesetzt wird, sind automatisch auch alle darin enthaltenen Dateien für Nicht-Admins unsichtbar.</p>
        </div>`,
        confirmText: isPrivate ? 'Auf Öffentlich setzen' : 'Auf Privat setzen',
        cancelText: 'Abbrechen',
        type: 'confirm'
    });

    if (result) {
        $.ajax({
            url: "api.php",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({
                action: "set_visibility",
                path: path,
                status: isPrivate ? 'public' : 'private'
            }),
            success: res => {
                if (res.error) customModal({ title: '❌ Fehler', message: res.error });
                else {
                    customModal({ title: '✅ Erfolg', message: res.success });
                    loadFiles();
                }
            },
            error: jqXHR => customModal({ title: '❌ Fehler', message: "Fehler: " + jqXHR.responseText })
        });
    }
}

// Hilfsfunktion zum Öffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    const separator = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + separator + name;
    loadFiles();
}

// 📂 Ordner öffnen beim Klick auf die Zeile (außer auf Buttons)
$(document).on("click", "#fileTable tr", function (e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").trim();
    const type = $(this).attr("data-type");

    if (type === "folder" || type === "Ordner") {
        openFolderByPath(name);
    }
});

// ✏️ Datei bearbeiten
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const separator = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + separator + name;

    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({ title: '❌ Fehler', message: data.error });

        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();

        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = { php: "php", js: "javascript", css: "css", html: "html", txt: "plaintext" };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => customModal({ title: '❌ Fehler', message: "Fehler: " + jqXHR.responseText }));
}

// 💾 Datei speichern
async function saveFile() {
    if (!window.isSystemAdmin) return customModal({ title: '🔐 Zugriff verweigert', message: "Admin-Rechte erforderlich!\nNur Administratoren können Dateien bearbeiten." });
    if (!editor) return;
    const content = editor.getValue();

    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content: content
        }),
        success: response => {
            if (response.error) customModal({ title: '❌ Fehler', message: response.error });
            else {
                customModal({ title: '✅ Erfolg', message: response.success || "Gespeichert." });
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => customModal({ title: '❌ Fehler', message: "Fehler beim Speichern: " + jqXHR.responseText })
    });
}

// 📁 Modal ein-/ausblenden
function openEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}
function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// 🗑️ Löschen
async function deleteFile(name) {
    if (!window.isSystemAdmin) return customModal({ title: '🔐 Zugriff verweigert', message: "Admin-Rechte erforderlich!\nLöschen ist nur für Administratoren erlaubt." });
    const confirmed = await customModal({ title: '🗑️ Löschen bestätigen', message: `Möchtest du "${name}" wirklich löschen?`, type: 'confirm', confirmText: 'Ja', cancelText: 'Nein' });
    if (!confirmed) return;

    const dir = document.getElementById("directoryPath").value.trim();
    const separator = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + separator + name;

    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) customModal({ title: '❌ Fehler', message: response.error });
        else {
            customModal({ title: '✅ Erfolg', message: response.success || "Gelöscht." });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({ title: '❌ Fehler', message: "Fehler: " + jqXHR.responseText }));
}

// 📄 Umbenennen
async function renameFile(oldName) {
    if (!window.isSystemAdmin) return customModal({ title: '🔐 Zugriff verweigert', message: "Admin-Rechte erforderlich!\nUmbenennen ist nur für Administratoren erlaubt." });
    const newName = await customModal({ title: '📄 Umbenennen', message: 'Neuer Name:', type: 'prompt', defaultValue: oldName });
    if (!newName || newName === oldName) return;

    const dir = document.getElementById("directoryPath").value.trim();

    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName: oldName,
        newName: newName
    }), response => {
        if (response.error) customModal({ title: '❌ Fehler', message: response.error });
        else {
            customModal({ title: '✅ Erfolg', message: response.success || "Umbenannt." });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({ title: '❌ Fehler', message: "Fehler: " + jqXHR.responseText }));
}

// ➕ Datei / Ordner erstellen
async function createFile(isFolder = false) {
    if (!window.isSystemAdmin) return customModal({ title: '🔐 Zugriff verweigert', message: "Admin-Rechte erforderlich!\nErstellen von Dateien/Ordnern ist Administratoren vorbehalten." });
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return customModal({ title: '⚠️ Eingabe erforderlich', message: "Bitte Namen eingeben!" });

    const dir = document.getElementById("directoryPath").value.trim();

    $.post("api.php", JSON.stringify({
        action: "create",
        path: dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        if (response.error) {
            customModal({ title: '❌ Fehler', message: response.error });
        } else {
            customModal({ title: '✅ Erfolg', message: response.success || "Erfolgreich erstellt." });
            loadFiles();
            document.getElementById(inputId).value = "";
        }
    }, "json").fail(jqXHR => customModal({ title: '❌ Fehler', message: "Fehler: " + jqXHR.responseText }));
}
function createFolder() { createFile(true); }

// ⬆️ Datei hochladen
function uploadFile(event) {
    event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;
    const formData = new FormData();

    if (!fileInput.files.length) return customModal({ title: '⚠️ Auswahl erforderlich', message: "Bitte wähle eine Datei aus." });

    formData.append('uploadFile', fileInput.files[0]);
    formData.append('path', path);

    fetch('upload.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(response => {
            customModal({ title: '⬆️ Upload Status', message: response });
            loadFiles();
            fileInput.value = "";
            document.getElementById('selectedFileName').textContent = "Keine Datei ausgewählt";
        })
        .catch(error => {
            console.error("Upload-Fehler:", error);
            customModal({ title: '❌ Fehler', message: "Fehler beim Hochladen." });
        });
}

// 🧠 Monaco laden
require(["vs/editor/editor.main"], function () {
    editor = monaco.editor.create(document.getElementById("editor"), {
        value: "// Warten auf Datei...",
        language: "plaintext",
        theme: darkMode ? "vs-dark" : "vs-light",
        fontSize: 14,
        automaticLayout: true
    });
    console.log("✅ Monaco Editor geladen");
});

// 📦 Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");

    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");

    $("#uploadForm").on("submit", uploadFile);
    document.getElementById("directoryPath").addEventListener("keydown", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            loadFiles();
        }
    });
});

// 🌐 Global exportieren
window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;
// 👁️ Passwort-Sichtbarkeit umschalten
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    if (input.type === "password") {
        input.type = "text";
        btn.textContent = "👁️‍🗨️";
    } else {
        input.type = "password";
        btn.textContent = "👁️";
    }
}

$(document).ready(() => {
    // Falls jQuery bereit ist, Modals etc. prüfen
    if (typeof loadFiles === "function") loadFiles();
});
