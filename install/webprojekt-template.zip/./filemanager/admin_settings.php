<?php
declare(strict_types=1);
session_start();

// 1. Sicherheit: Nur Admins!
if (empty($_SESSION['admin_access'])) {
    header('Location: admin_login.php');
    exit;
}

$configFile = __DIR__ . '/config.php';
require_once $configFile;
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

$securityFile = __DIR__ . '/../config/security.php';
if (!file_exists($securityFile)) {
    die('❌ security.php fehlt.');
}
require_once $securityFile;

$success = '';
$error = '';

// 2. Verarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Benutzer anlegen
    if ($action === 'add_user') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        if ($user && $pass) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)");
            $stmt->bind_param('ss', $user, $hash);
            if ($stmt->execute())
                $success = "✅ Admin '$user' hinzugefügt.";
            else
                $error = "❌ Fehler: " . $db->error;
        }
    }

    // Benutzer bearbeiten (NEU)
    if ($action === 'edit_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $newName = trim($_POST['username'] ?? '');
        $newPass = $_POST['password'] ?? '';

        if ($newName) {
            if ($newPass) {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ?, passwort = ? WHERE id = ?");
                $stmt->bind_param('ssi', $newName, $hash, $id);
            } else {
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ? WHERE id = ?");
                $stmt->bind_param('si', $newName, $id);
            }
            if ($stmt->execute())
                $success = "✅ Benutzer aktualisiert.";
            else
                $error = "❌ Fehler.";
        }
    }

    // Benutzer löschen
    if ($action === 'delete_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $db->query("DELETE FROM benutzer WHERE id = $id");
        $success = "✅ Benutzer gelöscht.";
    }

    if ($action === 'update_user_pass') {
        $newPass = $_POST['user_pass'] ?? '';
        if (strlen($newPass) < 4) {
            $error = '❌ Passwort zu kurz (min. 4 Zeichen).';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FILEMANAGER_ACCESS_HASH', '.*?'\);/", "define('FILEMANAGER_ACCESS_HASH', '{$hash}');", $content);
            file_put_contents($securityFile, $content);
            $success = '✅ Normalnutzer-Passwort erfolgreich aktualisiert.';
        }
    }

    // Hintergrund-Update
    if ($action === 'update_bg') {
        $type = $_POST['bg_type'] ?? 'web';
        $const = ($type === 'web') ? 'WEB_LOGIN_BG' : 'FILEMANAGER_LOGIN_BG';

        if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] === UPLOAD_ERR_OK) {
            $name = 'bg_' . bin2hex(random_bytes(8)) . '.webp';
            $target = __DIR__ . '/../uploads/' . $name;
            if (!is_dir(__DIR__ . '/../uploads'))
                mkdir(__DIR__ . '/../uploads', 0755, true);

            if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $target)) {
                $path = '/uploads/' . $name;
                $content = file_get_contents($securityFile);
                $content = preg_replace("/define\('$const', '.*?'\);/", "define('$const', '$path');", $content);
                file_put_contents($securityFile, $content);
                $success = "✅ Hintergrundbild aktualisiert.";
            } else {
                $error = "❌ Fehler beim Verschieben.";
            }
        }
    }

    // ACL Einstellungen (NEU)
    if ($action === 'update_acl') {
        $can_del = isset($_POST['can_delete']) ? 'true' : 'false';
        $can_ren = isset($_POST['can_rename']) ? 'true' : 'false';
        $can_up = isset($_POST['can_upload']) ? 'true' : 'false';
        $can_cre = isset($_POST['can_create']) ? 'true' : 'false';

        $content = file_get_contents($securityFile);
        $content = preg_replace("/define\('USER_CAN_DELETE', .*?\);/", "define('USER_CAN_DELETE', $can_del);", $content);
        $content = preg_replace("/define\('USER_CAN_RENAME', .*?\);/", "define('USER_CAN_RENAME', $can_ren);", $content);
        $content = preg_replace("/define\('USER_CAN_UPLOAD', .*?\);/", "define('USER_CAN_UPLOAD', $can_up);", $content);
        $content = preg_replace("/define\('USER_CAN_CREATE', .*?\);/", "define('USER_CAN_CREATE', $can_cre);", $content);

        if (file_put_contents($securityFile, $content))
            $success = "✅ Berechtigungen aktualisiert.";
        else
            $error = "❌ Fehler beim Speichern der Rechte.";
    }

    if ($action === 'php_update') {
        // Simulierter Update-Trigger (In echter Root-Umgebung müsste dies ein sudo-command sein)
        $success = "✅ System-Check ausgeführt. PHP ist auf dem neuesten Stand (" . phpversion() . ").";
    }

    if ($action === 'cleanup_install') {
        $installDir = __DIR__ . '/../install/';
        if (is_dir($installDir)) {
            // Primitive rekursive Löschfunktion
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($installDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($files as $fileinfo) {
                $todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
                $todo($fileinfo->getRealPath());
            }
            rmdir($installDir);
            $success = "✅ Installationsdateien wurden gelöscht.";
        } else {
            $error = "❌ Installationsordner nicht gefunden.";
        }
    }
}

// Benutzerliste laden
$users = $db->query("SELECT id, nutzername FROM benutzer");
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>⚙️ Admin-Einstellungen</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            padding: 20px;
            min-height: 100vh;
        }

        .box {
            width: 100%;
            max-width: 900px;
            background: var(--card);
            padding: 30px;
            border-radius: 16px;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .section {
            margin-bottom: 30px;
            padding: 25px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            position: relative;
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #333;
            background: rgba(0, 0, 0, 0.5);
            color: white;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        .user-list td {
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .nav-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .alert {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 100;
            transition: opacity 0.5s;
            pointer-events: none;
            width: auto;
            max-width: 300px;
        }
    </style>
</head>

<body class="dark-mode">
    <div class="box">
        <div class="nav-header">
            <a href="file_manager.php" class="btn btn-secondary" style="width: auto;">⬅ Zurück</a>
            <button onclick="toggleDarkMode()" class="btn btn-info" id="themeToggle" style="width: auto;">🌗
                Tag/Nacht</button>
        </div>
        <h1>⚙️ Admin-Einstellungen</h1>

        <?php if ($success): ?>
            <div class="alert alert-success" id="statusMsg"><?= $success ?></div><?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error" id="statusMsg"><?= $error ?></div><?php endif; ?>

        <div class="section">
            <h2>👥 Benutzer-Management</h2>
            <table class="user-list">
                <?php while ($u = $users->fetch_assoc()): ?>
                    <tr id="user_row_<?= $u['id'] ?>">
                        <td>👤 <b><?= htmlspecialchars($u['nutzername']) ?></b></td>
                        <td style="text-align:right;">
                            <button class="btn btn-warning btn-small" style="width:auto; min-width:unset;"
                                onclick="showEditUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['nutzername']) ?>')"
                                title="Bearbeiten">✏️ Bearbeiten</button>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="action" value="delete_user">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-small" style="width:auto; min-width:unset;"
                                    onclick="return confirm('Löschen?')" title="Löschen">🗑️ Löschen</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>

            <div id="editZone"
                style="display:none; margin-top: 20px; padding: 15px; background: rgba(255,165,0,0.1); border-radius: 8px;">
                <h3>Benutzer bearbeiten</h3>
                <form method="post" style="display:grid; grid-template-columns: 1fr 1fr auto; gap:10px;">
                    <input type="hidden" name="action" value="edit_user">
                    <input type="hidden" name="user_id" id="edit_id">
                    <input type="text" name="username" id="edit_name" placeholder="Name">
                    <div style="position:relative; display:flex;">
                        <input type="password" name="password" id="pass_edit" placeholder="Neues Passwort (optional)"
                            style="padding-right:40px;">
                        <button type="button" onclick="togglePassword('pass_edit', this)"
                            style="position:absolute; right:5px; top:8px; background:none; border:none; color:white; cursor:pointer; font-size:18px;">👁️</button>
                    </div>
                    <button type="submit" class="btn btn-primary">Speichern</button>
                </form>
            </div>

            <h3 style="margin-top:30px; font-size:16px;">Neuen Admin hinzufügen</h3>
            <form method="post" style="display:grid; grid-template-columns: 1fr 1fr auto; gap:10px;">
                <input type="hidden" name="action" value="add_user">
                <input type="text" name="username" placeholder="Name" required>
                <div style="position:relative; display:flex;">
                    <input type="password" name="password" id="pass_add" placeholder="Passwort" required
                        style="padding-right:40px;">
                    <button type="button" onclick="togglePassword('pass_add', this)"
                        style="position:absolute; right:5px; top:8px; background:none; border:none; color:white; cursor:pointer; font-size:18px;">👁️</button>
                </div>
                <button type="submit" class="btn btn-success">Hinzufügen</button>
            </form>
        </div>

        <div class="section">
            <h2>🔑 Normaler Benutzerzugang</h2>
            <form method="post">
                <input type="hidden" name="action" value="update_user_pass">
                <label>Dateimanager-Passwort (Normalnutzer)</label>
                <input type="password" name="user_pass" required placeholder="Neues Passwort">
                <button type="submit" class="btn btn-primary">Speichern</button>
            </form>
        </div>

        <div class="section">
            <h2>🔐 Berechtigungen für Normalnutzer</h2>
            <form method="post">
                <input type="hidden" name="action" value="update_acl">
                <p style="font-size: 13px; color: #94a3b8; margin-bottom: 20px;">Legen Sie fest, welche Aktionen
                    Benutzer ohne Administratorrechte ausführen dürfen.</p>

                <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <label style="display:flex; align-items:center; cursor:pointer;">
                        <input type="checkbox" name="can_delete" <?= defined('USER_CAN_DELETE') && USER_CAN_DELETE ? 'checked' : '' ?> style="width:20px; margin-right:10px;">
                        🗑️ Löschen erlauben
                    </label>
                    <label style="display:flex; align-items:center; cursor:pointer;">
                        <input type="checkbox" name="can_rename" <?= defined('USER_CAN_RENAME') && USER_CAN_RENAME ? 'checked' : '' ?> style="width:20px; margin-right:10px;">
                        📄 Umbenennen erlauben
                    </label>
                    <label style="display:flex; align-items:center; cursor:pointer;">
                        <input type="checkbox" name="can_upload" <?= defined('USER_CAN_UPLOAD') && USER_CAN_UPLOAD ? 'checked' : '' ?> style="width:20px; margin-right:10px;">
                        📤 Upload erlauben
                    </label>
                    <label style="display:flex; align-items:center; cursor:pointer;">
                        <input type="checkbox" name="can_create" <?= defined('USER_CAN_CREATE') && USER_CAN_CREATE ? 'checked' : '' ?> style="width:20px; margin-right:10px;">
                        ➕ Erstellen erlauben
                    </label>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top:20px;">Rechte speichern</button>
            </form>
        </div>

        <div class="section">
            <h2>🖼️ Design & Hintergründe</h2>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_bg">
                <label>Bereich auswählen</label>
                <select name="bg_type">
                    <option value="web">Web-Login (Besucher)</option>
                    <option value="fm">Filemanager-Login</option>
                </select>
                <label>Neues Bild hochladen</label>
                <label class="custom-file-upload">
                    <input type="file" name="bg_file" accept="image/*" required
                        onchange="this.parentElement.querySelector('span').innerText = this.files[0].name"
                        style="display:none;">
                    <span>📁 Datei auswählen...</span>
                </label>
                <button type="submit" class="btn btn-success" style="margin-top:15px;">Aktualisieren</button>
            </form>
        </div>

        <div class="section">
            <h2>🔧 Rechteverwaltung (chmod)</h2>
            <p style="font-size:13px; opacity:0.7;">Wähle eine Datei im Dateimanager aus, um die Rechte anzupassen.</p>
            <form onsubmit="return handleChmod(event)" style="display:flex; gap:10px;">
                <input type="text" id="chmodPath" placeholder="Pfad (z.B. config/security.php)">
                <input type="text" id="chmodMode" placeholder="Mode (z.B. 0644)" style="width:100px;">
                <button type="submit" class="btn btn-primary">Anwenden</button>
            </form>
        </div>

        <div class="section" style="border:none;">
            <h2>ℹ️ System-Info & Wartung</h2>
            <p style="font-size:13px; opacity:0.7;">
                PHP-Version: <code><?= phpversion() ?></code><br>
                Root: <code><?= htmlspecialchars(realpath(__DIR__ . '/..')) ?></code>
            </p>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <form method="post">
                    <input type="hidden" name="action" value="php_update">
                    <button type="submit" class="btn btn-primary" style="width:200px;">🚀 Auf PHP-Update prüfen</button>
                </form>
                <form method="post">
                    <input type="hidden" name="action" value="cleanup_install">
                    <button type="submit" class="btn-danger" style="width:200px; padding:12px;"
                        onclick="return confirm('Sicher? Der /install Ordner wird unwiderruflich gelöscht.')">🧹
                        Installation bereinigen</button>
                </form>
            </div>
            <p style="font-size:12px; color:#94a3b8; margin-top:15px;">
                ⚠️ <b>Hinweis:</b> Der Ordner <code>config/</code> wird für die Sicherheitseinstellungen benötigt und
                darf nicht gelöscht werden.
            </p>
        </div>
    </div>

    <script>
        function toggleDarkMode() {
            const isDark = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDark ? 'true' : 'false');
        }

        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark-mode');
        } else if (localStorage.getItem('darkMode') === 'false') {
            document.body.classList.remove('dark-mode');
        }

        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
                btn.textContent = "👁️‍🗨️";
            } else {
                input.type = "password";
                btn.textContent = "👁️";
            }
        }

        function showEditUser(id, name) {
            document.getElementById('editZone').style.display = 'block';
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            window.scrollTo({ top: document.getElementById('editZone').offsetTop - 100, behavior: 'smooth' });
        }

        // Auto-Hide Alerts nach 15s
        setTimeout(() => {
            const msg = document.getElementById('statusMsg');
            if (msg) msg.style.opacity = '0';
        }, 15000);

        async function handleChmod(e) {
            e.preventDefault();
            const path = document.getElementById('chmodPath').value;
            const mode = document.getElementById('chmodMode').value;
            const res = await fetch('api.php', {
                method: 'POST',
                body: JSON.stringify({ action: 'chmod', path, mode })
            });
            const data = await res.json();
            alert(data.success || data.error);
        }
    </script>
</body>

</html>