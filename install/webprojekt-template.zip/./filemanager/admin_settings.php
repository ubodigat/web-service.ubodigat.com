<?php
declare(strict_types=1);
session_start();

// 1. Sicherheit: Nur Admins!
if (empty($_SESSION['admin_access'])) {
    header('Location: admin_login.php');
    exit;
}

$securityFile = __DIR__ . '/../config/security.php';
if (!file_exists($securityFile)) {
    die('❌ security.php fehlt.');
}
require_once $securityFile;

$success = '';
$error = '';

// 2. Verarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_user_pass') {
        $newPass = $_POST['user_pass'] ?? '';
        if (strlen($newPass) < 4) {
            $error = '❌ Passwort zu kurz (min. 4 Zeichen).';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            // Datei neu schreiben (Primitiv aber effektiv für dieses Setup)
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FILEMANAGER_ACCESS_HASH', '.*?'\);/", "define('FILEMANAGER_ACCESS_HASH', '{$hash}');", $content);
            file_put_contents($securityFile, $content);
            $success = '✅ Normalnutzer-Passwort erfolgreich aktualisiert.';
        }
    }

    if ($action === 'update_bg') {
        $bgType = $_POST['bg_type'] ?? '';
        if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir))
                mkdir($uploadDir, 0755, true);

            $ext = pathinfo($_FILES['bg_file']['name'], PATHINFO_EXTENSION);
            $newName = 'bg_' . bin2hex(random_bytes(8)) . '.' . $ext;

            if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $uploadDir . $newName)) {
                $path = '/uploads/' . $newName;
                $content = file_get_contents($securityFile);
                $const = ($bgType === 'web') ? 'WEB_LOGIN_BG' : 'FILEMANAGER_LOGIN_BG';
                $content = preg_replace("/define\('{$const}', '.*?'\);/", "define('{$const}', '{$path}');", $content);
                file_put_contents($securityFile, $content);
                $success = '✅ Hintergrundbild aktualisiert.';
            } else {
                $error = '❌ Upload fehlgeschlagen.';
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>⚙️ Admin-Einstellungen</title>
    <link rel="icon" type="image/svg+xml" href="https://web-service.ubodigat.com/ubodigatlogo.svg">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --bg: #070A12;
            --accent: #2DE2E6;
            --card: rgba(255, 255, 255, 0.05);
        }

        body {
            font-family: sans-serif;
            background: #0b141a;
            color: white;
            display: flex;
            justify-content: center;
            padding: 20px;
        }

        .box {
            width: 100%;
            max-width: 600px;
            background: var(--card);
            padding: 30px;
            border-radius: 16px;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        h1,
        h2 {
            color: var(--accent);
            margin-top: 0;
        }

        .section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 14px;
        }

        input[type="text"],
        input[type="password"],
        select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #333;
            background: #000;
            color: white;
            margin-bottom: 15px;
        }

        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }

        .btn-primary {
            background: var(--accent);
            color: #000;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .alert-success {
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid #28a745;
        }

        .alert-error {
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            border: 1px solid #dc3545;
        }

        .nav {
            margin-bottom: 20px;
        }

        .nav a {
            color: #aaa;
            text-decoration: none;
            font-size: 14px;
        }

        .nav a:hover {
            color: white;
        }
    </style>
</head>

<body>
    <div class="box">
        <div class="nav"><a href="file_manager.php">⬅ Zurück zum Dateimanager</a></div>
        <h1>⚙️ Admin-Einstellungen</h1>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <?= $success ?>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <div class="section">
            <h2>🔑 Normaler Benutzerzugang</h2>
            <form method="post">
                <input type="hidden" name="action" value="update_user_pass">
                <label>Neues Passwort für den Dateimanager (Normalnutzer)</label>
                <input type="password" name="user_pass" required placeholder="Neues Passwort">
                <button type="submit" class="btn btn-primary">Passwort speichern</button>
            </form>
        </div>

        <div class="section">
            <h2>🖼️ Design & Hintergründe</h2>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_bg">
                <label>Bereich auswählen</label>
                <select name="bg_type">
                    <option value="web">Web-Login (Besucher)</option>
                    <option value="fm">Filemanager-Login</option>
                </select>
                <label>Neues Bild hochladen</label>
                <input type="file" name="bg_file" accept="image/*" required>
                <button type="submit" class="btn btn-primary">Bild aktualisieren</button>
            </form>
        </div>

        <div class="section" style="border:none;">
            <h2>ℹ️ System-Info</h2>
            <p style="font-size:13px; opacity:0.7;">
                Root-Verzeichnis: <code><?= htmlspecialchars(realpath(__DIR__ . '/..')) ?></code><br>
                PHP-Version: <code><?= phpversion() ?></code><br>
                Admin-Sitzung: <code>Aktiv</code>
            </p>
        </div>
    </div>
</body>

</html>