<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

// 1. Konfiguration laden
// Wir gehen davon aus, dass config im selben Ordner oder relativ dazu liegt.
// Hier: Sicherheits-Config liegt standardmäßig in ../config/
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Konfiguration fehlt.']);
    exit;
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    echo json_encode(['error' => 'Nicht eingeloggt.']);
    exit;
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    echo json_encode(['error' => 'Session abgelaufen.', 'redirect' => 'logout_admin.php?timeout=1']);
    exit;
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad (VORLAGEN-TAUGLICH!)
// Der Filemanager darf standardmäßig nur in SEINEM EIGENEN Ordner arbeiten (und Unterordnern).
// Wenn er woanders arbeiten soll, muss das in der config.php stehen.
// Hier als Fallback: Das aktuelle Verzeichnis (__DIR__).
$baseDir = realpath(__DIR__ . '/..');

$isAdmin = !empty($_SESSION['admin_access']);

// -------------------------------------------------------------------
// Hilfsfunktion: Pfad validieren
// -------------------------------------------------------------------
function resolvePath(string $inputPath, string $baseDir): ?string
{
    $realPath = realpath($inputPath);

    // Sonderfall: Bei Erstellung existiert Datei noch nicht -> Parent prüfen
    if (!$realPath) {
        $dir = dirname($inputPath);
        $realDir = realpath($dir);
        if ($realDir) {
            $realPath = $realDir . DIRECTORY_SEPARATOR . basename($inputPath);
        } else {
            return null;
        }
    }

    // Sandbox Check: Pfad muss mit BaseDir beginnen
    $realBase = realpath($baseDir);
    if ($realBase && strpos($realPath, $realBase) === 0) {
        return $realPath;
    }

    return null; // Ausbruchsversuch!
}

// -------------------------------------------------------------------
// Request Verarbeitung
// -------------------------------------------------------------------

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? $_POST['action'] ?? '';
$path = $input['path'] ?? $_POST['path'] ?? '';

// Pfad normalisieren
if (!$path) {
    $path = $baseDir;
}

// Sicherheits-Check des Pfades
$targetPath = resolvePath($path, $baseDir);

if (!$targetPath) {
    echo json_encode(['status' => 'error', 'message' => 'Zugriff verweigert (Ungültiger Pfad)']);
    exit;
}

try {
    switch ($action) {
        case 'list':
            if (!is_dir($targetPath))
                throw new Exception("Verzeichnis nicht gefunden.");
            $files = scandir($targetPath);
            $result = [];
            foreach ($files as $f) {
                if ($f === '.' || $f === '..')
                    continue;
                if (in_array($f, ['api.php', 'upload.php', 'download.php', 'config.php', 'admin_login.php', 'login_filemanager.php']))
                    continue;

                $full = $targetPath . DIRECTORY_SEPARATOR . $f;
                $result[] = [
                    'name' => $f,
                    'type' => is_dir($full) ? 'folder' : 'file',
                    'date' => date('d.m.Y H:i', filemtime($full))
                ];
            }
            usort($result, function ($a, $b) {
                return $b['type'] <=> $a['type'];
            });
            echo json_encode(['status' => 'success', 'files' => $result, 'currentPath' => $targetPath]);
            break;

        case 'get_content':
        case 'open':
            if (!is_file($targetPath))
                throw new Exception("Keine Datei.");
            echo json_encode(['status' => 'success', 'content' => file_get_contents($targetPath)]);
            break;

        case 'save_content':
        case 'save':
            if (!$isAdmin) {
                $ext = pathinfo($targetPath, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), ['php', 'phtml', 'htaccess', 'env'])) {
                    throw new Exception("Sicherheitswarnung: Dateityp verboten.");
                }
            }
            $content = $input['content'] ?? $_POST['content'] ?? '';
            if (file_put_contents($targetPath, $content) === false)
                throw new Exception("Speichern fehlgeschlagen.");
            echo json_encode(['status' => 'success']);
            break;

        case 'create':
            if (!$isAdmin)
                throw new Exception("Keine Berechtigung.");
            $type = $input['type'] ?? $_POST['type'] ?? 'file';
            $name = $input['fileName'] ?? $_POST['fileName'] ?? '';
            if (!$name)
                throw new Exception("Kein Name angegeben.");

            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");

            if (file_exists($newPath))
                throw new Exception("Bereits vorhanden.");
            if ($type === 'folder') {
                if (!mkdir($newPath, 0755))
                    throw new Exception("Ordner erstellen fehlgeschlagen.");
            } else {
                if (file_put_contents($newPath, "") === false)
                    throw new Exception("Datei erstellen fehlgeschlagen.");
            }
            echo json_encode(['status' => 'success']);
            break;

        case 'create_folder':
            if (!$isAdmin)
                throw new Exception("Keine Berechtigung.");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Ordnername.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Ordner existiert bereits.");
            if (!mkdir($newPath, 0755))
                throw new Exception("Konnte Ordner nicht erstellen.");
            echo json_encode(['status' => 'success']);
            break;

        case 'create_file':
            if (!$isAdmin)
                throw new Exception("Keine Berechtigung.");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Dateiname.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Datei existiert bereits.");
            if (file_put_contents($newPath, "") === false)
                throw new Exception("Konnte Datei nicht erstellen.");
            echo json_encode(['status' => 'success']);
            break;

        case 'delete':
            if (!$isAdmin)
                throw new Exception("Keine Berechtigung.");
            if (is_dir($targetPath)) {
                if (!rmdir($targetPath))
                    throw new Exception("Ordner muss leer sein.");
            } else {
                if (!unlink($targetPath))
                    throw new Exception("Löschen fehlgeschlagen.");
            }
            echo json_encode(['status' => 'success']);
            break;

        case 'rename':
            if (!$isAdmin)
                throw new Exception("Keine Berechtigung.");
            $newName = $input['newName'] ?? $_POST['newName'] ?? '';
            if (!$newName)
                throw new Exception("Kein neuer Name.");

            $dir = dirname($targetPath);
            $newPath = $dir . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $newName);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Zielpfad unzulässig.");

            if (!rename($targetPath, $newPath))
                throw new Exception("Umbenennen fehlgeschlagen.");
            echo json_encode(['status' => 'success']);
            break;

        default:
            throw new Exception("Unbekannte Aktion.");
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}