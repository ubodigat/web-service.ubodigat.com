<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

// 1. Konfiguration laden
// Wir gehen davon aus, dass config im selben Ordner oder relativ dazu liegt.
// Hier: Sicherheits-Config liegt standardmäßig in ../config/
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Konfiguration fehlt.']);
    exit;
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    echo json_encode(['error' => 'Nicht eingeloggt.']);
    exit;
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    echo json_encode(['error' => 'Session abgelaufen.', 'redirect' => 'logout_admin.php?timeout=1']);
    exit;
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad (VORLAGEN-TAUGLICH!)
// Der Filemanager darf standardmäßig nur in SEINEM EIGENEN Ordner arbeiten (und Unterordnern).
// Wenn er woanders arbeiten soll, muss das in der config.php stehen.
// Hier als Fallback: Das aktuelle Verzeichnis (__DIR__).
$baseDir = realpath(__DIR__ . '/..');

$isAdmin = !empty($_SESSION['admin_access']);

// -------------------------------------------------------------------
// Hilfsfunktion: Pfad validieren
// -------------------------------------------------------------------
function resolvePath(string $inputPath, string $baseDir): ?string
{
    $realPath = realpath($inputPath);

    // Sonderfall: Bei Erstellung existiert Datei noch nicht -> Parent prüfen
    if (!$realPath) {
        $dir = dirname($inputPath);
        $realDir = realpath($dir);
        if ($realDir) {
            $realPath = $realDir . DIRECTORY_SEPARATOR . basename($inputPath);
        } else {
            return null;
        }
    }

    // Sandbox Check: Pfad muss mit BaseDir beginnen
    $realBase = realpath($baseDir);
    if ($realBase && strpos($realPath, $realBase) === 0) {
        return $realPath;
    }

    return null; // Ausbruchsversuch!
}

// -------------------------------------------------------------------
// Hilfsfunktion: Berechtigungen prüfen
// -------------------------------------------------------------------
function hasPermission(string $action, string $path, string $baseDir, bool $isAdmin): bool
{
    if ($isAdmin)
        return true;

    // Relative Pfad-Ermittlung
    $relPath = str_replace([$baseDir, DIRECTORY_SEPARATOR], ['', '/'], $path);
    $relPath = trim($relPath, '/');

    // Globale Defaults
    $canDelete = defined('USER_CAN_DELETE') ? USER_CAN_DELETE : false;
    $canRename = defined('USER_CAN_RENAME') ? USER_CAN_RENAME : true;
    $canUpload = defined('USER_CAN_UPLOAD') ? USER_CAN_UPLOAD : true;
    $canCreate = defined('USER_CAN_CREATE') ? USER_CAN_CREATE : true;

    // Ordnerspezifische Overrides laden
    $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];

    // Prüfe ob für diesen Pfad (oder einen Parent) Regeln existieren
    // Wir suchen den tiefsten passenden Pfad
    $bestMatch = '';
    foreach ($folderPerms as $p => $rules) {
        if ($relPath === $p || (strpos($relPath, $p . '/') === 0)) {
            if (strlen($p) >= strlen($bestMatch)) {
                $bestMatch = $p;
            }
        }
    }

    if ($bestMatch !== '' && isset($folderPerms[$bestMatch])) {
        $rules = $folderPerms[$bestMatch];
        $canDelete = isset($rules['delete']) ? $rules['delete'] : $canDelete;
        $canRename = isset($rules['rename']) ? $rules['rename'] : $canRename;
        $canUpload = isset($rules['upload']) ? $rules['upload'] : $canUpload;
        $canCreate = isset($rules['create']) ? $rules['create'] : $canCreate;
    }

    switch ($action) {
        case 'delete':
            return $canDelete;
        case 'rename':
            return $canRename;
        case 'upload':
            return $canUpload;
        case 'create':
            return $canCreate;
        default:
            return false;
    }
}

// -------------------------------------------------------------------
// Request Verarbeitung
// -------------------------------------------------------------------

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_REQUEST['action'] ?? '';
$path = $input['path'] ?? $_REQUEST['path'] ?? $_REQUEST['dir'] ?? '';

// Pfad normalisieren
if (!$path) {
    $path = $baseDir;
}

// Sicherheits-Check des Pfades
$targetPath = resolvePath($path, $baseDir);

if (!$targetPath) {
    echo json_encode(['status' => 'error', 'message' => 'Zugriff verweigert (Ungültiger Pfad)']);
    exit;
}

try {
    switch ($action) {
        case 'list':
            if (!is_dir($targetPath))
                throw new Exception("Verzeichnis nicht gefunden.");
            $files = scandir($targetPath);
            $result = [];
            foreach ($files as $f) {
                if ($f === '.' || $f === '..')
                    continue;
                if (in_array($f, ['api.php', 'upload.php', 'download.php', 'config.php', 'admin_login.php', 'login_filemanager.php']))
                    continue;

                $full = $targetPath . DIRECTORY_SEPARATOR . $f;
                $result[] = [
                    'name' => $f,
                    'type' => is_dir($full) ? 'folder' : 'file',
                    'date' => date('d.m.Y H:i', filemtime($full))
                ];
            }
            // Sortierung: Ordner zuerst
            usort($result, function ($a, $b) {
                return $b['type'] <=> $a['type'];
            });

            // Filterung für Nicht-Admins (Sicherheit & Sichtbarkeit)
            if (!$isAdmin) {
                $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env'];
                $visSettings = defined('VISIBILITY_SETTINGS') ? json_decode(VISIBILITY_SETTINGS, true) : [];

                $result = array_filter($result, function ($file) use ($sensitive, $targetPath, $baseDir, $visSettings) {
                    if (in_array($file['name'], $sensitive))
                        return false;

                    // Sichtbarkeits-Prüfung
                    $relDir = str_replace([$baseDir, DIRECTORY_SEPARATOR], ['', '/'], $targetPath);
                    $relPath = trim($relDir . '/' . $file['name'], '/');

                    // Prüfe alle Parent-Ordner auf Sichtbarkeit
                    $parts = explode('/', $relPath);
                    $checkPath = '';
                    foreach ($parts as $part) {
                        $checkPath = trim($checkPath . '/' . $part, '/');
                        if (isset($visSettings[$checkPath]) && $visSettings[$checkPath] === 'private') {
                            return false;
                        }
                    }

                    return true;
                });
                $result = array_values($result); // Keys zurücksetzen
            }

            echo json_encode(['success' => true, 'files' => $result, 'currentPath' => $targetPath, 'isAdmin' => $isAdmin]);
            break;

        case 'get_content':
        case 'open':
            if (!is_file($targetPath))
                throw new Exception("Keine Datei.");
            echo json_encode(['success' => true, 'content' => file_get_contents($targetPath)]);
            break;

        case 'save_content':
        case 'save':
            if (!$isAdmin) {
                $ext = pathinfo($targetPath, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), ['php', 'phtml', 'htaccess', 'env'])) {
                    throw new Exception("Sicherheitswarnung: Dateityp verboten.");
                }
            }
            $content = $input['content'] ?? $_POST['content'] ?? '';
            if (file_put_contents($targetPath, $content) === false)
                throw new Exception("Speichern fehlgeschlagen.");
            echo json_encode(['success' => 'Datei erfolgreich gespeichert.']);
            break;

        case 'create':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $type = $input['type'] ?? $_POST['type'] ?? 'file';
            $name = $input['fileName'] ?? $_POST['fileName'] ?? '';
            if (!$name)
                throw new Exception("Kein Name angegeben.");

            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");

            if (file_exists($newPath))
                throw new Exception("Bereits vorhanden.");
            if ($type === 'folder') {
                if (!mkdir($newPath, 0755))
                    throw new Exception("Ordner erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Ordner erfolgreich erstellt.']);
            } else {
                if (file_put_contents($newPath, "") === false)
                    throw new Exception("Datei erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Datei erfolgreich erstellt.']);
            }
            break;

        case 'create_folder':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Ordnername.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Ordner existiert bereits.");
            if (!mkdir($newPath, 0755))
                throw new Exception("Konnte Ordner nicht erstellen.");
            echo json_encode(['success' => 'Ordner erstellt.']);
            break;

        case 'create_file':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Dateiname.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Datei existiert bereits.");
            if (file_put_contents($newPath, "") === false)
                throw new Exception("Konnte Datei nicht erstellen.");
            echo json_encode(['success' => 'Datei erstellt.']);
            break;

        case 'delete':
            if (!hasPermission('delete', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Löschen nicht erlaubt).");
            if (is_dir($targetPath)) {
                // Rekursives Löschen von Ordnern (Vorsicht!)
                $it = new RecursiveDirectoryIterator($targetPath, RecursiveDirectoryIterator::SKIP_DOTS);
                $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                foreach ($files as $file) {
                    if ($file->isDir())
                        rmdir($file->getRealPath());
                    else
                        unlink($file->getRealPath());
                }
                rmdir($targetPath);
            } else {
                unlink($targetPath);
            }
            echo json_encode(['success' => 'Erfolgreich gelöscht.']);
            break;

        case 'rename':
            if (!hasPermission('rename', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Umbenennen nicht erlaubt).");
            $oldName = $input['oldName'] ?? $_POST['oldName'] ?? '';
            $newName = $input['newName'] ?? $_POST['newName'] ?? '';
            if (!$oldName || !$newName)
                throw new Exception("Namen fehlen.");

            $oldPath = $targetPath . DIRECTORY_SEPARATOR . $oldName;
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $newName);

            if (!resolvePath($oldPath, $baseDir) || !resolvePath($newPath, $baseDir)) {
                throw new Exception("Pfad-Fehler.");
            }
            if (rename($oldPath, $newPath)) {
                echo json_encode(['success' => 'Umbenannt.']);
            } else {
                throw new Exception("Umbenennen fehlgeschlagen.");
            }
            break;

        case 'chmod':
            if (!$isAdmin)
                throw new Exception('Admin-Rechte erforderlich.');
            $path = $input['path'] ?? ''; // Changed from $data to $input
            $mode = $input['mode'] ?? ''; // z.B. "0755" // Changed from $data to $input
            $full = realpath($baseDir . '/' . $path);
            if (!$full || strpos($full, $baseDir) !== 0)
                throw new Exception('Ungültiger Pfad.');

            // Konvertierung von String (Oktal) zu Int
            $octalMode = octdec($mode);
            if (chmod($full, (int) $octalMode)) {
                echo json_encode(['success' => "Berechtigungen für " . basename($full) . " auf $mode geändert."]);
            } else {
                throw new Exception('chmod fehlgeschlagen.');
            }
            break;

        case 'get_visibility':
            $rel = $_GET['path'] ?? '';
            $rel = str_replace(['\\', $baseDir], ['/', ''], $rel);
            $rel = trim($rel, '/');
            $visSettings = defined('VISIBILITY_SETTINGS') ? json_decode(VISIBILITY_SETTINGS, true) : [];
            echo json_encode(['status' => $visSettings[$rel] ?? 'public']);
            break;

        case 'set_visibility':
            if (!$isAdmin)
                throw new Exception("Admin-Rechte erforderlich.");
            $rel = $input['path'] ?? '';
            $status = $input['status'] ?? 'public'; // 'public' oder 'private'
            $rel = str_replace(['\\', $baseDir], ['/', ''], $rel);
            $rel = trim($rel, '/');

            $visSettings = defined('VISIBILITY_SETTINGS') ? json_decode(VISIBILITY_SETTINGS, true) : [];
            if ($status === 'private') {
                $visSettings[$rel] = 'private';
            } else {
                unset($visSettings[$rel]);
            }

            $json = json_encode($visSettings);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('VISIBILITY_SETTINGS', '.*?'\);/", "define('VISIBILITY_SETTINGS', '$json');", $content);
            file_put_contents($securityFile, $content);
            echo json_encode(['success' => "Sichtbarkeit für " . ($rel ?: 'Root') . " auf $status gesetzt."]);
            break;

        default:
            throw new Exception('Unbekannte Aktion: ' . $action);
    }

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}