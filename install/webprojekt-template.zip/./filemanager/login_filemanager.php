<?php
declare(strict_types=1);
session_start();

$security = __DIR__ . '/../config/security.php';
if (!file_exists($security)) {
    http_response_code(500);
    die('❌ security.php fehlt. Bitte zuerst /install/setup.php ausführen.');
}
require_once $security;

$bg = defined('FILEMANAGER_LOGIN_BG') && FILEMANAGER_LOGIN_BG
    ? "background-image:url('/" . ltrim(FILEMANAGER_LOGIN_BG, '/') . "')"
    : "background:radial-gradient(circle at top,#0f172a,#020617)";


$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';

function doLogout(string $cookie_name): void
{
    session_unset();
    session_destroy();
    setcookie($cookie_name, '', time() - 3600, '/filemanager');
}

if (isset($_SESSION[$session_key]) && $_SESSION[$session_key] === true) {
    if (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) {
        $last = (int) ($_SESSION['filemanager_last_action'] ?? 0);
        if ($last > 0 && (time() - $last) > FILEMANAGER_TIMEOUT) {
            doLogout($cookie_name);
        } else {
            $_SESSION['filemanager_last_action'] = time();
        }
    } else {
        $_SESSION['filemanager_last_action'] = time();
    }
}

if (
    isset($_SESSION[$session_key]) &&
    $_SESSION[$session_key] === true &&
    isset($_COOKIE[$cookie_name]) &&
    $_COOKIE[$cookie_name] === '1'
) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    if ($pass !== '' && defined('FILEMANAGER_ACCESS_HASH') && password_verify($pass, FILEMANAGER_ACCESS_HASH)) {

        $_SESSION[$session_key] = true;
        $_SESSION['filemanager_last_action'] = time();

        $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
            ? time() + FILEMANAGER_TIMEOUT
            : time() + 86400;

        setcookie(
            $cookie_name,
            '1',
            [
                'expires' => $cookieExpires,
                'path' => '/filemanager',
                'secure' => isset($_SERVER['HTTPS']),
                'httponly' => true,
                'samesite' => 'Strict'
            ]
        );

        header('Location: file_manager.php');
        exit;

    } else {
        $error = '❌ Falsches Passwort';
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Filemanager Login</title>
    <link rel="icon" type="image/png" href="/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: radial-gradient(circle at top, #0f172a, #020617);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
            color: #e5e7eb;
            padding: 24px;
            <?= $bg ?>
            ;
            background-size: cover;
            background-attachment: fixed;
        }

        .card {
            width: 100%;
            max-width: 380px;
            background: rgba(15, 23, 42, .92);
            backdrop-filter: blur(14px);
            border-radius: 18px;
            padding: 36px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, .7);
            border: 1px solid rgba(34, 48, 74, .7);
            text-align: center;
        }

        .logo {
            width: 150px;
            margin-bottom: 18px
        }

        h2 {
            margin: 10px 0 18px;
            font-size: 20px
        }

        small {
            display: block;
            color: #94a3b8;
            line-height: 1.5;
            margin-bottom: 16px
        }

        input {
            width: 100%;
            padding: 14px;
            border-radius: 10px;
            border: 1px solid #334155;
            background: #020617;
            color: #e5e7eb;
            font-size: 15px;
        }

        input:focus {
            outline: none;
            border-color: #38bdf8
        }

        button {
            width: 100%;
            margin-top: 18px;
            padding: 14px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #22c55e, #4ade80);
            color: #022c22;
            font-size: 16px;
            font-weight: 800;
            cursor: pointer;
        }

        .error {
            margin-top: 14px;
            color: #f87171;
            font-weight: 700;
        }
    </style>
</head>

<body>
    <form method="post" class="card">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
        <h2>🔐 Filemanager-Zugriff</h2>
        <small>Passwort wurde im Setup festgelegt. (Nicht im Code gespeichert)</small>

        <input type="password" name="password" placeholder="Passwort eingeben" required autofocus>
        <button type="submit">Einloggen</button>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </form>
</body>

</html>