<?php
header("Location: login_filemanager.php");
exit;
