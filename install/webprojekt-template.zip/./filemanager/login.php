<?php
declare(strict_types=1);
session_start();

require_once __DIR__ . '/../config/security.php';

$timeout = WEB_LOGIN_TIMEOUT ?? 1800;
$sessionKey = 'eingeloggt';

if (isset($_SESSION[$sessionKey])) {
    if (time() - ($_SESSION['last_action'] ?? 0) < $timeout) {
        $_SESSION['last_action'] = time();
        header('Location: index.php');
        exit;
    }
    session_destroy();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'] ?? '';

    if (
        WEB_ACCESS_ENABLED === false ||
        password_verify($code, WEB_ACCESS_HASH)
    ) {
        $_SESSION[$sessionKey] = true;
        $_SESSION['last_action'] = time();
        header('Location: index.php');
        exit;
    }

    $error = '❌ Falscher Code';
}

$bg = WEB_LOGIN_BG
    ? "background-image:url('" . htmlspecialchars(WEB_LOGIN_BG) . "')"
    : "background:#f4f6fb";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Login</title>
    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            height: 100%;
            margin: 0;
            <?= $bg ?>
            ;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
            padding: 40px 30px;
            width: 100%;
            max-width: 320px;
            text-align: center;
            color: #000;
        }

        .login-box h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .login-box input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.9);
        }

        .login-box button {
            width: 100%;
            padding: 12px;
            font-size: 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-box button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-weight: bold;
        }

        @media (max-height: 500px) {
            body {
                align-items: flex-start;
                padding-top: 20px;
            }
        }
    </style>
</head>

<body>
    <form method="POST" class="login-box">
        <h2>🔒 Zugang gesperrt</h2>
        <input type="password" name="code" placeholder="Zahlencode eingeben" required>
        <button type="submit">Einloggen</button>
        <?php if (!empty($error))
            echo "<p class='error'>$error</p>"; ?>
    </form>
</body>

</html>