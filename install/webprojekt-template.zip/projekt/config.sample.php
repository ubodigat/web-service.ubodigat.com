<?php
define("DB_NAME", "DB_NAME_PLACEHOLDER");
define("DB_USER", "DB_USER_PLACEHOLDER");
define("DB_PASS", "DB_PASS_PLACEHOLDER");
?>