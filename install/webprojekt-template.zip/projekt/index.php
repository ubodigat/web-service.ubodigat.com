<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>Willkommen</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>🚀 Willkommen auf deiner neuen Webseite</h1>
  <p>Dies ist eine leere Projektvorlage. Du kannst die Dateien hier mit dem Dateimanager bearbeiten oder eigene hochladen.</p>
</body>
</html>
