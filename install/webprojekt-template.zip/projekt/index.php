<?php
declare(strict_types=1);

/* =========================================
   🔐 Web-Access Schutz einbinden
   ========================================= */
// 1. Config laden (Relativ zum Projektordner)
$securityFile = __DIR__ . '/../config/security.php';

if (file_exists($securityFile)) {
    require_once $securityFile;

    // 2. Prüfung: Ist Schutz AN? Und fehlt das Cookie?
    if (
        defined('WEB_ACCESS_ENABLED') &&
        WEB_ACCESS_ENABLED === true &&
        (empty($_COOKIE['web_access']) || $_COOKIE['web_access'] !== '1')
    ) {
        // 3. Zurück zum Login (Relativer Pfad für Portabilität!)
        header('Location: ../web_login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mein neues Projekt</title>
    <style>
        body {
            font-family: system-ui, -apple-system, sans-serif;
            background-color: #f0f2f5;
            color: #1f2937;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            text-align: center;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            max-width: 500px;
        }
        h1 { color: #2563eb; margin-bottom: 1rem; }
        p { line-height: 1.6; color: #4b5563; }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #2563eb;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .btn:hover { background: #1d4ed8; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Projekt erfolgreich erstellt</h1>
        <p>
            Dies ist die Startseite deines neuen Projekts.<br>
            Du kannst diese Datei (<code>index.php</code>) bearbeiten oder löschen.
        </p>
        <p>
            Nutze den Dateimanager, um deine Webseite aufzubauen.
        </p>
        <a href="../filemanager/" class="btn">Zum Dateimanager</a>
    </div>
</body>
</html>