-- Optionale Beispielstruktur
CREATE TABLE IF NOT EXISTS einstellungen (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schluessel VARCHAR(100),
    wert TEXT
);