<?php
declare(strict_types=1);

define('WEB_ACCESS_ENABLED', false);
define('WEB_ACCESS_HASH', '');

define('FILEMANAGER_TIMEOUT', 1800);

define('WEB_LOGIN_BG', '');
define('FILEMANAGER_LOGIN_BG', '');

// ACL für Normalnutzer (Admins dürfen immer alles)
define('USER_CAN_DELETE', false);
define('USER_CAN_RENAME', true);
define('USER_CAN_UPLOAD', true);
define('USER_CAN_CREATE', true);

// Ordnerspezifische Rechte (JSON-Objekt)
define('FOLDER_PERMISSIONS', '[]');

// Benutzerspezifische Rechte (JSON-Objekt {"username": {"delete":false,...}})
define('USER_PERMISSIONS', '{}');

// Sichtbarkeitseinstellungen (JSON-Array)
define('VISIBILITY_SETTINGS', '[]');

// Sicherheitsrichtlinien
define('REQUIRE_2FA', false);
define('PW_MIN_LENGTH', 15);
define('PW_REQUIRE_LOWERCASE', true);
define('PW_REQUIRE_UPPERCASE', true);
define('PW_REQUIRE_NUMBER', true);
define('PW_REQUIRE_SPECIAL', true);
