<?php
header("Location: /install/setup.php");
exit;
