<?php
session_start();

$admin_passcode = "DEIN_GEHEIMER_ADMIN_CODE";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST["code"] === $admin_passcode) {
        $_SESSION["admin_access"] = true;
        header("Location: file_manager.php");
        exit;
    } else {
        $fehler = "❌ Falscher Admin-Code!";
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <style>
    body {
        margin: 0;
        padding: 0;
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background: #0b141a;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        position: relative;
    }

    body::before {
        content: "";
        position: absolute;
        top: 50%;
        left: 50%;
        width: 80vw;
        height: 80vh;
        background: url('ubodigat logo breit transparent.png') no-repeat center center;
        background-size: contain;
        opacity: 0.06;
        transform: translate(-50%, -50%) scale(1);
        animation: pulseBackground 12s ease-in-out infinite;
        z-index: 0;
    }

    @keyframes pulseBackground {
        0%, 100% {
            transform: translate(-50%, -50%) scale(1);
        }
        50% {
            transform: translate(-50%, -50%) scale(1.05);
        }
    }

    @keyframes backgroundAnimation {
        0% {background-position: 0% 50%;}
        50% {background-position: 100% 50%;}
        100% {background-position: 0% 50%;}
    }

    .login-box {
        position: relative;
        z-index: 1;
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(30px);
        -webkit-backdrop-filter: blur(30px);
        border-radius: 20px;
        padding: 40px;
        width: 320px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        text-align: center;
        animation: fadeIn 1s ease-in-out;
    }
    
    input[type="password"] {
        width: 100%;
        padding: 14px;
        margin: 20px 0;
        border: none;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.15);
        color: white;
        font-size: 16px;
    }

    input::placeholder {
        color: rgba(255, 255, 255, 0.8);
    }

    button {
        padding: 12px 25px;
        background: rgba(0, 123, 255, 0.85);
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    button:hover {
        background: rgba(0, 123, 255, 1);
    }

    .error {
        color: #ff9999;
        margin-top: 15px;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: scale(0.95);
        }
        to {
            opacity: 1;
            transform: scale(1);
        }
    }

</style>
</head>
<body>
    <form method="POST" class="login-box">
        <h2>🔐 Admin Login</h2>
        <input type="password" name="code" placeholder="Admin-Code eingeben" required>
        <button type="submit">Einloggen</button>
        <?php if (!empty($fehler)) echo "<p class='error'>$fehler</p>"; ?>
    </form>
</body>
</html>