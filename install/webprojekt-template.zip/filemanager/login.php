<?php
session_start();
$passwort = "4873";
$timeout = 20 * 60;

if (isset($_SESSION["eingeloggt"]) && $_SESSION["eingeloggt"] === true) {
    if (isset($_SESSION["last_action"]) && (time() - $_SESSION["last_action"] < $timeout)) {
        $_SESSION["last_action"] = time();
        header("Location: " . ($_SESSION["redirect_after_login"] ?? "index.php"));
        exit;
    } else {
        session_unset();
        session_destroy();
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST["code"] === $passwort) {
        $_SESSION["eingeloggt"] = true;
        $_SESSION["last_action"] = time();
        $ziel = $_SESSION["redirect_after_login"] ?? "index.php";
        unset($_SESSION["redirect_after_login"]);
        header("Location: " . $ziel);
        exit;
    } else {
        $fehler = "❌ Falscher Code!";
    }
}

if (!isset($_SESSION["redirect_after_login"])) {
    $_SESSION["redirect_after_login"] = $_SERVER["REQUEST_URI"];
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>🔐 Login</title>
    <style>
        * { box-sizing: border-box; }
        html, body {
            height: 100%;
            margin: 0;
            background: url('/bs1-hintergrund.webp') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
            padding: 40px 30px;
            width: 100%;
            max-width: 320px;
            text-align: center;
            color: #000;
        }

        .login-box h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .login-box input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.9);
        }

        .login-box button {
            width: 100%;
            padding: 12px;
            font-size: 15px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-box button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-weight: bold;
        }

        @media (max-height: 500px) {
            body {
                align-items: flex-start;
                padding-top: 20px;
            }
        }
    </style>
</head>
<body>
    <form method="POST" class="login-box">
        <h2>🔒 Zugang gesperrt</h2>
        <input type="password" name="code" placeholder="Zahlencode eingeben" required>
        <button type="submit">Einloggen</button>
        <?php if (!empty($fehler)) echo "<p class='error'>$fehler</p>"; ?>
    </form>
</body>
</html>