<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    echo json_encode(['error' => 'Konfiguration fehlt.', 'redirect' => '../install/setup.php']);
    exit;
}


require_once $securityFile;
require_once $configFile;
require_once __DIR__ . '/fm_common.php';

$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if ((empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) || empty($_COOKIE[$cookieName])) {
    http_response_code(403);
    echo json_encode(['error' => 'Nicht eingeloggt.']);
    exit;
}

$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    echo json_encode(['error' => 'Session abgelaufen.', 'redirect' => 'logout_admin.php?timeout=1']);
    exit;
}
$_SESSION['filemanager_last_action'] = time();

$baseDir = realpath(__DIR__ . '/..');
if ($baseDir === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Basisverzeichnis nicht erreichbar.']);
    exit;
}

$isAdmin = !empty($_SESSION['admin_access']);

function getMimeTypeSafe(string $path): string
{
    if (function_exists('mime_content_type')) {
        $mime = @mime_content_type($path);
        if ($mime !== false && $mime !== '') {
            return $mime;
        }
    }
    if (class_exists('finfo')) {
        $finfo = @finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo !== false) {
            $mime = @finfo_file($finfo, $path);
            finfo_close($finfo);
            if ($mime !== false && $mime !== '') {
                return $mime;
            }
        }
    }
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $map = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
        'bmp' => 'image/bmp',
        'svg' => 'image/svg+xml',
        'mp4' => 'video/mp4',
        'webm' => 'video/webm',
        'mov' => 'video/quicktime',
        'm4v' => 'video/x-m4v',
        'ogg' => 'video/ogg',
        'ogv' => 'video/ogg',
    ];
    return $map[$ext] ?? 'application/octet-stream';
}

function resolvePathSafe(string $inputPath, string $baseDir): ?string
{
    $realPath = realpath($inputPath);
    if (!$realPath) {
        return null;
    }

    $realBase = realpath($baseDir);
    if ($realBase && stripos($realPath, $realBase) === 0) {
        return $realPath;
    }

    return null;
}

function hasEditPermissionForPath(string $path, string $baseDir, bool $isAdmin): bool
{
    if ($isAdmin) {
        return true;
    }

    $relPath = $path;
    $realBase = realpath($baseDir) ?: $baseDir;
    if (stripos($relPath, $realBase) === 0) {
        $relPath = substr($relPath, strlen($realBase));
    }
    $relPath = str_replace('\\', '/', $relPath);
    $relPath = trim($relPath, '/');

    $canEdit = defined('USER_CAN_EDIT') ? USER_CAN_EDIT : true;
    $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];

    $bestMatch = '';
    foreach ($folderPerms as $p => $rules) {
        if ($relPath === $p || stripos($relPath, $p . '/') === 0) {
            if (strlen($p) >= strlen($bestMatch)) {
                $bestMatch = $p;
            }
        }
    }

    if ($bestMatch !== '' && isset($folderPerms[$bestMatch])) {
        $canEdit = isset($folderPerms[$bestMatch]['edit']) ? $folderPerms[$bestMatch]['edit'] : $canEdit;
    }

    return (bool) $canEdit;
}

function isSystemBlockedPath(string $path, string $baseDir): bool
{
    $realBase = realpath($baseDir) ?: $baseDir;
    $realPath = realpath($path);

    if ($realPath === false) {
        $realParent = realpath(dirname($path));
        if ($realParent === false) {
            return true;
        }
        $realPath = rtrim($realParent, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . basename($path);
    }

    if (stripos($realPath, $realBase) !== 0) {
        return true;
    }

    $relPath = trim(str_replace('\\', '/', substr($realPath, strlen($realBase))), '/');
    if ($relPath === '') {
        return false;
    }

    $firstSegment = explode('/', $relPath)[0] ?? '';
    $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env', 'web_login.php'];
    return in_array($firstSegment, $sensitive, true);
}

function isMediaFileByName(string $name): bool
{
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $imageExt = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'];
    $videoExt = ['mp4', 'webm', 'mov', 'm4v', 'ogg', 'ogv'];
    return in_array($ext, $imageExt, true) || in_array($ext, $videoExt, true);
}

function metaFilePath(string $baseDir): string
{
    return rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'media_metadata.json';
}

function metaKey(string $filePath, string $baseDir): string
{
    $realBase = realpath($baseDir) ?: $baseDir;
    $realPath = realpath($filePath) ?: $filePath;
    if (strpos($realPath, $realBase) === 0) {
        $realPath = substr($realPath, strlen($realBase));
    }
    return trim(str_replace('\\', '/', $realPath), '/');
}

function loadMetaStore(string $baseDir): array
{
    $file = metaFilePath($baseDir);
    if (!is_file($file)) {
        return [];
    }
    $raw = file_get_contents($file);
    $data = json_decode((string) $raw, true);
    return is_array($data) ? $data : [];
}

function saveMetaStore(string $baseDir, array $store): void
{
    $file = metaFilePath($baseDir);
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    file_put_contents($file, json_encode($store, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
}

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_REQUEST['action'] ?? '';
$path = (string) ($input['path'] ?? $_REQUEST['path'] ?? '');

if ($path === '') {
    echo json_encode(['error' => 'Kein Pfad angegeben.']);
    exit;
}

$targetPath = resolvePathSafe($path, $baseDir);
if (!$targetPath || !is_file($targetPath)) {
    echo json_encode(['error' => 'Datei nicht gefunden oder ungültiger Pfad.']);
    exit;
}

if (!isMediaFileByName(basename($targetPath))) {
    echo json_encode(['error' => 'Diese Datei ist kein unterstütztes Bild/Video.']);
    exit;
}

try {
    if ($action === 'get') {
        $store = loadMetaStore($baseDir);
        $key = metaKey($targetPath, $baseDir);
        $saved = (isset($store[$key]) && is_array($store[$key])) ? $store[$key] : [];
        $systemBlocked = isSystemBlockedPath($targetPath, $baseDir);
        $canEdit = !$systemBlocked && hasEditPermissionForPath($targetPath, $baseDir, $isAdmin);

        $mime = getMimeTypeSafe($targetPath);
        $meta = [
            'fileName' => basename($targetPath),
            'sizeFormatted' => formatSize((int) filesize($targetPath)),
            'mimeType' => $mime,
            'capturedAt' => $saved['capturedAt'] ?? '',
            'location' => $saved['location'] ?? '',
            'description' => $saved['description'] ?? '',
            'modifiedAt' => date('c', (int) filemtime($targetPath)),
            'systemBlocked' => $systemBlocked,
            'canEdit' => $canEdit
        ];

        if (function_exists('exif_read_data') && str_starts_with($mime, 'image/')) {
            $ext = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'tif', 'tiff'], true)) {
                $exif = @exif_read_data($targetPath, null, true, false);
                if (is_array($exif)) {
                    if ($meta['capturedAt'] === '' && !empty($exif['EXIF']['DateTimeOriginal'])) {
                        $meta['capturedAt'] = (string) $exif['EXIF']['DateTimeOriginal'];
                    }
                    if ($meta['location'] === '' && !empty($exif['GPS'])) {
                        $meta['location'] = 'EXIF-GPS vorhanden';
                    }
                }
            }
        }

        echo json_encode(['success' => true, 'metadata' => $meta]);
        exit;
    }

    if ($action === 'save') {
        if (isSystemBlockedPath($targetPath, $baseDir)) {
            echo json_encode(['error' => 'Dieser Eintrag ist durch das System gesperrt und kann nicht bearbeitet werden.']);
            exit;
        }
        if (!hasEditPermissionForPath($targetPath, $baseDir, $isAdmin)) {
            echo json_encode(['error' => 'Zugriff verweigert (Metadaten bearbeiten nicht erlaubt).']);
            exit;
        }

        $metaInput = is_array($input['metadata'] ?? null) ? $input['metadata'] : [];
        $capturedAt = trim((string) ($metaInput['capturedAt'] ?? ''));
        $location = trim((string) ($metaInput['location'] ?? ''));
        $description = trim((string) ($metaInput['description'] ?? ''));

        if ($capturedAt !== '') {
            $ts = strtotime($capturedAt);
            if ($ts !== false) {
                @touch($targetPath, $ts);
            }
        }

        $store = loadMetaStore($baseDir);
        $key = metaKey($targetPath, $baseDir);

        if ($capturedAt === '' && $location === '' && $description === '') {
            unset($store[$key]);
        } else {
            $store[$key] = [
                'capturedAt' => $capturedAt,
                'location' => $location,
                'description' => $description,
                'updatedAt' => date('c')
            ];
        }

        saveMetaStore($baseDir, $store);
        if ($auditDb = fm_open_db()) {
            fm_log_action($auditDb, 'media_metadata_save', $targetPath, 'Medien-Metadaten gespeichert');
            $auditDb->close();
        }
        echo json_encode(['success' => 'Medien-Metadaten gespeichert.']);
        exit;
    }

    echo json_encode(['error' => 'Unbekannte Aktion.']);
} catch (Throwable $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

function formatSize(int $bytes): string
{
    if ($bytes === 0) {
        return '0 B';
    }
    $k = 1024;
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = (int) floor(log($bytes) / log($k));
    return sprintf('%.2f', $bytes / pow($k, $i)) . ' ' . $sizes[$i];
}
