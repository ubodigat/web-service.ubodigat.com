<?php
declare(strict_types=1);

function fm_add_column_if_missing(mysqli $db, string $table, string $column, string $definition): void
{
    $stmt = $db->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    if (!$stmt) {
        return;
    }

    $stmt->bind_param('s', $column);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result && $result->num_rows === 0) {
        @$db->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

function fm_ensure_schema(mysqli $db): void
{
    @$db->set_charset('utf8mb4');

    $tableCheck = @$db->query("SHOW TABLES LIKE 'benutzer'");
    if ($tableCheck && $tableCheck->num_rows > 0) {
        fm_add_column_if_missing($db, 'benutzer', 'auth_secret', 'VARCHAR(255) NULL DEFAULT NULL');
        fm_add_column_if_missing($db, 'benutzer', 'is_admin', 'TINYINT(1) NOT NULL DEFAULT 1');
    }

    @$db->query("
        CREATE TABLE IF NOT EXISTS filemanager_audit_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            actor VARCHAR(120) NOT NULL,
            role VARCHAR(20) NOT NULL DEFAULT '',
            action VARCHAR(120) NOT NULL,
            target_path TEXT NULL,
            details TEXT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'success',
            ip_address VARCHAR(64) NULL,
            PRIMARY KEY (id),
            KEY idx_created_at (created_at),
            KEY idx_actor (actor),
            KEY idx_action (action)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
}

function fm_open_db(): ?mysqli
{
    global $db_host, $db_user, $db_pass, $db_name;

    if (!isset($db_host, $db_user, $db_pass, $db_name)) {
        return null;
    }

    try {
        $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
        $db->set_charset('utf8mb4');
        fm_ensure_schema($db);
        return $db;
    } catch (Throwable $e) {
        return null;
    }
}

function fm_current_actor_label(): string
{
    if (!empty($_SESSION['admin_access'])) {
        return (string) ($_SESSION['admin_user'] ?? 'Administrator');
    }

    if (!empty($_SESSION['filemanager_user'])) {
        return (string) $_SESSION['filemanager_user'];
    }

    return 'unbekannt';
}

function fm_current_actor_role(): string
{
    if (!empty($_SESSION['admin_access'])) {
        return 'admin';
    }

    if (!empty($_SESSION['filemanager_user'])) {
        return 'user';
    }

    return 'guest';
}

function fm_log_action(mysqli $db, string $action, string $targetPath = '', string $details = '', string $status = 'success'): void
{
    try {
        fm_ensure_schema($db);
        $actor = fm_current_actor_label();
        $role = fm_current_actor_role();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        $stmt = $db->prepare(
            "INSERT INTO filemanager_audit_log (actor, role, action, target_path, details, status, ip_address)
             VALUES (?, ?, ?, ?, ?, ?, ?)"
        );

        if (!$stmt) {
            return;
        }

        $pathValue = $targetPath !== '' ? $targetPath : null;
        $detailsValue = $details !== '' ? $details : null;
        $stmt->bind_param('sssssss', $actor, $role, $action, $pathValue, $detailsValue, $status, $ip);
        $stmt->execute();
        $stmt->close();
    } catch (Throwable $e) {
        // Logging darf die Hauptfunktion nicht stören.
    }
}

function fm_fetch_audit_log(mysqli $db, int $limit = 100): array
{
    fm_ensure_schema($db);

    $limit = max(1, min(500, $limit));
    $stmt = $db->prepare(
        "SELECT id, created_at, actor, role, action, target_path, details, status, ip_address
         FROM filemanager_audit_log
         ORDER BY id DESC
         LIMIT ?"
    );

    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('i', $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $rows = [];

    while ($result && ($row = $result->fetch_assoc())) {
        $rows[] = $row;
    }

    $stmt->close();
    return $rows;
}
