<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $targetDir = $_POST['path'] ?? '';
    if (!is_dir($targetDir)) {
        http_response_code(400);
        echo "❌ Ungültiges Verzeichnis!";
        exit;
    }

    if (!isset($_FILES['uploadFile']) || $_FILES['uploadFile']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo "❌ Datei konnte nicht empfangen werden.";
        exit;
    }

    $file = $_FILES['uploadFile'];
    $targetPath = rtrim($targetDir, '/') . '/' . basename($file['name']);

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        echo "✅ Datei erfolgreich hochgeladen!";
    } else {
        http_response_code(500);
        echo "❌ Fehler beim Speichern der Datei!";
    }
}
?>