<?php
session_start();

$standard_path = "/var/www/html/webseite/aeup-projekt";
$isAdmin = isset($_SESSION["admin_access"]) && $_SESSION["admin_access"] === true;

$filename = $_GET['file'] ?? '';
$path = $_GET['path'] ?? $standard_path;

if (!$isAdmin && strpos(realpath($path), realpath($standard_path)) !== 0) {
    die("❌ Zugriff verweigert.");
}

$fullPath = realpath($path . DIRECTORY_SEPARATOR . $filename);
if (!$fullPath || !file_exists($fullPath)) {
    die("❌ Datei/Ordner nicht gefunden.");
}

if (is_dir($fullPath)) {
    $zipFile = sys_get_temp_dir() . '/' . basename($fullPath) . '.zip';
    $zip = new ZipArchive();
    if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($fullPath) + 1);
            $zip->addFile($filePath, $relativePath);
        }
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFile) . '"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    } else {
        die("❌ ZIP konnte nicht erstellt werden.");
    }
}

if (!is_file($fullPath)) {
    die("❌ Keine reguläre Datei.");
}

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($fullPath) . '"');
header('Content-Length: ' . filesize($fullPath));
readfile($fullPath);
exit;
?>