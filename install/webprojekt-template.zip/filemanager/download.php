﻿<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration & Sicherheit laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    header('Location: ../install/setup.php');
    exit;
}

require_once $configFile;
require_once __DIR__ . '/fm_common.php';

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    exit('âŒ Zugriff verweigert.');
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    exit('âŒ Sitzung abgelaufen.');
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad & Admin-Status
$baseDir = realpath(__DIR__ . '/..');

if ($baseDir === false) {
    http_response_code(500);
    exit('âŒ Basisverzeichnis nicht erreichbar.');
}

$isAdmin = !empty($_SESSION['admin_access']);

// ---------------------------------------------------------
// Parameter Validierung (Hier war der Fehler!)
// ---------------------------------------------------------

// Wir erwarten nur 'path', der den vollen Pfad zur Datei/Ordner enthÃ¤lt
$requestPath = $_GET['path'] ?? '';
$inlineView = isset($_GET['inline']) && $_GET['inline'] === '1';

if ($requestPath === '') {
    http_response_code(400);
    exit('âŒ Kein Pfad angegeben.');
}

// ---------------------------------------------------------
// Pfad-Sicherheit (Sandbox)
// ---------------------------------------------------------

$fullPath = realpath($requestPath);

// Existenz-Check
if ($fullPath === false || !file_exists($fullPath)) {
    http_response_code(404);
    exit('âŒ Datei oder Ordner nicht gefunden.');
}

// Sandbox-Check: Ausbruch verhindern (nur fÃ¼r Nicht-Admins)
if (!$isAdmin) {
    if (strpos($fullPath, $baseDir) !== 0) {
        http_response_code(403);
        exit('âŒ Zugriff auÃŸerhalb des Projektordners verboten.');
    }
}

// ---------------------------------------------------------
// Fall A: Es ist ein ORDNER -> Als ZIP herunterladen
// ---------------------------------------------------------
if (is_dir($fullPath)) {

    // Temp-Datei fÃ¼r das ZIP
    $zipFilename = basename($fullPath) . '.zip';
    $tempZipPath = sys_get_temp_dir() . '/' . uniqid('zip_') . '.zip';

    $zip = new ZipArchive();
    if ($zip->open($tempZipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        http_response_code(500);
        exit('âŒ ZIP konnte nicht erstellt werden.');
    }

    // Rekursiv alle Dateien hinzufÃ¼gen
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS)
    );

    $maxFiles = 5000; // DoS Schutz
    $count = 0;

    foreach ($iterator as $file) {
        if (++$count > $maxFiles) {
            $zip->close();
            unlink($tempZipPath);
            http_response_code(413); // Payload Too Large
            exit('âŒ ZIP enthÃ¤lt zu viele Dateien (Limit 5000).');
        }

        // Pfad innerhalb des Zips relativ machen
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($fullPath) + 1);

        if (!$file->isDir()) {
            $zip->addFile($filePath, $relativePath);
        } else {
            $zip->addEmptyDir($relativePath);
        }
    }

    $zip->close();

    // Download starten
    if (file_exists($tempZipPath)) {
        header('Content-Type: application/zip');
        if ($auditDb = fm_open_db()) {
            fm_log_action($auditDb, 'download_zip', $fullPath, 'Ordner als ZIP heruntergeladen');
            $auditDb->close();
        }
        header('Content-Disposition: attachment; filename="' . $zipFilename . '"');
        header('Content-Length: ' . filesize($tempZipPath));
        header('Pragma: no-cache');
        readfile($tempZipPath);

        // Aufräumen
        unlink($tempZipPath);
        exit;
    } else {
        http_response_code(500);
        exit('❌ Fehler beim Erstellen der ZIP-Datei.');
    }
}

// ---------------------------------------------------------
// Fall B: Es ist eine DATEI -> Direkt herunterladen
// ---------------------------------------------------------
if (is_file($fullPath)) {

    $mimeType = 'application/octet-stream';
    if (function_exists('mime_content_type')) {
        $mimeType = @mime_content_type($fullPath) ?: 'application/octet-stream';
    }
    $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
    $mimeByExt = [
        'mp4' => 'video/mp4',
        'webm' => 'video/webm',
        'mov' => 'video/quicktime',
        'm4v' => 'video/x-m4v',
        'ogv' => 'video/ogg',
        'ogg' => 'video/ogg',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
        'bmp' => 'image/bmp',
        'svg' => 'image/svg+xml'
    ];
    if (isset($mimeByExt[$ext])) {
        $mimeType = $mimeByExt[$ext];
    }

    if ($auditDb = fm_open_db()) {
        fm_log_action($auditDb, 'download', $fullPath, $inlineView ? 'Datei inline ge?ffnet' : 'Datei heruntergeladen');
        $auditDb->close();
    }
    header('Content-Type: ' . $mimeType);
    header('Content-Description: File Transfer');
    $disposition = $inlineView ? 'inline' : 'attachment';
    header('Content-Disposition: ' . $disposition . '; filename="' . basename($fullPath) . '"');
    header('Accept-Ranges: bytes');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($fullPath));
    header('X-Content-Type-Options: nosniff'); // Security Header

    // Puffer leeren, um korrupte Downloads zu verhindern
    if (ob_get_level())
        ob_end_clean();
    flush();

    readfile($fullPath);
    exit;
}

// Falls weder Datei noch Ordner (z.B. Symlink ins Nichts)
http_response_code(400);
exit('âŒ UngÃ¼ltiger Dateityp.');
