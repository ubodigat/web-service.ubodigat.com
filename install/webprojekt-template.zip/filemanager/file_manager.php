<?php
session_start();

$timeout = 20 * 60;
$standard_path = "/var/www/html/webseite/aeup-projekt";
$session_key = "filemanager_login";

if (!isset($_SESSION[$session_key]) || $_SESSION[$session_key] !== true) {
    $url = urlencode($_SERVER["REQUEST_URI"]);
    header("Location: /login_filemanager.php?redirect=$url");
    exit;
}

if (isset($_SESSION["filemanager_last_action"]) && (time() - $_SESSION["filemanager_last_action"]) > $timeout) {
    session_unset();
    session_destroy();
    setcookie(session_name(), '', time() - 3600, '/');
    header("Location: /login_filemanager.php?timeout=1");
    exit;
}
$_SESSION["filemanager_last_action"] = time();

$isAdmin = isset($_SESSION["admin_access"]) && $_SESSION["admin_access"] === true;

$rootDir = $standard_path;
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Web-Dateimanager</title>
    <link rel="stylesheet" href="style.css?v=205" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
    <script>
        require.config({
            paths: {
                vs: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.1/min/vs"
            }
        });
    </script>
</head>
<body>
    <div class="container">

        <div class="top-controls">
            <h2>📂 Web-Dateimanager</h2>
            <div class="right-buttons">
                <?php if ($isAdmin): ?>
                    <form method="post" action="logout_admin.php" style="margin: 0;">
                        <button type="submit" class="btn btn-danger">🚪 Admin-Logout</button>
                    </form>
                <?php endif; ?>
                <button class="btn btn-info" onclick="window.location.href='admin_login.php'">🔐 Admin-Login</button>
                <button class="dark-mode-toggle" onclick="toggleDarkMode()">🌙 Dark Mode</button>
            </div>
        </div>

        <div class="upload-box">
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="upload-row">
                    <label class="custom-upload">
                        📤 Datei auswählen
                        <input type="file" id="uploadFile" name="uploadFile" onchange="showFileName()" hidden>
                    </label>
                    <span id="selectedFileName" class="file-name">Keine Datei ausgewählt</span>
                    <button type="submit" class="btn btn-warning" id="uploadBtn">⬆️ Hochladen</button>
                </div>
            </form>
        </div>

        <div class="input-group">
            <input
                type="text"
                id="directoryPath"
                value="<?= htmlspecialchars($rootDir) ?>"
            >
            <button id="aktualisieren" class="btn btn-success" onclick="loadFiles()">🔄 Aktualisieren</button>
        </div>

        <script>
            const inputPath = document.getElementById("directoryPath");
            const isAdmin = <?= $isAdmin ? "true" : "false" ?>;
            const basePath = "<?= addslashes($rootDir) ?>";

            if (!isAdmin) {
                inputPath.addEventListener("input", () => {
                    if (!inputPath.value.startsWith(basePath)) {
                        inputPath.value = basePath;
                    }
                });

                // Cursorposition überwachen
                inputPath.addEventListener("keydown", function (e) {
                    const start = inputPath.selectionStart;
                    const baseLength = basePath.length;

                    // Wenn versucht wird, den Cursor vor den Standardpfad zu setzen
                    if (start < baseLength) {
                        const allowed = ["ArrowRight", "ArrowDown", "End", "Tab"];
                        if (!allowed.includes(e.key)) {
                            e.preventDefault();
                            // Cursor ans Ende setzen
                            inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                        }
                    }
                });

                // Cursorposition am Ende setzen beim Klick
                inputPath.addEventListener("click", function () {
                    const baseLength = basePath.length;
                    if (inputPath.selectionStart < baseLength) {
                        inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                    }
                });
            }
        </script>

        <div class="input-group">
            <input type="text" id="newFileName" class="input-half" placeholder="Dateiname">
            <button id="buttonbreite" class="btn btn-primary" onclick="createFile()">➕ Datei erstellen</button>

            <input type="text" id="newFolderName" class="input-half" placeholder="Ordnername">
            <button id="buttonbreite" class="btn btn-secondary" onclick="createFolder()">📁 Ordner erstellen</button>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Typ</th>
                    <th>Letzte Änderung</th>
                    <th>Aktionen</th>
                </tr>
            </thead>
            <tbody id="fileTable"></tbody>
        </table>
    </div>

    <div id="editModal" class="edit-modal">
        <h3 id="editTitle">Datei bearbeiten</h3>
        <div id="editor-container">
            <div id="editor"></div>
        </div>
        <div class="modal-buttons">
            <button class="btn btn-danger" onclick="closeEditModal()">❌ Schließen</button>
            <button class="btn btn-success" onclick="saveFile()">💾 Speichern</button>
        </div>
    </div>

    <script src="script.js?v=205"></script>
    <script>
        function showFileName() {
            const input = document.getElementById('uploadFile');
            const label = document.getElementById('selectedFileName');
            label.textContent = input.files.length > 0 ? input.files[0].name : "Keine Datei ausgewählt";
        }

        <?php if (!$isAdmin): ?>
        document.addEventListener("DOMContentLoaded", () => {
            const input = document.getElementById("directoryPath");
            const original = input.value;
            input.addEventListener("input", () => {
                if (!input.value.startsWith(original)) {
                    input.value = original;
                }
            });
        });
        <?php endif; ?>
        let timeout = 20 * 60 * 1000; // 20 Minuten
        let timer = setTimeout(() => {
        window.location.href = "/logout_filemanager.php?timeout=1";
        }, timeout);

        document.addEventListener("mousemove", resetTimer);
        document.addEventListener("keydown", resetTimer);

        function resetTimer() {
        clearTimeout(timer);
        timer = setTimeout(() => {
            window.location.href = "/logout_filemanager.php?timeout=1";
        }, timeout);
        }

        function downloadFile() {
        const path = document.getElementById("directoryPath").value.trim();
        if (!path) {
            alert("❗ Bitte wähle erst eine Datei oder einen Ordner aus.");
            return;
        }
        const fileName = path.split("/").pop();
        const link = document.createElement('a');
        link.href = 'download.php?path=' + encodeURIComponent(path);
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        }
    </script>
</body>
</html>
