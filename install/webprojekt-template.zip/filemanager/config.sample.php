<?php
$standard_path = "/var/www/html";
$admin_user = "ADMIN_USER_PLACEHOLDER";
$admin_pass_hash = "ADMIN_PASS_HASH_PLACEHOLDER";
?>