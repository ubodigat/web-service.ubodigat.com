let editor = null;
let darkMode = localStorage.getItem("darkMode") === "true";

// 🌙 Dark Mode umschalten
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode);
    applyEditorTheme();
}

// 🎨 Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    document.getElementById("editor-container").style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// 📂 Datei-Icons
function getFileIcon(name, type) {
    if (type === "Ordner") return "📂";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "🌐", htm: "🌐", php: "🐘", js: "📜", css: "🎨", txt: "📝", json: "🔢", pdf: "📑",
        ico: "📎", zip: "📦", rar: "📦", png: "🖼️", jpg: "🖼️", jpeg: "🖼️", mp4: "🎞️", mov: "🎞️"
    };
    return icons[ext] || "📄";
}

// 🔄 Dateien laden
function loadFiles() {
    const dir = document.getElementById("directoryPath").value.trim();
    if (!dir) return alert("Verzeichnis ist leer!");

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        const table = $("#fileTable").empty();
        data.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            table.append(`
                <tr>
                    <td>${icon} ${file.name}</td>
                    <td>${file.type}</td>
                    <td>${file.modified}</td>
                    <td>
                        <button class="btn btn-warning btn-small" onclick="editFile('${file.name}')">✏️ Bearbeiten</button>
                        <button class="btn btn-info btn-small" onclick="renameFile('${file.name}')">📄 Umbenennen</button>
                        <button class="btn btn-danger btn-small" onclick="deleteFile('${file.name}')">🗑️ Löschen</button>
                        <a href="download.php?file=${encodeURIComponent(file.name)}&path=${encodeURIComponent(dir)}" class="btn btn-success btn-icon-only" title="Download">⬇️</a>
                    </td>
                </tr>
            `);
        });
    }).fail(jqXHR => alert("Fehler beim Laden: " + jqXHR.responseText));
}

// ✏️ Datei bearbeiten
function editFile(name) {
    const dir = document.getElementById("directoryPath").value;

    $.getJSON(`api.php?action=open&dir=${encodeURIComponent(dir)}&file=${encodeURIComponent(name)}`, data => {
        if (!editor) return alert("Editor nicht geladen!");

        if (data.content !== undefined) {
            editor.setValue(data.content);
            const ext = name.split('.').pop().toLowerCase();
            const langMap = { php: "php", js: "javascript", css: "css", html: "html", txt: "plaintext" };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");

            $("#editModal").data("filename", name);
            openEditModal();
            setTimeout(() => editor.layout(), 300);
        }
    });
}

// 💾 Datei speichern
function saveFile() {
    const dir = document.getElementById("directoryPath").value;
    const name = $("#editModal").data("filename");
    if (!name) return alert("Kein Dateiname!");

    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            dir,
            file: name,
            content: editor.getValue()
        }),
        success: response => {
            alert(response.success || response.error);
            if (response.success) {
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => alert("Fehler beim Speichern: " + jqXHR.responseText)
    });
}

// 📁 Modal ein-/ausblenden
function openEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("hidden");
    modal.classList.add("show");
}
function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.classList.remove("show");
    setTimeout(() => modal.classList.add("hidden"), 300);
}

// 🗑️ Datei löschen
function deleteFile(name) {
    if (!confirm(`${name} wirklich löschen?`)) return;
    const dir = document.getElementById("directoryPath").value;

    $.post("api.php", JSON.stringify({ action: "delete", dir, file: name }), response => {
        alert(response.success || response.error);
        loadFiles();
    }, "json");
}

// 📄 Umbenennen
function renameFile(name) {
    const newName = prompt(`Neuer Name für ${name}:`);
    if (!newName) return;
    const dir = document.getElementById("directoryPath").value;

    $.post("api.php", JSON.stringify({
        action: "rename",
        dir,
        oldName: name,
        newName
    }), response => {
        alert(response.success || response.error);
        loadFiles();
    }, "json");
}

// ➕ Datei / Ordner erstellen
function createFile(isFolder = false) {
    const dir = document.getElementById("directoryPath").value;
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return alert("Name darf nicht leer sein!");

    $.post("api.php", JSON.stringify({
        action: "create",
        dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        alert(response.success || response.error);
        loadFiles();
        document.getElementById(inputId).value = "";
    }, "json");
}

// ⬆️ Datei hochladen
function uploadFile(event) {
    event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;
    const formData = new FormData();

    if (!fileInput.files.length) return alert("Bitte wähle eine Datei aus.");

    formData.append('uploadFile', fileInput.files[0]);
    formData.append('path', path);

    fetch('upload.php', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(response => {
            alert(response);
            loadFiles();
            fileInput.value = "";
            document.getElementById('selectedFileName').textContent = "Keine Datei ausgewählt";
        })
        .catch(error => {
            console.error("Upload-Fehler:", error);
            alert("Fehler beim Hochladen.");
        });
}

// 🧠 Monaco laden
require(["vs/editor/editor.main"], function () {
    editor = monaco.editor.create(document.getElementById("editor"), {
        value: "// Warten auf Datei...",
        language: "plaintext",
        theme: darkMode ? "vs-dark" : "vs-light",
        fontSize: 14,
    });
    applyEditorTheme();
    setTimeout(() => editor.layout(), 300);
    console.log("✅ Monaco Editor geladen");
});

// 📦 Init
$(document).ready(() => {
    document.getElementById("editModal").classList.add("hidden"); // Modal ausblenden bei Start
    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");
    applyEditorTheme();

    $("#uploadForm").on("submit", uploadFile);
    document.getElementById("directoryPath").addEventListener("keydown", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            loadFiles();
        }
    });
});

// 🌐 Global exportieren
window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = () => createFile(true);
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;
