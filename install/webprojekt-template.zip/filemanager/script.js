﻿let editor = null;
let darkModeVal = localStorage.getItem("darkMode");
let darkMode = darkModeVal === null ? true : (darkModeVal === "true");
let currentDirectorySystemBlocked = false;
let currentTableSort = { key: 'name', dir: 'asc' };

// ðŸŒ™ Dark Mode
function toggleDarkMode() {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
    localStorage.setItem("darkMode", darkMode ? "true" : "false");
    applyEditorTheme();
}
// Initialer Check â€“ nur wenn body bereits existiert (script am Ende des body)
if (document.body) {
    if (darkMode) {
        document.body.classList.add("dark-mode");
    } else {
        document.body.classList.remove("dark-mode");
    }
}

// ðŸŽ¨ Editor-Theme
function applyEditorTheme() {
    if (!editor) return;
    monaco.editor.setTheme(darkMode ? "vs-dark" : "vs-light");
    const ec = document.getElementById("editor-container");
    if (ec) ec.style.backgroundColor = darkMode ? "#1e1e1e" : "#ffffff";
}

// ðŸ“‚ Datei-Icons
function getFileIcon(name, type) {
    if (type === "folder" || type === "Ordner") return "ðŸ“‚";
    const ext = name.split('.').pop().toLowerCase();
    const icons = {
        html: "ðŸŒ",
        htm: "ðŸŒ",
        php: "ðŸ˜",
        js: "ðŸ“œ",
        css: "ðŸŽ¨",
        txt: "ðŸ“",
        json: "ðŸ”¢",
        pdf: "ðŸ“‘",
        ico: "ðŸ“Ž",
        zip: "ðŸ“¦",
        rar: "ðŸ“¦",
        png: "ðŸ–¼ï¸",
        jpg: "ðŸ–¼ï¸",
        jpeg: "ðŸ–¼ï¸",
        mp4: "ðŸŽžï¸",
        mov: "ðŸŽžï¸"
    };
    return icons[ext] || "ðŸ“„";
}

// ðŸ”’ HTML escapen (XSS-Schutz)
function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'm4v', 'ogg', 'ogv'];

function getExtension(name) {
    const parts = String(name || '').toLowerCase().split('.');
    return parts.length > 1 ? parts.pop() : '';
}

function isImageFile(name) {
    return IMAGE_EXTENSIONS.includes(getExtension(name));
}

function isVideoFile(name) {
    return VIDEO_EXTENSIONS.includes(getExtension(name));
}

function isMediaFile(name) {
    return isImageFile(name) || isVideoFile(name);
}

function parseDateForSort(value) {
    if (!value) return 0;
    if (typeof value === 'number') return value;
    const ts = Date.parse(value);
    if (!Number.isNaN(ts)) return ts;
    const match = String(value).match(/(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}):(\d{2})/);
    if (!match) return 0;
    return new Date(`${match[3]}-${match[2]}-${match[1]}T${match[4]}:${match[5]}:00`).getTime() || 0;
}

function compareFilesForSort(a, b, key) {
    const aIsFolder = a.type === 'folder' || a.type === 'Ordner';
    const bIsFolder = b.type === 'folder' || b.type === 'Ordner';

    if (key !== 'status' && aIsFolder !== bIsFolder) {
        return aIsFolder ? -1 : 1;
    }

    const nameA = String(a.name || '').toLowerCase();
    const nameB = String(b.name || '').toLowerCase();

    switch (key) {
        case 'name':
            return nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'status':
            return String(a.isSystemBlocked ? '1' : '0').localeCompare(String(b.isSystemBlocked ? '1' : '0')) || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'type':
            return String(a.type || '').localeCompare(String(b.type || ''), 'de', { sensitivity: 'base' }) || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        case 'size': {
            const sizeA = Number(a.sizeBytes || 0);
            const sizeB = Number(b.sizeBytes || 0);
            return sizeA - sizeB || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        }
        case 'date': {
            const timeA = parseDateForSort(a.modifiedTimestamp || a.date);
            const timeB = parseDateForSort(b.modifiedTimestamp || b.date);
            return timeA - timeB || nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
        }
        default:
            return nameA.localeCompare(nameB, 'de', { sensitivity: 'base' });
    }
}

function sortFilesList(files) {
    const sorted = [...files];
    sorted.sort((a, b) => {
        const result = compareFilesForSort(a, b, currentTableSort.key);
        return currentTableSort.dir === 'asc' ? result : -result;
    });
    return sorted;
}

function updateSortIndicators() {
    const headers = document.querySelectorAll('th[data-sort-key]');
    headers.forEach(th => {
        const key = th.getAttribute('data-sort-key');
        const isActive = key === currentTableSort.key;
        th.dataset.sortDir = isActive ? currentTableSort.dir : '';
        th.style.opacity = isActive ? '1' : '0.8';
        th.title = isActive
            ? `Sortierung: ${currentTableSort.dir === 'asc' ? 'aufsteigend' : 'absteigend'}`
            : 'Zum Sortieren klicken';
    });
}

function setTableSort(key) {
    if (!key) return;
    if (currentTableSort.key === key) {
        currentTableSort.dir = currentTableSort.dir === 'asc' ? 'desc' : 'asc';
    } else {
        currentTableSort.key = key;
        currentTableSort.dir = key === 'size' || key === 'date' ? 'desc' : 'asc';
    }
    updateSortIndicators();
    loadFiles();
}
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('th[data-sort-key]').forEach(th => {
        th.addEventListener('click', () => setTableSort(th.getAttribute('data-sort-key')));
    });
    updateSortIndicators();
});
// ðŸ–¼ï¸ Custom Modal
function customModal({
    title,
    message,
    type = 'alert',
    confirmText = 'OK',
    cancelText = 'Abbrechen',
    inputPlaceholder = '',
    defaultValue = ''
}) {
    return new Promise(resolve => {
        const overlay = $('<div class="modal-overlay modal-front"></div>');
        const card = $('<div class="modal-card"></div>');
        const header = $(`<div class="modal-header">${title}</div>`);
        const closeBtn = $('<button class="modal-close" title="Schlie&szlig;en">x</button>');
        header.append(closeBtn);
        closeBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        const body = $(`<div class="modal-body">${message}</div>`);
        const footer = $('<div class="modal-footer"></div>');

        let input = null;
        if (type === 'prompt') {
            input = $(`<input type="text" class="modal-input" placeholder="${inputPlaceholder}" value="${defaultValue}">`);
            body.append(input);
        }

        const confirmBtn = $(`<button class="btn btn-primary">${confirmText}</button>`);
        const cancelBtn = $(`<button class="btn btn-secondary">${cancelText}</button>`);


        confirmBtn.on('click', () => {
            let result = true;
            if (type === 'prompt') result = input.val();
            overlay.remove();
            resolve(result);
        });
        cancelBtn.on('click', () => {
            overlay.remove();
            resolve(null);
        });

        footer.append(cancelBtn).append(confirmBtn);
        if (type === 'alert') cancelBtn.remove();

        card.append(header).append(body).append(footer);
        overlay.append(card);
        $('body').append(overlay);
        if (input) input.focus();
    });
}

function showSystemBlockedNotice(itemName = '') {
    const safeName = escHtml(itemName || 'Dieser Eintrag');
    return customModal({
        title: 'ðŸ”’ Gesperrt',
        message: `${safeName} ist durch das System gesperrt und kann nicht bearbeitet werden.`
    });
}

function updateMutationControlsLockState() {
    const lock = !!currentDirectorySystemBlocked;
    const message = lock ? 'Dieser Ordner ist systemgesperrt. Aktualisieren bleibt verfuegbar.' : '';

    const uploadInput = document.getElementById('uploadFile');
    const uploadBtn = document.getElementById('uploadBtn');
    const createFileBtn = document.getElementById('createFileBtn');
    const createFolderBtn = document.getElementById('createFolderBtn');
    const newFileName = document.getElementById('newFileName');
    const newFolderName = document.getElementById('newFolderName');

    if (uploadInput) {
        uploadInput.disabled = lock;
        uploadInput.title = message;
    }
    if (uploadBtn) {
        uploadBtn.disabled = lock;
        uploadBtn.title = message;
    }
    if (createFileBtn) {
        createFileBtn.disabled = lock;
        createFileBtn.title = message;
    }
    if (createFolderBtn) {
        createFolderBtn.disabled = lock;
        createFolderBtn.title = message;
    }
    if (newFileName) {
        newFileName.disabled = lock;
        newFileName.title = message;
    }
    if (newFolderName) {
        newFolderName.disabled = lock;
        newFolderName.title = message;
    }
}

// ðŸ”„ Dateien laden
function loadFiles() {
    const dirInput = document.getElementById("directoryPath");
    if (!dirInput) return;
    const dir = dirInput.value.trim();
    if (!dir) return;

    $.getJSON(`api.php?action=list&dir=${encodeURIComponent(dir)}`, data => {
        if (data.error) {
            customModal({
                title: 'âŒ Fehler',
                message: escHtml(data.error)
            });
            return;
        }

        currentDirectorySystemBlocked = !!data.currentPathBlocked;
        updateMutationControlsLockState();
        updateSortIndicators();

        const table = $("#fileTable").empty();
        const files = sortFilesList(data.files || []);
        const separator = dir.includes("\\") ? "\\" : "/";

        if (files.length === 0) {
            table.append(`
                <tr>
                    <td colspan="6" style="text-align:center; padding:60px 20px; color:var(--text-muted);">
                        <div style="font-size:48px; margin-bottom:16px;">ðŸ“‚</div>
                        <h3 style="margin:0 0 8px; color:var(--text);">Dieser Ordner ist leer</h3>
                        <p style="margin:0 0 24px; font-size:14px;">Lade eine Datei hoch oder erstelle einen neuen Ordner.</p>
                    </td>
                </tr>
            `);
            return;
        }

        files.forEach(file => {
            const icon = getFileIcon(file.name, file.type);
            const fullPath = (dir === '.' ? '' : dir).replace(/[/\\]$/, "") + (dir === '.' ? '' : separator) + file.name;
            const isFolder = file.type === "folder" || file.type === "Ordner";
            const isZip = !isFolder && file.name.toLowerCase().endsWith('.zip');
            const isPrivate = !!file.isPrivate;
            const nameEsc = escHtml(file.name);
            const typeEsc = escHtml(file.type);
            const dateEsc = escHtml(file.date);
            // Schloss-Icon fÃ¼r private Elemente (nur Admin sieht es, da normale User private Elemente gar nicht sehen)
            const privBadge = (window.isSystemAdmin && isPrivate) ? ' <span title="Privat â€“ nur Admins" style="font-size:12px; opacity:0.7;">ðŸ”’</span>' : '';

            let badgeText = isPrivate ? 'ðŸ”’ Verborgen' : 'ðŸŒ Sichtbar';
            let badgeClass = isPrivate ? 'vis-private' : 'vis-public';
            if (file.isSystemBlocked) {
                badgeText = 'ðŸš« Gesperrt';
                badgeClass = 'vis-system';
            }

            const sizeEsc = escHtml(file.sizeFormatted || '-');

            const row = $(`
                <tr data-type="${typeEsc}" data-name="${nameEsc}" data-path="${escHtml(fullPath)}">
                    <td style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:0;" title="${nameEsc}">${icon} ${nameEsc}</td>
                    <td>
                        <span class="vis-badge ${badgeClass}">
                            ${badgeText}
                        </span>
                    </td>
                    <td>${typeEsc}</td>
                    <td>${sizeEsc}</td>
                    <td>${dateEsc}</td>
                    <td>
                        <div class="action-btn-group">
                            <button class="btn btn-primary  btn-small js-open-folder" title="Ã–ffnen"     style="display:${isFolder?'':'none'}">ðŸ“‚ Ã–ffnen</button>
                            <button class="btn btn-warning  btn-small js-edit-file"   title="Bearbeiten" style="display:${isFolder?'none':''}">âœï¸ Edit</button>
                            <button class="btn btn-warning  btn-small js-rename"      title="Umbenennen">ðŸ“„</button>
                            <button class="btn btn-danger   btn-small js-delete"      title="LÃ¶schen">ðŸ—‘ï¸</button>
                            <a href="download.php?path=${encodeURIComponent(fullPath)}" class="btn btn-success btn-small" title="Herunterladen">â¬‡ï¸</a>
                            ${isFolder ? `<button class="btn btn-info btn-small js-zip-folder" title="Als ZIP packen">ðŸ“¦</button>` : ''}
                            ${isZip ? `<button class="btn btn-info btn-small js-unzip-file" title="ZIP entpacken">ðŸ“¦</button>` : ''}
                            ${window.isSystemAdmin ? `<button class="btn btn-secondary btn-small js-visibility" title="${isPrivate?'Privat â€“ klicken um Ã¶ffentlich zu setzen':'Ã–ffentlich â€“ klicken um privat zu setzen'}" style="opacity:${isPrivate?'1':'0.5'}; visibility:${file.isSystemBlocked ? 'hidden' : 'visible'};">${isPrivate?'ðŸ”’':'ðŸŒ'}</button>` : ''}
                        </div>
                    </td>
                </tr>`);

            if (file.isSystemBlocked) {
                row.find('.js-edit-file, .js-rename, .js-delete')
                    .attr('title', 'Durch System gesperrt')
                    .css({ opacity: '0.45', cursor: 'not-allowed' });
            }

            row.find('.js-open-folder').on('click', () => openFolderByPath(encodeURIComponent(file.name)));
            row.find('.js-edit-file').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                handleEditAction(file, fullPath);
            });
            row.find('.js-rename').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                renameFile(file.name);
            });
            row.find('.js-delete').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                deleteFile(file.name);
            });
            row.find('.js-visibility').on('click', () => showVisibility(fullPath, isFolder, isPrivate));
            row.find('.js-zip-folder').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                zipFolder(fullPath);
            });
            row.find('.js-unzip-file').on('click', () => {
                if (file.isSystemBlocked) return showSystemBlockedNotice(file.name);
                unzipFile(fullPath);
            });

            table.append(row);
        });
    }).fail(jqXHR => customModal({
        title: 'âŒ Fehler',
        message: "Ladefehler: " + escHtml(jqXHR.responseText)
    }));
}

// ðŸ‘ï¸ Sichtbarkeit verwalten
async function showVisibility(path, isFolder, currentlyPrivate) {
    if (!window.isSystemAdmin) return customModal({
        title: 'ðŸ” Zugriff verweigert',
        message: 'Admin-Rechte erforderlich!'
    });

    const itemName = path.split('/').pop() || path.split('\\').pop() || path;

    if (currentlyPrivate) {
        // Aktuell PRIVAT â†’ auf Ã–ffentlich setzen
        let cascade = false;
        if (isFolder) {
            // Ordner: Abfrage mit Cascade-Option
            const overlay = $('<div class="modal-overlay modal-front"></div>');
            const card = $(`
                <div class="modal-card" style="max-width:420px;">
                    <div class="modal-header">ðŸŒ Ordner Ã¶ffentlich setzen
                        <button class="modal-close">x</button>
                    </div>
                    <div class="modal-body">
                        <p>Ordner <b>${escHtml(itemName)}</b> fÃ¼r alle angemeldeten Nutzer sichtbar machen?</p>
                        <div style="margin-top:15px; padding:12px; background:rgba(255,255,255,0.05); border-radius:8px;">
                            <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px;">
                                <input type="checkbox" id="vis-cascade" style="width:18px; height:18px; flex-shrink:0;">
                                <span>Auch alle Unterordner und Dateien Ã¶ffentlich setzen (private Einzel-Einstellungen entfernen)</span>
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="vis-cancel">Abbrechen</button>
                        <button class="btn btn-success"   id="vis-confirm">ðŸŒ Ã–ffentlich setzen</button>
                    </div>
                </div>`);
            overlay.append(card);
            $('body').append(overlay);
            card.find('.modal-close, #vis-cancel').on('click', () => {
                overlay.remove();
                return;
            });
            card.find('#vis-confirm').on('click', () => {
                cascade = card.find('#vis-cascade').is(':checked');
                overlay.remove();
                doSetVisibility(path, 'public', cascade);
            });
            return;
        }
        // Einfache Datei
        const ok = await customModal({
            title: 'ðŸŒ Ã–ffentlich setzen',
            message: `<b>${escHtml(itemName)}</b> fÃ¼r alle angemeldeten Nutzer sichtbar machen?`,
            type: 'confirm',
            confirmText: 'Ã–ffentlich setzen'
        });
        if (ok) doSetVisibility(path, 'public', false);

    } else {
        // Aktuell Ã–FFENTLICH â†’ auf Privat setzen
        let msg = `<b>${escHtml(itemName)}</b> nur fÃ¼r Admins sichtbar machen?`;
        if (isFolder) msg += `<br><br><span style="font-size:12px; color:#94a3b8;">ðŸ’¡ Alle Unterordner und Dateien werden automatisch ausgeblendet â€“ kein einzelnes Setzen nÃ¶tig.</span>`;
        const ok = await customModal({
            title: 'ðŸ”’ Privat setzen',
            message: msg,
            type: 'confirm',
            confirmText: 'Privat setzen'
        });
        if (ok) doSetVisibility(path, 'private', false);
    }
}

function doSetVisibility(path, status, cascade) {
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            action: 'set_visibility',
            path,
            status,
            cascade
        }),
        success: res => {
            if (res.error) customModal({
                title: 'âŒ Fehler',
                message: escHtml(res.error)
            });
            else {
                customModal({
                    title: 'âœ… Gespeichert',
                    message: escHtml(res.success)
                });
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: 'âŒ Fehler',
            message: 'Fehler: ' + escHtml(jqXHR.responseText)
        })
    });
}

// Ordner Ã¶ffnen
function openFolderByPath(name) {
    name = decodeURIComponent(name);
    const pathInput = document.getElementById("directoryPath");
    const sep = pathInput.value.includes("\\") ? "\\" : "/";
    pathInput.value = pathInput.value.replace(/[/\\]$/, "") + sep + name;
    loadFiles();
}

$(document).on("click", "#fileTable tr", function(e) {
    if ($(e.target).closest("button, a").length > 0) return;
    const name = $(this).find("td:first").text().replace(/^[^\s]+\s/, "").replace(/ðŸ”’\s*$/, "").trim();
    const type = $(this).attr("data-type");
    if (type === "folder" || type === "Ordner") openFolderByPath(name);
});

// âœï¸ Datei bearbeiten
function handleEditAction(file, fullPath) {
    if (file && file.isSystemBlocked) {
        showSystemBlockedNotice(file.name || 'Dieser Eintrag');
        return;
    }
    if (isMediaFile(file.name)) {
        showMediaActionModal(file, fullPath);
        return;
    }
    editFile(file.name);
}

function showMediaActionModal(file, fullPath) {
    const fileName = escHtml(String(file.name || "").replace(/\uFFFD/g, "").replace(/[\u0000-\u001F\u007F]/g, ""));
    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:520px;">
            <div class="modal-header">Medien-Aktionen: ${fileName}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body">
                <p>Diese Datei kann nicht als Text bearbeitet werden. W&auml;hle stattdessen eine Aktion:</p>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                    <button type="button" class="btn btn-primary" id="media-meta-btn">ðŸ“ Metadaten bearbeiten</button>
                    <button type="button" class="btn btn-success" id="media-view-btn">ðŸ‘ï¸ Datei anzeigen</button>
                </div>
            </div>
        </div>
    `);
    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    card.find('.modal-close').on('click', close);
    card.find('#media-view-btn').on('click', () => {
        close();
        showMediaViewer(file, fullPath);
    });
    card.find('#media-meta-btn').on('click', () => {
        close();
        showMediaMetadataEditor(file, fullPath);
    });
}

function showMediaViewer(file, fullPath) {
    const encodedPath = encodeURIComponent(fullPath);
    const url = `download.php?path=${encodedPath}&inline=1`;
    const fileName = escHtml(String(file.name || "").replace(/\uFFFD/g, "").replace(/[\u0000-\u001F\u007F]/g, ""));

    let viewerHtml = '';
    if (isImageFile(file.name)) {
        viewerHtml = `<img src="${url}" alt="${fileName}" style="max-width:100%; max-height:70vh; border-radius:10px; display:block; margin:0 auto;">`;
    } else if (isVideoFile(file.name)) {
        viewerHtml = `<video controls style="width:100%; max-height:70vh; border-radius:10px; background:black;"><source src="${url}">Dein Browser unterst&uuml;tzt dieses Videoformat nicht.</video>`;
    } else {
        window.open(url, '_blank', 'noopener');
        return;
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:900px; width:min(900px, 95vw);">
            <div class="modal-header">Vorschau: ${fileName}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body" style="text-align:center;">
                ${viewerHtml}
                <p style="margin-top:12px; font-size:12px; opacity:0.75;">Falls die Vorschau blockiert ist, &ouml;ffnet der Link die Datei direkt.</p>
            </div>
            <div class="modal-footer">
                <a href="${url}" target="_blank" rel="noopener" class="btn btn-success">In neuem Tab &ouml;ffnen</a>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);
    card.find('.modal-close').on('click', () => overlay.remove());
}

async function showMediaMetadataEditor(file, fullPath) {
    let meta = null;
    let responseData = null;
    try {
        responseData = await $.ajax({
            url: 'media_api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'get', path: fullPath })
        });
        if (responseData.error) {
            throw new Error(responseData.error);
        }
        meta = responseData.metadata || {};
    } catch (err) {
        customModal({
            title: 'Fehler',
            message: escHtml(err.message || 'Metadaten konnten nicht geladen werden.')
        });
        return;
    }

    const canEditMediaMeta = responseData && responseData.canEdit !== false;
    const blockedReason = responseData && responseData.metadata && responseData.metadata.systemBlocked
        ? 'Dieser Eintrag ist durch das System gesperrt und kann nicht bearbeitet werden.'
        : (!canEditMediaMeta ? 'Metadaten bearbeiten ist fuer diesen Eintrag nicht erlaubt.' : '');

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:650px;">
            <div class="modal-header">Metadaten: ${escHtml(file.name)}
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body">
                <div style="font-size:12px; opacity:0.75; margin-bottom:12px;">
                    Typ: <b>${escHtml(meta.mimeType || 'unbekannt')}</b> - Gr&ouml;&szlig;e: <b>${escHtml(meta.sizeFormatted || '-')}</b>
                </div>
                ${blockedReason ? `<div class="alert alert-warning" style="margin-bottom:12px;">${escHtml(blockedReason)}</div>` : ''}
                <label style="display:block; margin-bottom:6px;">Datum/Zeit</label>
                <input type="text" id="meta-capturedAt" class="modal-input" placeholder="z. B. 2026-05-31 14:30:00" value="${escHtml(meta.capturedAt || '')}">

                <label style="display:block; margin:12px 0 6px;">Standort</label>
                <input type="text" id="meta-location" class="modal-input" placeholder="z. B. Berlin, Deutschland" value="${escHtml(meta.location || '')}">

                <label style="display:block; margin:12px 0 6px;">Beschreibung</label>
                <textarea id="meta-description" class="modal-input" rows="4" style="resize:vertical;">${escHtml(meta.description || '')}</textarea>

                <p style="font-size:12px; opacity:0.7; margin-top:10px;">Hinweis: Datum aktualisiert zus&auml;tzlich das Dateidatum, Standort/Beschreibung werden systemseitig gespeichert.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="meta-cancel-btn">Abbrechen</button>
                <button type="button" class="btn btn-primary" id="meta-save-btn" ${canEditMediaMeta ? '' : 'disabled'}>Speichern</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    card.find('.modal-close, #meta-cancel-btn').on('click', close);
    if (!canEditMediaMeta) {
        card.find('#meta-capturedAt, #meta-location, #meta-description').prop('disabled', true);
    }

    card.find('#meta-save-btn').on('click', async () => {
        if (!canEditMediaMeta) {
            customModal({
                title: 'Gesperrt',
                message: escHtml(blockedReason || 'Dieser Eintrag kann nicht bearbeitet werden.')
            });
            return;
        }
        const payload = {
            action: 'save',
            path: fullPath,
            metadata: {
                capturedAt: card.find('#meta-capturedAt').val().trim(),
                location: card.find('#meta-location').val().trim(),
                description: card.find('#meta-description').val().trim()
            }
        };

        const saveBtn = card.find('#meta-save-btn');
        saveBtn.prop('disabled', true).text('Speichert...');

        try {
            const response = await $.ajax({
                url: 'media_api.php',
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify(payload)
            });
            if (response.error) {
                throw new Error(response.error);
            }
            close();
            customModal({
                title: 'Gespeichert',
                message: escHtml(response.success || 'Metadaten wurden gespeichert.')
            });
            loadFiles();
        } catch (err) {
            saveBtn.prop('disabled', false).text('Speichern');
            customModal({
                title: 'Fehler',
                message: escHtml(err.message || 'Metadaten konnten nicht gespeichert werden.')
            });
        }
    });
}
let currentEditingPath = "";

function editFile(name) {
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    currentEditingPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.getJSON(`api.php?action=open&path=${encodeURIComponent(currentEditingPath)}`, data => {
        if (data.error) return customModal({
            title: 'âŒ Fehler',
            message: escHtml(data.error)
        });
        $("#editTitle").text(`Bearbeite: ${name}`);
        openEditModal();
        if (editor) {
            editor.setValue(data.content || "");
            const ext = name.split('.').pop().toLowerCase();
            const langMap = {
                php: "php",
                js: "javascript",
                css: "css",
                html: "html",
                txt: "plaintext"
            };
            monaco.editor.setModelLanguage(editor.getModel(), langMap[ext] || "plaintext");
            setTimeout(() => editor.layout(), 300);
        }
    }).fail(jqXHR => customModal({
        title: 'âŒ Fehler',
        message: "Fehler: " + escHtml(jqXHR.responseText)
    }));
}

// ðŸ’¾ Datei speichern
async function saveFile() {
    if (!editor) return;
    const content = editor.getValue();
    $.ajax({
        url: "api.php",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({
            action: "save",
            path: currentEditingPath,
            content
        }),
        success: response => {
            if (response.error) customModal({
                title: 'âŒ Fehler',
                message: escHtml(response.error)
            });
            else {
                customModal({
                    title: 'âœ… Gespeichert',
                    message: response.success || "Gespeichert."
                });
                closeEditModal();
                loadFiles();
            }
        },
        error: jqXHR => customModal({
            title: 'âŒ Fehler',
            message: "Fehler beim Speichern: " + escHtml(jqXHR.responseText)
        })
    });
}

// ðŸ“ Modal
function openEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        overlay.classList.remove("hidden");
        $(overlay).fadeIn();
    }
    modal.classList.remove("hidden");
    modal.classList.add("show");
    $(modal).fadeIn();
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    const overlay = document.getElementById("editModalOverlay");
    if (overlay) {
        $(overlay).fadeOut(() => overlay.classList.add("hidden"));
    }
    modal.classList.remove("show");
    $(modal).fadeOut(() => modal.classList.add("hidden"));
}

// ðŸ—‘ï¸ LÃ¶schen (Server entscheidet Ã¼ber Berechtigung)
async function deleteFile(name) {
    const confirmed = await customModal({
        title: 'ðŸ—‘ï¸ LÃ¶schen bestÃ¤tigen',
        message: `"${escHtml(name)}" wirklich lÃ¶schen?`,
        type: 'confirm',
        confirmText: 'Ja',
        cancelText: 'Nein'
    });
    if (!confirmed) return;
    const dir = document.getElementById("directoryPath").value.trim();
    const sep = dir.includes("\\") ? "\\" : "/";
    const fullPath = dir.replace(/[/\\]$/, "") + sep + name;
    $.post("api.php", JSON.stringify({
        action: "delete",
        path: fullPath
    }), response => {
        if (response.error) customModal({
            title: 'âŒ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'âœ… GelÃ¶scht',
                message: response.success || "GelÃ¶scht."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: 'âŒ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// ðŸ“¦ ZIP packen
async function zipFolder(fullPath) {
    const name = fullPath.split(/[\/\\]/).pop();
    const confirmed = await customModal({
        title: 'ðŸ“¦ Ordner packen',
        message: `Ordner <b>${escHtml(name)}</b> als ZIP-Archiv packen?`,
        type: 'confirm',
        confirmText: 'ðŸ“¦ Packen',
        cancelText: 'Abbrechen'
    });
    if (!confirmed) return;
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ action: 'zip_folder', path: fullPath }),
        dataType: 'json',
        success: res => {
            if (res.error) {
                customModal({ title: 'âŒ Fehler', message: escHtml(res.error) });
            } else {
                customModal({ title: 'âœ… Erfolg', message: escHtml(res.success) });
                loadFiles();
            }
        },
        error: jqXHR => customModal({ title: 'âŒ Fehler', message: 'Verbindungsfehler: ' + escHtml(jqXHR.responseText) })
    });
}

// ðŸ“¦ ZIP entpacken
async function unzipFile(fullPath) {
    const name = fullPath.split(/[\/\\]/).pop();
    const confirmed = await customModal({
        title: 'ðŸ“¦ ZIP entpacken',
        message: `<b>${escHtml(name)}</b> hier entpacken?`,
        type: 'confirm',
        confirmText: 'ðŸ“¦ Entpacken',
        cancelText: 'Abbrechen'
    });
    if (!confirmed) return;
    $.ajax({
        url: 'api.php',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ action: 'unzip_file', path: fullPath }),
        dataType: 'json',
        success: res => {
            if (res.error) {
                customModal({ title: 'âŒ Fehler', message: escHtml(res.error) });
            } else {
                customModal({ title: 'âœ… Erfolg', message: escHtml(res.success) });
                loadFiles();
            }
        },
        error: jqXHR => customModal({ title: 'âŒ Fehler', message: 'Verbindungsfehler: ' + escHtml(jqXHR.responseText) })
    });
}

async function showTrashManager() {
    if (!window.isSystemAdmin) {
        return customModal({
            title: 'Zugriff verweigert',
            message: 'Admin-Rechte erforderlich.'
        });
    }

    const overlay = $('<div class="modal-overlay modal-front"></div>');
    const card = $(`
        <div class="modal-card" style="max-width:900px; width:min(900px, 95vw);">
            <div class="modal-header">ðŸ—‘ï¸ Papierkorb
                <button class="modal-close" type="button">x</button>
            </div>
            <div class="modal-body">
                <div id="trash-status" style="margin-bottom:12px; opacity:0.8;">Lade Papierkorb...</div>
                <div id="trash-content"></div>
            </div>
            <div class="modal-footer" style="gap:10px; flex-wrap:wrap;">
                <button type="button" class="btn btn-secondary" id="trash-close-btn">SchlieÃŸen</button>
                <button type="button" class="btn btn-danger" id="trash-empty-btn">ðŸ§¹ Papierkorb leeren</button>
            </div>
        </div>
    `);

    overlay.append(card);
    $('body').append(overlay);

    const close = () => overlay.remove();
    card.find('.modal-close, #trash-close-btn').on('click', close);

    const renderTrash = (items) => {
        const content = card.find('#trash-content').empty();
        const status = card.find('#trash-status');

        if (!items.length) {
            status.text('Der Papierkorb ist leer.');
            content.append('<p style="margin:0; color:var(--text-muted);">Keine gelÃ¶schten Elemente vorhanden.</p>');
            return;
        }

        status.text(`${items.length} Element(e) gefunden.`);
        const table = $(`
            <div style="overflow:auto; border:1px solid var(--border); border-radius:12px;">
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr style="background:rgba(255,255,255,0.04);">
                            <th style="text-align:left; padding:12px;">Name</th>
                            <th style="text-align:left; padding:12px;">Ursprung</th>
                            <th style="text-align:left; padding:12px;">GelÃ¶scht</th>
                            <th style="text-align:left; padding:12px;">Typ</th>
                            <th style="text-align:left; padding:12px;">GrÃ¶ÃŸe</th>
                            <th style="text-align:left; padding:12px;">Aktionen</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        `);
        const tbody = table.find('tbody');

        items.forEach(item => {
            const row = $(`
                <tr>
                    <td style="padding:12px; border-top:1px solid var(--border);">${escHtml(item.originalName || item.trashName)}</td>
                    <td style="padding:12px; border-top:1px solid var(--border); font-size:12px; opacity:0.8;">${escHtml(item.originalPath || '-')}</td>
                    <td style="padding:12px; border-top:1px solid var(--border); white-space:nowrap;">${escHtml(item.deletedAt || '-')}</td>
                    <td style="padding:12px; border-top:1px solid var(--border);">${item.isDir ? 'Ordner' : 'Datei'}</td>
                    <td style="padding:12px; border-top:1px solid var(--border); white-space:nowrap;">${escHtml(item.sizeFormatted || '-')}</td>
                    <td style="padding:12px; border-top:1px solid var(--border);">
                        <div style="display:flex; gap:8px; flex-wrap:wrap;">
                            <button type="button" class="btn btn-success btn-small js-trash-restore">â†©ï¸ Wiederherstellen</button>
                            <button type="button" class="btn btn-danger btn-small js-trash-delete">ðŸ—‘ï¸ LÃ¶schen</button>
                        </div>
                    </td>
                </tr>
            `);

            row.find('.js-trash-restore').on('click', async () => {
                const confirmed = await customModal({
                    title: 'â†©ï¸ Wiederherstellen',
                    message: `"<b>${escHtml(item.originalName || item.trashName)}</b>" wiederherstellen?`,
                    type: 'confirm',
                    confirmText: 'Wiederherstellen',
                    cancelText: 'Abbrechen'
                });
                if (!confirmed) return;
                $.ajax({
                    url: 'api.php',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({ action: 'trash_restore', trashName: item.trashName }),
                    success: res => {
                        if (res.error) {
                            customModal({ title: 'Fehler', message: escHtml(res.error) });
                        } else {
                            showTrashManager();
                        }
                    },
                    error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
                });
            });

            row.find('.js-trash-delete').on('click', async () => {
                const confirmed = await customModal({
                    title: 'ðŸ—‘ï¸ EndgÃ¼ltig lÃ¶schen',
                    message: `"<b>${escHtml(item.originalName || item.trashName)}</b>" endgÃ¼ltig lÃ¶schen?`,
                    type: 'confirm',
                    confirmText: 'LÃ¶schen',
                    cancelText: 'Abbrechen'
                });
                if (!confirmed) return;
                $.ajax({
                    url: 'api.php',
                    type: 'POST',
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({ action: 'trash_delete', trashName: item.trashName }),
                    success: res => {
                        if (res.error) {
                            customModal({ title: 'Fehler', message: escHtml(res.error) });
                        } else {
                            showTrashManager();
                        }
                    },
                    error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
                });
            });

            tbody.append(row);
        });

        content.append(table);
    };

    const loadTrash = () => {
        card.find('#trash-status').text('Lade Papierkorb...');
        $.ajax({
            url: 'api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'trash_list' }),
            success: res => {
                if (res.error) {
                    card.find('#trash-status').text('Fehler beim Laden des Papierkorbs.');
                    card.find('#trash-content').html(`<div style="color:#ffb4b4;">${escHtml(res.error)}</div>`);
                    return;
                }
                renderTrash(res.items || []);
            },
            error: jqXHR => {
                card.find('#trash-status').text('Fehler beim Laden des Papierkorbs.');
                card.find('#trash-content').html(`<div style="color:#ffb4b4;">${escHtml(jqXHR.responseText || 'Unbekannter Fehler')}</div>`);
            }
        });
    };

    card.find('#trash-empty-btn').on('click', async () => {
        const confirmed = await customModal({
            title: 'ðŸ§¹ Papierkorb leeren',
            message: 'Alle Elemente im Papierkorb endgÃ¼ltig lÃ¶schen?',
            type: 'confirm',
            confirmText: 'Leeren',
            cancelText: 'Abbrechen'
        });
        if (!confirmed) return;
        $.ajax({
            url: 'api.php',
            type: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify({ action: 'trash_empty' }),
            success: res => {
                if (res.error) {
                    customModal({ title: 'Fehler', message: escHtml(res.error) });
                } else {
                    showTrashManager();
                }
            },
            error: jqXHR => customModal({ title: 'Fehler', message: escHtml(jqXHR.responseText) })
        });
    });

    loadTrash();
}

// ðŸ“„ Umbenennen (Server entscheidet Ã¼ber Berechtigung)
async function renameFile(oldName) {
    const newName = await customModal({
        title: 'ðŸ“„ Umbenennen',
        message: 'Neuer Name:',
        type: 'prompt',
        defaultValue: oldName
    });
    if (!newName || newName === oldName) return;
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "rename",
        path: dir,
        oldName,
        newName
    }), response => {
        if (response.error) customModal({
            title: 'âŒ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'âœ… Umbenannt',
                message: response.success || "Umbenannt."
            });
            loadFiles();
        }
    }, "json").fail(jqXHR => customModal({
        title: 'âŒ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

// âž• Erstellen (Server entscheidet Ã¼ber Berechtigung)
async function createFile(isFolder = false) {
    if (currentDirectorySystemBlocked) {
        showSystemBlockedNotice('Dieser Ordner');
        return;
    }
    const inputId = isFolder ? "newFolderName" : "newFileName";
    const name = document.getElementById(inputId).value.trim();
    if (!name) return customModal({
        title: 'âš ï¸ Eingabe erforderlich',
        message: "Bitte Namen eingeben!"
    });
    const dir = document.getElementById("directoryPath").value.trim();
    $.post("api.php", JSON.stringify({
        action: "create",
        path: dir,
        fileName: name,
        type: isFolder ? "folder" : "file"
    }), response => {
        if (response.error) customModal({
            title: 'âŒ Fehler',
            message: escHtml(response.error)
        });
        else {
            customModal({
                title: 'âœ… Erstellt',
                message: response.success || "Erstellt."
            });
            loadFiles();
            document.getElementById(inputId).value = "";
        }
    }, "json").fail(jqXHR => customModal({
        title: 'âŒ Fehler',
        message: escHtml(jqXHR.responseText)
    }));
}

function createFolder() {
    createFile(true);
}

// â¬†ï¸ Upload
function uploadFile(event) {
    if (event) event.preventDefault();
    const fileInput = document.getElementById("uploadFile");
    const path = document.getElementById("directoryPath").value;

    if (currentDirectorySystemBlocked) {
        showSystemBlockedNotice('Dieser Ordner');
        return;
    }

    let fileToUpload = null;
    if (fileInput.files.length) {
        fileToUpload = fileInput.files[0];
    } else if (window.droppedFile) {
        fileToUpload = window.droppedFile;
    }

    if (!fileToUpload) {
        return customModal({
            title: 'Auswahl erforderlich',
            message: "Bitte w\u00e4hle eine Datei aus."
        });
    }

    const maxSize = 2 * 1024 * 1024 * 1024;
    if (fileToUpload.size > maxSize) {
        return customModal({
            title: 'Datei zu gro\u00df',
            message: `Die Datei "${escHtml(fileToUpload.name)}" ist zu gro\u00df (${(fileToUpload.size / 1024 / 1024 / 1024).toFixed(2)} GB). Das maximale Upload-Limit betr\u00e4gt 2 GB.`
        });
    }

    const progressContainer = document.getElementById("uploadProgressContainer");
    const progressBar = document.getElementById("uploadProgressBar");
    const uploadBtn = document.getElementById("uploadBtn");

    progressContainer.style.display = "block";
    progressBar.style.width = "0%";
    uploadBtn.disabled = true;
    uploadBtn.textContent = "L\u00e4dt...";

    const resetUploadUI = () => {
        progressContainer.style.display = "none";
        progressBar.style.width = "0%";
        uploadBtn.disabled = false;
        uploadBtn.textContent = "Hochladen";
    };

    uploadFileInChunks(fileToUpload, path, progress => {
        progressBar.style.width = `${progress}%`;
        uploadBtn.textContent = `${progress}%`;
    }).then(message => {
        resetUploadUI();
        customModal({
            title: 'Upload-Status',
            message: escHtml(message)
        });
        loadFiles();
        fileInput.value = "";
        window.droppedFile = null;
        const lbl = document.getElementById('selectedFileName');
        if (lbl) lbl.textContent = "Keine Datei ausgew\u00e4hlt oder hier ablegen";
    }).catch(err => {
        resetUploadUI();
        customModal({
            title: 'Fehler',
            message: escHtml(err.message || 'Fehler beim Hochladen.')
        });
    });
}

function uploadFileInChunks(file, path, onProgress) {
    const chunkSize = 8 * 1024 * 1024;
    const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
    const uploadId = `up_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;

    return new Promise((resolve, reject) => {
        let chunkIndex = 0;

        const sendNextChunk = () => {
            if (chunkIndex >= totalChunks) {
                resolve(`Datei erfolgreich hochgeladen: ${file.name}`);
                return;
            }

            const start = chunkIndex * chunkSize;
            const end = Math.min(start + chunkSize, file.size);
            const chunk = file.slice(start, end);

            const formData = new FormData();
            formData.append('uploadFile', chunk, file.name);
            formData.append('path', path);
            formData.append('chunkIndex', String(chunkIndex));
            formData.append('totalChunks', String(totalChunks));
            formData.append('uploadId', uploadId);
            formData.append('originalName', file.name);
            formData.append('totalFileSize', String(file.size));

            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'upload.php', true);

            xhr.upload.onprogress = function (e) {
                if (!e.lengthComputable) return;
                const chunkFraction = e.total > 0 ? (e.loaded / e.total) : 0;
                const totalProgress = ((chunkIndex + chunkFraction) / totalChunks) * 100;
                onProgress(Math.max(1, Math.min(100, Math.round(totalProgress))));
            };

            xhr.onload = function () {
                if (xhr.status < 200 || xhr.status >= 300) {
                    reject(new Error(xhr.responseText || `Upload fehlgeschlagen (HTTP ${xhr.status}).`));
                    return;
                }

                chunkIndex += 1;
                onProgress(Math.max(1, Math.min(100, Math.round((chunkIndex / totalChunks) * 100))));
                sendNextChunk();
            };

            xhr.onerror = function () {
                reject(new Error('Netzwerkfehler beim Hochladen.'));
            };

            xhr.send(formData);
        };

        sendNextChunk();
    });
}
// ðŸ§  Monaco
if (typeof require !== "undefined") {
    require(["vs/editor/editor.main"], function() {
        editor = monaco.editor.create(document.getElementById("editor"), {
            value: "// Warten auf Datei...",
            language: "plaintext",
            theme: darkMode ? "vs-dark" : "vs-light",
            fontSize: 14,
            automaticLayout: true,
            scrollbar: {
                verticalScrollbarSize: 8,
                horizontalScrollbarSize: 8,
                verticalHasArrows: false,
                horizontalHasArrows: false,
                useShadows: false
            }
        });
        
        editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, function() {
            saveFile();
        });
    });
}

// ðŸ“¦ Init
$(document).ready(() => {
    const modal = document.getElementById("editModal");
    if (modal) modal.classList.add("hidden");
    loadFiles();
    if (darkMode) document.body.classList.add("dark-mode");
    $("#uploadForm").on("submit", uploadFile);
    const dirInput = document.getElementById("directoryPath");
    if (dirInput) {
        dirInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                loadFiles();
            }
        });
    }

    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.style.border = '2px dashed var(--primary)';
        });
        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.style.border = '1px solid var(--border)';
            if (e.dataTransfer.files.length) {
                window.droppedFile = e.dataTransfer.files[0];
                const lbl = document.getElementById('selectedFileName');
                if (lbl) lbl.textContent = window.droppedFile.name;
                uploadFile(); // Auto-upload on drop
            }
        });
    }
});

// Search filter
function filterTable() {
    const term = document.getElementById('searchInput').value.toLowerCase();
    $('#fileTable tr').each(function() {
        const rowText = $(this).text().toLowerCase();
        $(this).toggle(rowText.indexOf(term) > -1);
    });
}
window.filterTable = filterTable;

// Global Ctrl-S handler
document.addEventListener("keydown", function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        const editModal = document.getElementById("editModal");
        if (editModal && !editModal.classList.contains("hidden")) {
            saveFile();
        }
    }
});

window.toggleDarkMode = toggleDarkMode;
window.createFile = createFile;
window.createFolder = createFolder;
window.showTrashManager = showTrashManager;
window.editFile = editFile;
window.saveFile = saveFile;
window.deleteFile = deleteFile;
window.renameFile = renameFile;
window.uploadFile = uploadFile;
window.closeEditModal = closeEditModal;

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    btn.textContent = input.type === "text" ? "ðŸ™ˆ" : "ðŸ‘ï¸";
}



