<?php
declare(strict_types=1);
session_start();

$configFile = __DIR__ . '/config.php';
if (file_exists($configFile)) {
    require_once $configFile;
    require_once __DIR__ . '/fm_common.php';
    try {
        $logDb = fm_open_db();
        fm_log_action($logDb, 'logout', '', 'Abgemeldet');
        $logDb->close();
    } catch (Throwable $e) {}
}

unset($_SESSION['admin_access']);
unset($_SESSION['filemanager_access']);
unset($_SESSION['filemanager_last_action']);

setcookie(
    'filemanager_access',
    '',
    [
        'expires'  => time() - 3600,
        'path'     => '/filemanager',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict'
    ]
);

session_regenerate_id(true);

header('Location: login_filemanager.php');
exit;