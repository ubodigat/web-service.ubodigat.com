<?php
session_start();
unset($_SESSION["admin_access"]);
header("Location: file_manager.php");
exit;
?>
