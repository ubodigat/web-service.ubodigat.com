<?php
header("Content-Type: application/json");

// 🕑 **Zeitzone auf Deutschland setzen**
date_default_timezone_set("Europe/Berlin");

// 🔍 **Debug-Log aktivieren (optional für Fehleranalyse)**
$log_file = __DIR__ . "/debug.log";
file_put_contents($log_file, date("Y-m-d H:i:s") . " - Request: " . file_get_contents("php://input") . PHP_EOL, FILE_APPEND);

// **Basispfad setzen (sicherstellen, dass Nutzer nur in diesem Ordner arbeiten)**
$baseDir = realpath(__DIR__ . "/webseite");

// **Eingehende Daten verarbeiten**
$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'] ?? $_GET['action'] ?? null;
$dir = $data['dir'] ?? $_GET['dir'] ?? null;

// **Sicherstellen, dass das Verzeichnis existiert und gültig ist**
if ($dir) {
    $dir = realpath($dir);
} else {
    $dir = $baseDir; // Falls kein Verzeichnis angegeben ist, Standard setzen
}

// **Falls das Verzeichnis NULL oder ungültig ist, Fehler ausgeben**
if (!$dir || strpos($dir, $baseDir) !== 0) {
    file_put_contents($log_file, "❌ Ungültiges Verzeichnis: " . ($dir ?: "NULL") . "\n", FILE_APPEND);
    echo json_encode(["error" => "Ungültiges Verzeichnis: " . ($dir ?: "NULL")]);
    exit;
}

// **Falls keine Aktion angegeben wurde, Fehler zurückgeben**
if (!$action) {
    file_put_contents($log_file, "⚠️ Fehlende Aktion: " . json_encode($data) . "\n", FILE_APPEND);
    echo json_encode(["error" => "Fehlende oder ungültige Aktion"]);
    exit;
}

// 🔍 **Debugging: Aktion & Verzeichnis protokollieren**
file_put_contents($log_file, "✅ Aktion: $action | Verzeichnis: $dir\n", FILE_APPEND);

switch ($action) {

    // 📂 **Dateien & Ordner auflisten**
    case "list":
        $files = [];
        if (!is_dir($dir)) {
            echo json_encode(["error" => "Verzeichnis existiert nicht."]);
            exit;
        }

        foreach (scandir($dir) as $file) {
            if ($file === "." || $file === "..") continue;
            $filePath = $dir . DIRECTORY_SEPARATOR . $file;
            $files[] = [
                "name" => $file,
                "type" => is_dir($filePath) ? "Ordner" : "Datei",
                "modified" => date("d.m.Y H:i", filemtime($filePath)) // ✅ **Korrigierte Uhrzeit**
            ];
        }
        echo json_encode($files);
        break;

    // ✏️ **Datei öffnen**
    case "open":
        if (!isset($_GET['file'])) {
            echo json_encode(["error" => "Keine Datei angegeben."]);
            exit;
        }
    
        $file = realpath($dir . DIRECTORY_SEPARATOR . $_GET['file']);
    
        if (!$file || !file_exists($file) || !is_readable($file) || strpos($file, $baseDir) !== 0) {
            echo json_encode(["error" => "Datei konnte nicht geladen werden."]);
            exit;
        }
    
        $content = file_get_contents($file);
        if ($content === false) {
            echo json_encode(["error" => "Fehler beim Lesen der Datei."]);
            exit;
        }        
        
        // 🛠 Debugging: Loggt den Inhalt der Datei
        file_put_contents("debug.log", "Datei geladen: " . $file . "\nInhalt:\n" . $content . "\n", FILE_APPEND);
        
        // 🚀 Sicherstellen, dass keine unerwarteten HTML-Tags oder Styles gesendet werden
        header("Content-Type: application/json; charset=UTF-8");
        echo json_encode(["content" => $content]);
        exit;      

    // 💾 **Datei speichern**
    case "save":
        if (!isset($data['file']) || !isset($data['content'])) {
            echo json_encode(["error" => "Fehlende Parameter."]);
            exit;
        }

        $file = realpath($dir . DIRECTORY_SEPARATOR . $data['file']);
        if (!$file || strpos($file, $baseDir) !== 0) {
            echo json_encode(["error" => "Ungültige Datei."]);
            exit;
        }

        if (file_put_contents($file, $data['content']) === false) {
            echo json_encode(["error" => "Fehler beim Speichern."]);
        } else {
            echo json_encode(["success" => "Datei erfolgreich gespeichert."]);
        }
        break;

    // ✏️ **Datei umbenennen**
    case "rename":
        if (!isset($data['oldName']) || !isset($data['newName'])) {
            echo json_encode(["error" => "Fehlende Parameter für Umbenennung."]);
            exit;
        }

        $oldFile = realpath($dir . DIRECTORY_SEPARATOR . $data['oldName']);
        $newFile = $dir . DIRECTORY_SEPARATOR . basename($data['newName']);

        if (!$oldFile || strpos($oldFile, $baseDir) !== 0 || file_exists($newFile)) {
            echo json_encode(["error" => "Ungültige Umbenennung oder Datei existiert bereits."]);
            exit;
        }

        if (rename($oldFile, $newFile)) {
            echo json_encode(["success" => "Datei erfolgreich umbenannt."]);
        } else {
            echo json_encode(["error" => "Fehler beim Umbenennen."]);
        }
        break;

    // 🗑️ **Datei oder Ordner löschen**
    case "delete":
        if (!isset($data['file'])) {
            echo json_encode(["error" => "Keine Datei angegeben."]);
            exit;
        }

        $file = realpath($dir . DIRECTORY_SEPARATOR . $data['file']);
        if (!$file || strpos($file, $baseDir) !== 0) {
            echo json_encode(["error" => "Ungültige Datei oder Ordner."]);
            exit;
        }

        if (is_dir($file)) {
            if (!rmdir($file)) {
                echo json_encode(["error" => "Ordner konnte nicht gelöscht werden."]);
                exit;
            }
        } else {
            if (!unlink($file)) {
                echo json_encode(["error" => "Datei konnte nicht gelöscht werden."]);
                exit;
            }
        }

        echo json_encode(["success" => "Erfolgreich gelöscht."]);
        break;

    // 📂 **Neue Datei oder Ordner erstellen**
    case "create":
        if (!isset($data['fileName']) || !isset($data['type'])) {
            echo json_encode(["error" => "Kein Name oder Typ angegeben."]);
            exit;
        }
    
        $newPath = $dir . DIRECTORY_SEPARATOR . basename($data['fileName']);
    
        if (file_exists($newPath)) {
            echo json_encode(["error" => "Datei oder Ordner existiert bereits."]);
            exit;
        }
    
        // 📂 **Ordner-Erstellung**
        if ($data['type'] === "folder") {
            if (mkdir($newPath, 0777, true)) {
                echo json_encode(["success" => "Ordner erfolgreich erstellt."]);
            } else {
                echo json_encode(["error" => "Ordner konnte nicht erstellt werden."]);
            }
        } else {
            // 📄 **Datei-Erstellung**
            if (file_put_contents($newPath, "") !== false) {
                echo json_encode(["success" => "Datei erfolgreich erstellt."]);
            } else {
                echo json_encode(["error" => "Datei konnte nicht erstellt werden."]);
            }
        }
        break;    
}
?>
