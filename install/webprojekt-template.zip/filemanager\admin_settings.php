<?php
declare(strict_types=1);
session_start();

// 1. Nur Admins
if (empty($_SESSION['admin_access'])) {
    header('Location: admin_login.php');
    exit;
}

$configFile = __DIR__ . '/config.php';
require_once $configFile;
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);
$db->set_charset('utf8mb4');

$securityFile = __DIR__ . '/../config/security.php';
if (!file_exists($securityFile)) {
    die('❌ security.php fehlt.');
}
require_once $securityFile;

// ── TOTP Hilfsfunktionen ──────────────────────────────────────────────────────
function generate2FASecret(int $length = 16): string
{
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < $length; $i++) $secret .= $chars[random_int(0, 31)];
    return $secret;
}

function calculateTOTP(string $secret, int $time): string
{
    $secret = strtoupper($secret);
    $base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $charsFlipped = array_flip(str_split($base32chars));
    $bin = '';
    $v = 0; $vbits = 0;
    foreach (str_split($secret) as $char) {
        if (!isset($charsFlipped[$char])) continue;
        $v = ($v << 5) | $charsFlipped[$char];
        $vbits += 5;
        if ($vbits >= 8) { $vbits -= 8; $bin .= chr(($v >> $vbits) & 255); }
    }
    $timeStr = pack('N*', 0) . pack('N*', $time);
    $hmac = hash_hmac('sha1', $timeStr, $bin, true);
    $offset = ord($hmac[19]) & 0xf;
    $otp = (
        ((ord($hmac[$offset])   & 0x7f) << 24) |
        ((ord($hmac[$offset+1]) & 0xff) << 16) |
        ((ord($hmac[$offset+2]) & 0xff) <<  8) |
        ( ord($hmac[$offset+3]) & 0xff)
    ) % 1000000;
    return str_pad((string)$otp, 6, '0', STR_PAD_LEFT);
}

function verifyTOTP(string $secret, string $code): bool
{
    if (!$secret) return true;
    if (!$code)   return false;
    $time = (int)floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        if (calculateTOTP($secret, $time + $i) === $code) return true;
    }
    return false;
}

// ── Statusvariablen ───────────────────────────────────────────────────────────
$success = '';
$error   = '';

// Nach PRG-Redirect
if (isset($_GET['success'])) $success = '✅ ' . htmlspecialchars($_GET['success']);
if (isset($_GET['error']))   $error   = '❌ ' . htmlspecialchars($_GET['error']);

// ── DB-Migration: auth_secret Spalte ─────────────────────────────────────────
$res = $db->query("SHOW COLUMNS FROM benutzer LIKE 'auth_secret'");
if ($res && $res->num_rows === 0) {
    $db->query("ALTER TABLE benutzer ADD COLUMN auth_secret VARCHAR(64) NULL DEFAULT NULL");
}

// ── POST-Verarbeitung ─────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── AJAX: 2FA Secret generieren / abrufen ─────────────────────────────────
    if ($action === 'get_2fa_secret') {
        header('Content-Type: application/json');
        $id = (int)($_POST['user_id'] ?? 0);
        $stmt = $db->prepare("SELECT nutzername, auth_secret FROM benutzer WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $u = $stmt->get_result()->fetch_assoc();
        if (!$u) { echo json_encode(['error' => 'Benutzer nicht gefunden']); exit; }

        // Neues Secret generieren und temporär in Session speichern
        $secret = generate2FASecret();
        if (!isset($_SESSION['pending_2fa'])) $_SESSION['pending_2fa'] = [];
        $_SESSION['pending_2fa'][$id] = $secret;

        $label   = urlencode($u['nutzername']);
        $issuer  = urlencode('web-service');
        $uri     = "otpauth://totp/{$issuer}:{$label}?secret={$secret}&issuer={$issuer}&algorithm=SHA1&digits=6&period=30";

        echo json_encode(['secret' => $secret, 'uri' => $uri, 'username' => $u['nutzername'], 'has2fa' => !empty($u['auth_secret'])]);
        exit;
    }

    // ── AJAX: 2FA Setup bestätigen ────────────────────────────────────────────
    if ($action === 'confirm_2fa_setup') {
        header('Content-Type: application/json');
        $id   = (int)($_POST['user_id'] ?? 0);
        $code = trim($_POST['code'] ?? '');

        $secret = $_SESSION['pending_2fa'][$id] ?? null;
        if (!$secret) { echo json_encode(['error' => 'Session abgelaufen. Bitte neu versuchen.']); exit; }

        if (!verifyTOTP($secret, $code)) {
            echo json_encode(['error' => 'Ungültiger Code – bitte erneut versuchen.']);
            exit;
        }

        $stmt = $db->prepare("UPDATE benutzer SET auth_secret = ? WHERE id = ?");
        $stmt->bind_param('si', $secret, $id);
        if ($stmt->execute()) {
            unset($_SESSION['pending_2fa'][$id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Datenbankfehler: ' . $db->error]);
        }
        exit;
    }

    // ── AJAX: 2FA deaktivieren ────────────────────────────────────────────────
    if ($action === 'disable_2fa') {
        $id = (int)($_POST['user_id'] ?? 0);
        if ($db->query("UPDATE benutzer SET auth_secret = NULL WHERE id = " . $id)) {
            $success = '🔓 2FA wurde deaktiviert.';
        } else {
            $error = '❌ Fehler beim Deaktivieren.';
        }
    }

    // ── Benutzer anlegen ──────────────────────────────────────────────────────
    if ($action === 'add_user') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        if ($user && $pass) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)");
            $stmt->bind_param('ss', $user, $hash);
            if ($stmt->execute())
                $success = "✅ Admin '$user' wurde angelegt.";
            else
                $error = '❌ Fehler: ' . $db->error;
        } else {
            $error = '❌ Benutzername und Passwort erforderlich.';
        }
    }

    // ── Benutzer bearbeiten ───────────────────────────────────────────────────
    if ($action === 'edit_user') {
        $id      = (int)($_POST['user_id'] ?? 0);
        $newName = trim($_POST['username'] ?? '');
        $newPass = $_POST['password'] ?? '';

        if ($newName) {
            if ($newPass) {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ?, passwort = ? WHERE id = ?");
                $stmt->bind_param('ssi', $newName, $hash, $id);
            } else {
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ? WHERE id = ?");
                $stmt->bind_param('si', $newName, $id);
            }
            if ($stmt->execute())
                $success = '✅ Benutzer aktualisiert.';
            else
                $error = '❌ Fehler: ' . $db->error;
        } else {
            $error = '❌ Benutzername darf nicht leer sein.';
        }
    }

    // ── Benutzer löschen ──────────────────────────────────────────────────────
    if ($action === 'delete_user') {
        $id = (int)($_POST['user_id'] ?? 0);
        $db->query("DELETE FROM benutzer WHERE id = " . $id);
        $success = '✅ Benutzer gelöscht.';
    }

    // ── Normalnutzer-Passwort ─────────────────────────────────────────────────
    if ($action === 'update_user_pass') {
        $newPass = $_POST['user_pass'] ?? '';
        if (strlen($newPass) < 4) {
            $error = '❌ Passwort zu kurz (min. 4 Zeichen).';
        } else {
            $hash    = password_hash($newPass, PASSWORD_BCRYPT);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FILEMANAGER_ACCESS_HASH', '.*?'\);/", "define('FILEMANAGER_ACCESS_HASH', '{$hash}');", $content);
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            header('Location: admin_settings.php?success=' . urlencode('Normalnutzer-Passwort aktualisiert.'));
            exit;
        }
    }

    // ── Hintergrundbild ───────────────────────────────────────────────────────
    if ($action === 'update_bg') {
        $type  = $_POST['bg_type'] ?? 'web';
        $const = ($type === 'web') ? 'WEB_LOGIN_BG' : 'FILEMANAGER_LOGIN_BG';

        if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['bg_file']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
            if (!in_array($ext, $allowed, true)) {
                $error = '❌ Nur Bilder erlaubt (jpg, png, webp, gif).';
            } else {
                $name   = 'bg_' . bin2hex(random_bytes(8)) . '.' . $ext;
                $target = __DIR__ . '/../uploads/' . $name;
                if (!is_dir(__DIR__ . '/../uploads')) mkdir(__DIR__ . '/../uploads', 0755, true);

                if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $target)) {
                    $path    = '/uploads/' . $name;
                    $content = file_get_contents($securityFile);
                    $content = preg_replace("/define\('$const', '.*?'\);/", "define('$const', '$path');", $content);
                    if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
                    file_put_contents($securityFile, $content);
                    header('Location: admin_settings.php?success=' . urlencode('Hintergrundbild aktualisiert.'));
                    exit;
                } else {
                    $error = '❌ Fehler beim Hochladen.';
                }
            }
        } else {
            $error = '❌ Keine Datei empfangen.';
        }
    }

    // ── Globale ACL ───────────────────────────────────────────────────────────
    if ($action === 'update_acl') {
        $can_del = isset($_POST['can_delete']) ? 'true' : 'false';
        $can_ren = isset($_POST['can_rename']) ? 'true' : 'false';
        $can_up  = isset($_POST['can_upload']) ? 'true' : 'false';
        $can_cre = isset($_POST['can_create']) ? 'true' : 'false';

        $content = file_get_contents($securityFile);
        $content = preg_replace("/define\('USER_CAN_DELETE', .*?\);/",  "define('USER_CAN_DELETE', $can_del);",  $content);
        $content = preg_replace("/define\('USER_CAN_RENAME', .*?\);/",  "define('USER_CAN_RENAME', $can_ren);",  $content);
        $content = preg_replace("/define\('USER_CAN_UPLOAD', .*?\);/",  "define('USER_CAN_UPLOAD', $can_up);",   $content);
        $content = preg_replace("/define\('USER_CAN_CREATE', .*?\);/",  "define('USER_CAN_CREATE', $can_cre);",  $content);

        if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
        if (file_put_contents($securityFile, $content)) {
            header('Location: admin_settings.php?success=' . urlencode('Globale Berechtigungen gespeichert.'));
            exit;
        } else {
            $error = '❌ Fehler beim Speichern.';
        }
    }

    // ── Ordnerspezifische ACL ─────────────────────────────────────────────────
    if ($action === 'update_folder_acl') {
        $path = trim($_POST['folder_path'] ?? '');
        $path = str_replace('\\', '/', $path);
        $path = trim($path, '/');

        if ($path !== '') {
            $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
            if (isset($folderPerms[$path])) unset($folderPerms[$path]);

            $folderPerms[$path] = [
                'delete'     => isset($_POST['can_delete']),
                'rename'     => isset($_POST['can_rename']),
                'upload'     => isset($_POST['can_upload']),
                'create'     => isset($_POST['can_create']),
                'is_private' => isset($_POST['is_private']),
            ];

            $json    = json_encode($folderPerms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'FOLDER_PERMISSIONS'") !== false) {
                $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/s", "define('FOLDER_PERMISSIONS', '$json');", $content);
            } else {
                $content .= "\ndefine('FOLDER_PERMISSIONS', '$json');\n";
            }
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            header('Location: admin_settings.php?success=' . urlencode('Ordner-Regel gespeichert.'));
            exit;
        } else {
            $error = '❌ Bitte Ordnerpfad angeben.';
        }
    }

    // ── Ordner-ACL löschen ────────────────────────────────────────────────────
    if ($action === 'delete_folder_acl') {
        $path        = $_POST['folder_path'] ?? '';
        $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
        if (isset($folderPerms[$path])) {
            unset($folderPerms[$path]);
            $json    = json_encode($folderPerms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'FOLDER_PERMISSIONS'") !== false) {
                $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/s", "define('FOLDER_PERMISSIONS', '$json');", $content);
            } else {
                $content .= "\ndefine('FOLDER_PERMISSIONS', '$json');\n";
            }
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            header('Location: admin_settings.php?success=' . urlencode('Ordner-Regel entfernt.'));
            exit;
        }
    }

    // ── PHP-Update Check (simuliert) ──────────────────────────────────────────
    if ($action === 'php_update') {
        $success = '✅ System-Check: PHP ' . phpversion() . ' ist aktuell.';
    }

    // ── Installation bereinigen ───────────────────────────────────────────────
    if ($action === 'cleanup_install') {
        $installDir = __DIR__ . '/../install/';
        if (is_dir($installDir)) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($installDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($files as $fileinfo) {
                ($fileinfo->isDir() ? 'rmdir' : 'unlink')($fileinfo->getRealPath());
            }
            rmdir($installDir);
            $success = '✅ Installationsdateien gelöscht.';
        } else {
            $error = '❌ Installationsordner nicht gefunden.';
        }
    }
}

// ── Daten für die Anzeige ─────────────────────────────────────────────────────
$users = $db->query("SELECT id, nutzername, auth_secret FROM benutzer ORDER BY id");

function getFolderList(string $dir, string $base, array &$folders = []): array
{
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..') continue;
        $full = $dir . DIRECTORY_SEPARATOR . $f;
        if (is_dir($full)) {
            $rel = trim(str_replace([$base, DIRECTORY_SEPARATOR], ['', '/'], $full), '/');
            if (!in_array($rel, ['config', 'install', 'sql', 'filemanager', '.git'], true)) {
                $folders[] = $rel;
                getFolderList($full, $base, $folders);
            }
        }
    }
    return $folders;
}
$basePath         = (string)realpath(__DIR__ . '/..');
$availableFolders = getFolderList($basePath, $basePath);
sort($availableFolders);

$fPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>⚙️ Admin-Einstellungen</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css?v=3">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/otpauth@9.3.5/dist/otpauth.umd.js"></script>
    <style>
        body { display:flex; justify-content:center; padding:20px; min-height:100vh; }
        .box { width:100%; max-width:900px; background:var(--bg-card); padding:30px; border-radius:16px; backdrop-filter:blur(20px); border:1px solid rgba(255,255,255,0.1); }
        .section { margin-bottom:30px; padding:25px; background:rgba(0,0,0,0.2); border-radius:12px; border:1px solid rgba(255,255,255,0.05); position:relative; }
        input, select { width:100%; padding:12px; border-radius:8px; border:1px solid #333; background:rgba(0,0,0,0.5); color:white; margin-bottom:15px; box-sizing:border-box; }
        .user-list td { padding:12px; border-bottom:1px solid rgba(255,255,255,0.1); }
        .nav-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:25px; }
        .alert { position:fixed; top:20px; left:50%; transform:translateX(-50%); padding:14px 28px; border-radius:12px; z-index:10000; font-weight:600; box-shadow:0 10px 30px rgba(0,0,0,0.4); pointer-events:auto; transition:opacity 0.5s; white-space:nowrap; }
        .alert-success { background:#059669; color:white; }
        .alert-danger, .alert-error { background:#dc2626; color:white; }
    </style>
</head>
<body class="dark-mode">
<div class="box">

    <div class="nav-header">
        <div style="display:flex; align-items:center; gap:15px;">
            <a href="file_manager.php" class="btn btn-secondary" style="width:auto;">⬅ Zurück</a>
            <div style="font-size:12px; opacity:0.7;">👤 Admin: <b><?= htmlspecialchars($_SESSION['admin_user'] ?? 'Unbekannt') ?></b></div>
        </div>
        <button onclick="toggleDarkMode()" class="btn btn-info" id="themeToggle" style="width:auto;">🌗 Tag/Nacht</button>
    </div>

    <h1>⚙️ Admin-Einstellungen</h1>

    <?php if ($success): ?>
        <div class="alert alert-success" id="statusMsg"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger" id="statusMsg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- ── Administratoren ──────────────────────────────────────────────────── -->
    <div class="section">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h2>👥 Administratoren</h2>
            <button onclick="showAddUser()" class="btn btn-success" style="width:auto;">➕ Neu</button>
        </div>
        <table class="user-list" style="width:100%;">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>2FA</th>
                    <th style="text-align:right;">Aktionen</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($u = $users->fetch_assoc()):
                    $has2fa = !empty($u['auth_secret']);
                    $uid    = (int)$u['id'];
                    $uname  = htmlspecialchars($u['nutzername'], ENT_QUOTES);
                ?>
                <tr>
                    <td><?= htmlspecialchars($u['nutzername']) ?></td>
                    <td><?= $has2fa ? '<span style="color:#10b981;">✅ Aktiv</span>' : '<span style="opacity:0.5;">❌</span>' ?></td>
                    <td style="text-align:right; white-space:nowrap;">
                        <button onclick='showEditUser(<?= $uid ?>, <?= json_encode($u["nutzername"]) ?>, <?= $has2fa ? "true" : "false" ?>)'
                                class="btn btn-primary btn-small" style="width:auto;">✏️ Bearbeiten</button>
                        <button onclick='deleteUser(<?= $uid ?>, <?= json_encode($u["nutzername"]) ?>)'
                                class="btn btn-danger btn-small" style="width:auto; margin-left:6px;">🗑️</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- ── Normalnutzer-Passwort ────────────────────────────────────────────── -->
    <div class="section">
        <h2>🔑 Normalnutzer-Zugang</h2>
        <form method="post">
            <input type="hidden" name="action" value="update_user_pass">
            <label style="color:#94a3b8; font-size:13px;">Neues Dateimanager-Passwort</label>
            <div class="password-wrapper">
                <input type="password" name="user_pass" id="user_pass" required placeholder="Neues Passwort">
                <button type="button" onclick="togglePassword('user_pass', this)" class="toggle-password">👁️</button>
            </div>
            <button type="submit" class="btn btn-primary" style="width:auto;">Speichern</button>
        </form>
    </div>

    <!-- ── Globale ACL ──────────────────────────────────────────────────────── -->
    <div class="section">
        <h2>🔐 Berechtigungen für Normalnutzer</h2>
        <form method="post" style="border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:20px; margin-bottom:20px;">
            <input type="hidden" name="action" value="update_acl">
            <h3>Globale Standardwerte</h3>
            <p style="font-size:12px; color:#94a3b8; margin-bottom:15px;">Diese Regeln gelten, sofern keine ordnerspezifische Regel existiert.</p>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                <div class="perm-item"><label><input type="checkbox" name="can_delete" <?= defined('USER_CAN_DELETE') && USER_CAN_DELETE ? 'checked' : '' ?>> 🗑️ Löschen</label></div>
                <div class="perm-item"><label><input type="checkbox" name="can_rename" <?= defined('USER_CAN_RENAME') && USER_CAN_RENAME ? 'checked' : '' ?>> 📄 Umbenennen</label></div>
                <div class="perm-item"><label><input type="checkbox" name="can_upload" <?= defined('USER_CAN_UPLOAD') && USER_CAN_UPLOAD ? 'checked' : '' ?>> 📤 Upload</label></div>
                <div class="perm-item"><label><input type="checkbox" name="can_create" <?= defined('USER_CAN_CREATE') && USER_CAN_CREATE ? 'checked' : '' ?>> ➕ Erstellen</label></div>
            </div>
            <button type="submit" class="btn btn-primary" style="margin-top:15px; width:auto;">Globale Rechte speichern</button>
        </form>

        <h3>📁 Ordnerspezifische Regeln</h3>
        <p style="font-size:12px; color:#94a3b8; margin-bottom:15px;">Hier kannst du exakte Berechtigungen für einzelne Verzeichnisse festlegen.</p>
        
        <form method="post" style="margin-bottom:25px; background:rgba(255,255,255,0.03); padding:20px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
            <input type="hidden" name="action" value="update_folder_acl">
            
            <div style="margin-bottom:15px;">
                <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:8px;">Ordner auswählen oder Pfad eingeben</label>
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <select onchange="this.nextElementSibling.value=this.value" style="width:200px; margin-bottom:0; flex-shrink:0;">
                        <option value="">-- Ordner wählen --</option>
                        <?php foreach ($availableFolders as $fold): ?>
                            <option value="<?= htmlspecialchars($fold) ?>"><?= htmlspecialchars($fold) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <input type="text" name="folder_path" placeholder="Pfad (z.B. projekte/kunden)" required style="flex:1; min-width:150px;">
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap:15px; margin-bottom:20px;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <label class="switch"><input type="checkbox" name="is_private"><span class="slider"></span></label>
                    <span style="font-size:13px;">🔒 Privat</span>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <label class="switch"><input type="checkbox" name="can_upload"><span class="slider"></span></label>
                    <span style="font-size:13px;">📤 Upload</span>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <label class="switch"><input type="checkbox" name="can_create"><span class="slider"></span></label>
                    <span style="font-size:13px;">➕ Erstellen</span>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <label class="switch"><input type="checkbox" name="can_rename"><span class="slider"></span></label>
                    <span style="font-size:13px;">📄 Umbenennen</span>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <label class="switch"><input type="checkbox" name="can_delete"><span class="slider"></span></label>
                    <span style="font-size:13px;">🗑️ Löschen</span>
                </div>
            </div>
            
            <button type="submit" class="btn btn-success" style="width:auto; padding:10px 20px;">Regel speichern</button>
        </form>

        <div class="rules-list">
            <?php if (empty($fPerms)): ?>
                <div style="text-align:center; opacity:0.5; padding:30px; background:rgba(255,255,255,0.02); border-radius:12px;">Keine spezifischen Regeln definiert.</div>
            <?php else: ?>
                <?php foreach ($fPerms as $p => $r): ?>
                    <div class="rule-card">
                        <div class="rule-info">
                            <span class="rule-path"><?= htmlspecialchars($p) ?></span>
                            <div class="rule-perms">
                                <span class="perm-badge <?= !empty($r['is_private']) ? 'active' : '' ?>">🔒 Privat</span>
                                <span class="perm-badge <?= !empty($r['upload']) ? 'active' : '' ?>">📤 Upload</span>
                                <span class="perm-badge <?= !empty($r['create']) ? 'active' : '' ?>">➕ Erstellen</span>
                                <span class="perm-badge <?= !empty($r['rename']) ? 'active' : '' ?>">📄 Umbenennen</span>
                                <span class="perm-badge <?= !empty($r['delete']) ? 'active' : '' ?>">🗑️ Löschen</span>
                            </div>
                        </div>
                        <div class="rule-actions">
                            <form method="post" onsubmit="return confirm('Regel für <?= htmlspecialchars($p) ?> wirklich löschen?')">
                                <input type="hidden" name="action" value="delete_folder_acl">
                                <input type="hidden" name="folder_path" value="<?= htmlspecialchars($p) ?>">
                                <button type="submit" class="btn btn-danger btn-small" title="Regel löschen">🗑️</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- ── Hintergrundbilder ────────────────────────────────────────────────── -->
    <div class="section">
        <h2>🖼️ Design & Hintergründe</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_bg">
            <label style="color:#94a3b8; font-size:13px;">Bereich</label>
            <select name="bg_type" style="margin-bottom:15px;">
                <option value="web">Web-Login (Besucher)</option>
                <option value="fm">Filemanager-Login</option>
            </select>
            <label style="color:#94a3b8; font-size:13px;">Bild hochladen (jpg, png, webp, gif)</label>
            <label class="custom-file-upload" style="margin-bottom:15px;">
                <input type="file" name="bg_file" accept="image/*" required
                    onchange="this.parentElement.querySelector('span').innerText=this.files[0].name"
                    style="display:none;">
                <span>📁 Datei auswählen...</span>
            </label>
            <button type="submit" class="btn btn-success" style="width:auto;">Aktualisieren</button>
        </form>
    </div>

    <!-- ── System-Info ──────────────────────────────────────────────────────── -->
    <div class="section" style="border:none;">
        <h2>ℹ️ System-Info & Wartung</h2>
        <p style="font-size:13px; opacity:0.7;">
            PHP: <code><?= phpversion() ?></code>&nbsp;&nbsp;
            Root: <code><?= htmlspecialchars($basePath) ?></code>
        </p>
        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:15px;">
            <form method="post">
                <input type="hidden" name="action" value="php_update">
                <button type="submit" class="btn btn-primary" style="width:200px;">🚀 PHP-Update prüfen</button>
            </form>
            <form method="post" id="cleanupForm">
                <input type="hidden" name="action" value="cleanup_install">
                <button type="button" class="btn btn-danger" style="width:200px;" onclick="confirmCleanup()">🧹 Installation bereinigen</button>
            </form>
        </div>
        <p style="font-size:12px; color:#94a3b8; margin-top:15px;">
            ⚠️ Der Ordner <code>config/</code> wird für Sicherheitseinstellungen benötigt und darf nicht gelöscht werden.
        </p>
    </div>
</div>

<script>
// ── Dark Mode ─────────────────────────────────────────────────────────────────
function toggleDarkMode() {
    const isDark = document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', isDark ? 'true' : 'false');
}
if (localStorage.getItem('darkMode') !== 'false') document.body.classList.add('dark-mode');

// ── Hilfsfunktionen ───────────────────────────────────────────────────────────
function escapeHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.textContent = input.type === 'text' ? '🙈' : '👁️';
}

// ── Auto-Hide Status-Alert ────────────────────────────────────────────────────
setTimeout(() => {
    const msg = document.getElementById('statusMsg');
    if (msg) msg.style.opacity = '0';
}, 6000);

// ── Benutzer anlegen ──────────────────────────────────────────────────────────
function showAddUser() {
    customModal({
        title: '👤 Neuen Admin anlegen',
        message: `
            <form id="addUserForm" method="post" style="text-align:left;">
                <input type="hidden" name="action" value="add_user">
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Benutzername</label>
                    <input type="text" name="username" required placeholder="z.B. admin"
                        style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.3); color:white; box-sizing:border-box;">
                </div>
                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Passwort</label>
                    <div class="password-wrapper" style="margin-bottom:0;">
                        <input type="password" name="password" id="pass_new_admin" required placeholder="Sicheres Passwort">
                        <button type="button" onclick="togglePassword('pass_new_admin',this)" class="toggle-password">👁️</button>
                    </div>
                </div>
                <button type="submit" class="btn btn-success" style="width:100%;">Benutzer anlegen</button>
            </form>`
    });
}

// ── Benutzer bearbeiten ───────────────────────────────────────────────────────
function showEditUser(id, name, has2fa) {
    customModal({
        title: '✏️ Bearbeiten: ' + escapeHtml(name),
        message: `
            <form method="post" style="text-align:left;">
                <input type="hidden" name="action" value="edit_user">
                <input type="hidden" name="user_id" value="${id}">
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Benutzername</label>
                    <input type="text" name="username" value="${escapeHtml(name)}" required
                        style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.3); color:white; box-sizing:border-box;">
                </div>
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Neues Passwort (optional)</label>
                    <div class="password-wrapper" style="margin-bottom:0;">
                        <input type="password" name="password" id="pass_edit_${id}" placeholder="Leer lassen = unverändert">
                        <button type="button" onclick="togglePassword('pass_edit_${id}',this)" class="toggle-password">👁️</button>
                    </div>
                </div>
                <div style="margin-bottom:20px; padding:15px; background:rgba(255,255,255,0.05); border-radius:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-weight:600;">🔐 2-Faktor-Authentifizierung</span>
                        <span style="font-size:12px; color:${has2fa ? '#10b981' : '#94a3b8'};">${has2fa ? '✅ Aktiviert' : '❌ Nicht aktiv'}</span>
                    </div>
                    <div style="margin-top:10px;">
                        ${has2fa
                            ? `<button type="button" onclick="disable2FA(${id}, '${escapeHtml(name)}')" class="btn btn-danger btn-small" style="width:auto;">🔓 Deaktivieren</button>`
                            : `<button type="button" onclick="show2FASetup(${id}, '${escapeHtml(name)}')" class="btn btn-success btn-small" style="width:auto;">🔐 2FA einrichten</button>`
                        }
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;">Änderungen speichern</button>
            </form>`
    });
}

// ── Benutzer löschen ──────────────────────────────────────────────────────────
async function deleteUser(id, name) {
    const ok = await customModal({
        title: '🗑️ Benutzer löschen',
        message: `Benutzer <b>${escapeHtml(name)}</b> wirklich löschen?`,
        type: 'confirm', confirmText: 'Ja, löschen', cancelText: 'Abbrechen'
    });
    if (ok) {
        const f = document.createElement('form');
        f.method = 'post';
        f.innerHTML = `<input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="${id}">`;
        document.body.appendChild(f);
        f.submit();
    }
}

// ── 2FA deaktivieren ─────────────────────────────────────────────────────────
async function disable2FA(id, name) {
    const ok = await customModal({
        title: '🔓 2FA deaktivieren',
        message: `2FA für <b>${escapeHtml(name)}</b> wirklich deaktivieren?`,
        type: 'confirm', confirmText: 'Deaktivieren', cancelText: 'Abbrechen'
    });
    if (ok) {
        const f = document.createElement('form');
        f.method = 'post';
        f.innerHTML = `<input type="hidden" name="action" value="disable_2fa"><input type="hidden" name="user_id" value="${id}">`;
        document.body.appendChild(f);
        f.submit();
    }
}

// ── 2FA einrichten (OTPAuth + QR-Code) ───────────────────────────────────────
async function show2FASetup(userId, userName) {
    // Schritt 1: Secret vom Server holen
    let data;
    try {
        const res = await fetch('admin_settings.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=get_2fa_secret&user_id=${userId}`
        });
        data = await res.json();
    } catch(e) {
        customModal({title:'❌ Fehler', message:'Netzwerkfehler beim Laden des Secrets.'});
        return;
    }
    if (data.error) { customModal({title:'❌ Fehler', message: escapeHtml(data.error)}); return; }

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(data.uri)}`;

    // Schritt 2: Modal mit QR-Code aufbauen
    const overlay = $('<div class="modal-overlay"></div>');
    const card    = $(`
        <div class="modal-card" style="max-width:420px; text-align:center;">
            <div class="modal-header" style="position:relative;">
                🔐 2FA Einrichten: ${escapeHtml(data.username)}
                <button class="modal-close" onclick="$(this).closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <p style="font-size:13px; opacity:0.8; margin-bottom:15px;">
                    Scanne den QR-Code mit <b>Google Authenticator</b>, <b>Authy</b> oder einer anderen TOTP-App.
                </p>
                <div style="background:white; padding:10px; display:inline-block; border-radius:8px; margin-bottom:15px;">
                    <img src="${qrUrl}" alt="QR Code" style="display:block; width:180px; height:180px;"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block'">
                    <p style="display:none; color:#333; font-size:11px; margin:0; padding:5px;">QR nicht ladbar – Secret manuell eingeben</p>
                </div>
                <p style="font-size:11px; margin-bottom:8px; opacity:0.5;">Oder Secret manuell eingeben:</p>
                <div style="font-family:monospace; font-size:18px; letter-spacing:3px; background:rgba(0,0,0,0.4); padding:12px; border-radius:8px; margin-bottom:10px; color:#2DE2E6; cursor:pointer; user-select:all;"
                     onclick="navigator.clipboard.writeText('${data.secret}'); this.textContent='✅ Kopiert!'; setTimeout(()=>this.textContent='${data.secret}',2000);">
                    ${data.secret}
                </div>
                <p style="font-size:11px; margin-bottom:20px; opacity:0.5;">Klicke auf den Secret zum Kopieren</p>
                <input type="text" id="twofa-code-input" placeholder="6-stelligen Code eingeben"
                    maxlength="6" inputmode="numeric" pattern="[0-9]*"
                    style="text-align:center; letter-spacing:5px; font-size:22px; width:100%; padding:14px; border-radius:10px; border:1px solid rgba(255,255,255,0.2); background:rgba(0,0,0,0.4); color:white; box-sizing:border-box;">
                <div id="twofa-error" style="color:#f87171; font-size:13px; margin-top:8px; display:none;"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="$(this).closest('.modal-overlay').remove()">Abbrechen</button>
                <button class="btn btn-success" id="btn-finish-2fa">✅ Einrichtung abschließen</button>
            </div>
        </div>`);

    overlay.append(card);
    $('body').append(overlay);
    setTimeout(() => $('#twofa-code-input').focus(), 300);

    // Enter-Taste im Input
    card.find('#twofa-code-input').on('keydown', e => {
        if (e.key === 'Enter') card.find('#btn-finish-2fa').trigger('click');
    });

    // Schritt 3: Bestätigen
    card.find('#btn-finish-2fa').on('click', async () => {
        const code = $('#twofa-code-input').val().trim().replace(/\s/g, '');
        const errDiv = card.find('#twofa-error');

        if (!code || code.length !== 6) {
            errDiv.text('Bitte gib den 6-stelligen Code ein.').show();
            return;
        }

        // Client-seitige Vorprüfung mit OTPAuth
        if (window.OTPAuth) {
            try {
                const totp  = new OTPAuth.TOTP({ secret: data.secret, algorithm:'SHA1', digits:6, period:30 });
                const delta = totp.validate({ token: code, window: 1 });
                if (delta === null) {
                    errDiv.text('Code ungültig (App-Prüfung). Bitte erneut versuchen.').show();
                    return;
                }
            } catch(e) {
                console.warn('OTPAuth client check failed:', e);
            }
        }

        const btn = card.find('#btn-finish-2fa').prop('disabled', true).text('Prüfe…');

        try {
            const vRes  = await fetch('admin_settings.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=confirm_2fa_setup&user_id=${userId}&code=${encodeURIComponent(code)}`
            });
            const vData = await vRes.json();
            if (vData.success) {
                overlay.remove();
                customModal({title:'✅ 2FA aktiviert', message:`2FA für <b>${escapeHtml(userName)}</b> wurde erfolgreich eingerichtet.`});
                setTimeout(() => location.reload(), 2000);
            } else {
                errDiv.text(vData.error || 'Ungültiger Code. Bitte erneut versuchen.').show();
                btn.prop('disabled', false).text('✅ Einrichtung abschließen');
            }
        } catch(e) {
            errDiv.text('Netzwerkfehler – bitte erneut versuchen.').show();
            btn.prop('disabled', false).text('✅ Einrichtung abschließen');
        }
    });
}


async function confirmCleanup() {
    const ok = await customModal({
        title: '🧹 Installation bereinigen',
        message: '<b>Achtung:</b> Der <code>/install</code>-Ordner wird unwiderruflich gelöscht.<br>Das Setup kann danach nicht mehr erneut aufgerufen werden.',
        type: 'confirm', confirmText: 'Ja, löschen', cancelText: 'Abbrechen'
    });
    if (ok) document.getElementById('cleanupForm').submit();
}
</script>
    <script src="script.js?v=3"></script>
</body>
</html>
