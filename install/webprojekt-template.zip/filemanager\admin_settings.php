<?php
declare(strict_types=1);
session_start();

// 1. Nur Admins
if (empty($_SESSION['admin_access'])) {
    header('Location: admin_login.php');
    exit;
}

$bootstrapSecurityFile = __DIR__ . '/../config/security.php';
$bootstrapConfigFile = __DIR__ . '/config.php';
if (!file_exists($bootstrapSecurityFile) || !file_exists($bootstrapConfigFile)) {
    header('Location: ../install/setup.php');
    exit;
}

$versionCandidates = [
    __DIR__ . '/version.txt',
    __DIR__ . '/../../version.txt',
    __DIR__ . '/../../install/version.txt'
];
$versionFile = null;
$currentVersionStr = 'unbekannt';
foreach ($versionCandidates as $candidate) {
    if (!is_file($candidate)) {
        continue;
    }
    $versionFile = $candidate;
    $candidateVersion = trim((string) @file_get_contents($candidate));
    if ($candidateVersion !== '') {
        $currentVersionStr = $candidateVersion;
        break;
    }
}
if ($versionFile === null) {
    // Fallback-Ziel, falls beim n?chsten Update noch keine Versionsdatei existiert.
    $versionFile = __DIR__ . '/../../version.txt';
}

if (isset($_GET['check_version'])) {
    header('Content-Type: application/json');
    $remoteVersionUrl = "https://web-service.ubodigat.com/install/version.txt";
    $ch = curl_init($remoteVersionUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 2);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $remoteVersion = curl_exec($ch);
    curl_close($ch);

    $remoteVersion = $remoteVersion ? trim($remoteVersion) : '';

    $updateAvailable = false;
    if ($remoteVersion !== '' && version_compare($remoteVersion, $currentVersionStr, '>')) {
        $updateAvailable = true;
    }

    $changelog = '';
    if ($updateAvailable) {
        $changelogUrl = 'https://web-service.ubodigat.com/install/changelog.txt';
        $ch2 = curl_init($changelogUrl);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_TIMEOUT, 3);
        curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
        $raw = curl_exec($ch2);
        curl_close($ch2);
        if ($raw) {
            $lines = explode("\n", str_replace("\r", '', trim($raw)));
            $out = [];
            $include = false;
            foreach ($lines as $line) {
                if (preg_match('/^v(\d+\.\d+\.\d+)/', $line, $m)) {
                    $include = version_compare($m[1], $currentVersionStr, '>');
                }
                if ($include) {
                    $out[] = rtrim($line);
                }
            }
            $changelog = implode("\n", $out);
        }
    }

    echo json_encode([
        'current'          => $currentVersionStr,
        'remote'           => $remoteVersion,
        'update_available' => $updateAvailable,
        'changelog'        => $changelog
    ]);
    exit;
}

$configFile = $bootstrapConfigFile;
require_once $configFile;
require_once __DIR__ . '/fm_common.php';
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);
$db->set_charset('utf8mb4');
fm_ensure_schema($db);

$securityFile = $bootstrapSecurityFile;
if (isset($_GET['audit_log'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['logs' => fm_fetch_audit_log($db, 2000)], JSON_UNESCAPED_UNICODE);
    exit;
}
require_once $securityFile;

// ── Statusvariablen ───────────────────────────────────────────────────────────
$success = '';
$error = '';

// Nach PRG-Redirect
if (isset($_GET['success']))
    $success = '✅ ' . htmlspecialchars($_GET['success']);
if (isset($_GET['error']))
    $error = '❌ ' . htmlspecialchars($_GET['error']);

// ── DB-Migration: auth_secret Spalte ─────────────────────────────────────────
$res = $db->query("SHOW COLUMNS FROM benutzer LIKE 'auth_secret'");
if ($res && $res->num_rows === 0) {
    $db->query("ALTER TABLE benutzer ADD COLUMN auth_secret VARCHAR(64) NULL DEFAULT NULL");
}
$res = $db->query("SHOW COLUMNS FROM benutzer LIKE 'is_admin'");
if ($res && $res->num_rows === 0) {
    $db->query("ALTER TABLE benutzer ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 1");
}

// ── POST-Verarbeitung ─────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── AJAX: 2FA Secret generieren / abrufen ─────────────────────────────────
    if ($action === 'get_2fa_secret') {
        header('Content-Type: application/json');
        $id = (int) ($_POST['user_id'] ?? 0);
        $stmt = $db->prepare("SELECT nutzername, auth_secret FROM benutzer WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $stmt->bind_result($userName, $authSecret);
        if (!$stmt->fetch()) {
            $stmt->close();
            echo json_encode(['error' => 'Benutzer nicht gefunden']);
            exit;
        }
        $stmt->close();
        $u = ['nutzername' => $userName, 'auth_secret' => $authSecret];

        // Neues Secret generieren und temporär in Session speichern
        $secret = generate2FASecret();
        if (!isset($_SESSION['pending_2fa']))
            $_SESSION['pending_2fa'] = [];
        $_SESSION['pending_2fa'][$id] = $secret;

        $label = urlencode($u['nutzername']);
        $issuer = urlencode('web-service');
        $uri = "otpauth://totp/{$issuer}:{$label}?secret={$secret}&issuer={$issuer}&algorithm=SHA1&digits=6&period=30";

        echo json_encode(['secret' => $secret, 'uri' => $uri, 'username' => $u['nutzername'], 'has2fa' => !empty($u['auth_secret'])]);
        exit;
    }

    // ── AJAX: 2FA Setup bestätigen ────────────────────────────────────────────
    if ($action === 'confirm_2fa_setup') {
        header('Content-Type: application/json');
        $id = (int) ($_POST['user_id'] ?? 0);
        $code = trim($_POST['code'] ?? '');

        $secret = $_SESSION['pending_2fa'][$id] ?? null;
        if (!$secret) {
            echo json_encode(['error' => 'Session abgelaufen. Bitte neu versuchen.']);
            exit;
        }

        if (!verifyTOTP($secret, $code)) {
            echo json_encode(['error' => 'Ungültiger Code – bitte erneut versuchen.']);
            exit;
        }

        $stmt = $db->prepare("UPDATE benutzer SET auth_secret = ? WHERE id = ?");
        $stmt->bind_param('si', $secret, $id);
        if ($stmt->execute()) {
            unset($_SESSION['pending_2fa'][$id]);
            fm_log_action($db, 'confirm_2fa_setup', 'user:' . $id, '2FA eingerichtet (Admin)');
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Datenbankfehler: ' . $db->error]);
        }
        exit;
    }

    // AJAX: 2FA deaktivieren
    if ($action === 'disable_2fa') {
        $id = (int) ($_POST['user_id'] ?? 0);
        if ($db->query("UPDATE benutzer SET auth_secret = NULL WHERE id = " . $id)) {
            $success = '✅ 2FA wurde deaktiviert.';
            fm_log_action($db, 'disable_2fa', 'user:' . $id, '2FA deaktiviert');
        } else {
            $error = '❌ Fehler beim Deaktivieren.';
        }
    }

    // Benutzer anlegen
    if ($action === 'add_user') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $isAdminFlag = !empty($_POST['is_admin']) ? 1 : 0;
        if ($user && $pass) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO benutzer (nutzername, passwort, is_admin) VALUES (?, ?, ?)");
            $stmt->bind_param('ssi', $user, $hash, $isAdminFlag);
            if ($stmt->execute()) {
                $success = ($isAdminFlag ? "? Administrator '" : "? Benutzer '") . $user . "' wurde angelegt.";
                fm_log_action($db, 'add_user', 'user:' . $user, ($isAdminFlag ? 'Administrator' : 'Benutzer') . ' angelegt');
            } else {
                $error = '? Fehler: ' . $db->error;
            }
        } else {
            $error = '? Benutzername und Passwort erforderlich.';
        }
    }

    // Benutzer bearbeiten
    if ($action === 'edit_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $newName = trim($_POST['username'] ?? '');
        $newPass = $_POST['password'] ?? '';
        $isAdminFlag = !empty($_POST['is_admin']) ? 1 : 0;

        if ($newName) {
            if ($newPass) {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ?, passwort = ?, is_admin = ? WHERE id = ?");
                $stmt->bind_param('ssii', $newName, $hash, $isAdminFlag, $id);
            } else {
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ?, is_admin = ? WHERE id = ?");
                $stmt->bind_param('sii', $newName, $isAdminFlag, $id);
            }
            if ($stmt->execute()) {
                $success = '? Benutzer aktualisiert.';
                fm_log_action($db, 'edit_user', 'user:' . $id, 'Benutzer aktualisiert');
            } else {
                $error = '? Fehler: ' . $db->error;
            }
        } else {
            $error = '? Benutzername darf nicht leer sein.';
        }
    }

    // Benutzer l?schen
    if ($action === 'delete_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $db->query("DELETE FROM benutzer WHERE id = " . $id);
        $success = '? Benutzer gelöscht.';
        fm_log_action($db, 'delete_user', 'user:' . $id, 'Benutzer gelöscht');
    }

    // ── Hintergrundbild ───────────────────────────────────────────────────────
    if ($action === 'update_bg') {
        $type = $_POST['bg_type'] ?? 'web';
        $const = ($type === 'web') ? 'WEB_LOGIN_BG' : 'FILEMANAGER_LOGIN_BG';

        if (isset($_FILES['bg_file'])) {
            $errCode = $_FILES['bg_file']['error'];
            if ($errCode === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['bg_file']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
                if (!in_array($ext, $allowed, true)) {
                    $error = '❌ Nur Bilder erlaubt (jpg, png, webp, gif).';
                } else {
                    $name = 'bg_' . bin2hex(random_bytes(8)) . '.' . $ext;
                    $target = __DIR__ . '/../uploads/' . $name;
                    if (!is_dir(__DIR__ . '/../uploads'))
                        mkdir(__DIR__ . '/../uploads', 0755, true);

                    if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $target)) {
                        $path = '/uploads/' . $name;
                        $content = file_get_contents($securityFile);
                        // Flexibleres Regex für Single oder Double Quotes
                        $content = preg_replace("/define\('$const', (['\"]).*?\\1\);/", "define('$const', '$path');", $content);
                        if (function_exists('opcache_invalidate'))
                            opcache_invalidate($securityFile, true);
                        file_put_contents($securityFile, $content);
                        fm_log_action($db, 'update_bg', $type, 'Hintergrundbild aktualisiert (' . $type . ')');
                        header('Location: admin_settings.php?success=' . urlencode('Hintergrundbild aktualisiert.'));
                        exit;
                    } else {
                        $error = '❌ Fehler beim Speichern der Datei auf dem Server.';
                    }
                }
            } else {
                $uploadErrors = [
                    UPLOAD_ERR_INI_SIZE   => 'Die Datei überschreitet die in php.ini erlaubte Maximalgröße (upload_max_filesize).',
                    UPLOAD_ERR_FORM_SIZE  => 'Die Datei überschreitet die im Formular erlaubte Maximalgröße.',
                    UPLOAD_ERR_PARTIAL    => 'Die Datei wurde nur teilweise hochgeladen.',
                    UPLOAD_ERR_NO_FILE    => 'Keine Datei ausgewählt.',
                    UPLOAD_ERR_NO_TMP_DIR => 'Fehlender temporärer Ordner auf dem Server.',
                    UPLOAD_ERR_CANT_WRITE => 'Schreibfehler auf dem Server.',
                    UPLOAD_ERR_EXTENSION  => 'Eine PHP-Erweiterung hat den Upload gestoppt.'
                ];
                $error = '❌ ' . ($uploadErrors[$errCode] ?? 'Unbekannter Upload-Fehler (Code ' . $errCode . ').');
            }
        } else {
            $error = '❌ Keine Datei empfangen.';
        }
    }

    // ── Globale ACL ───────────────────────────────────────────────────────────
    if ($action === 'update_acl') {
        $can_del = isset($_POST['can_delete']) ? 'true' : 'false';
        $can_ren = isset($_POST['can_rename']) ? 'true' : 'false';
        $can_up = isset($_POST['can_upload']) ? 'true' : 'false';
        $can_cre = isset($_POST['can_create']) ? 'true' : 'false';
        $can_edi = isset($_POST['can_edit']) ? 'true' : 'false';

        $content = file_get_contents($securityFile);
        $content = preg_replace("/define\('USER_CAN_DELETE', .*?\);/", "define('USER_CAN_DELETE', $can_del);", $content);
        $content = preg_replace("/define\('USER_CAN_RENAME', .*?\);/", "define('USER_CAN_RENAME', $can_ren);", $content);
        $content = preg_replace("/define\('USER_CAN_UPLOAD', .*?\);/", "define('USER_CAN_UPLOAD', $can_up);", $content);
        $content = preg_replace("/define\('USER_CAN_CREATE', .*?\);/", "define('USER_CAN_CREATE', $can_cre);", $content);
        if (strpos($content, "'USER_CAN_EDIT'") !== false) {
            $content = preg_replace("/define\('USER_CAN_EDIT', .*?\);/", "define('USER_CAN_EDIT', $can_edi);", $content);
        } else {
            $content .= "\ndefine('USER_CAN_EDIT', $can_edi);\n";
        }

        if (function_exists('opcache_invalidate'))
            opcache_invalidate($securityFile, true);
        if (file_put_contents($securityFile, $content)) {
            fm_log_action($db, 'update_acl', '', 'Globale Berechtigungen geändert');
            header('Location: admin_settings.php?success=' . urlencode('Globale Berechtigungen gespeichert.'));
            exit;
        } else {
            $error = '❌ Fehler beim Speichern.';
        }
    }

    // ── Ordnerspezifische ACL ─────────────────────────────────────────────────
    if ($action === 'update_folder_acl') {
        $path = trim($_POST['folder_path'] ?? '');
        $path = str_replace('\\', '/', $path);
        $path = trim($path, '/');

        if ($path !== '') {
            $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
            if (isset($folderPerms[$path]))
                unset($folderPerms[$path]);

            $folderPerms[$path] = [
                'delete' => isset($_POST['can_delete']),
                'rename' => isset($_POST['can_rename']),
                'upload' => isset($_POST['can_upload']),
                'create' => isset($_POST['can_create']),
                'edit' => isset($_POST['can_edit']),
                'is_private' => isset($_POST['is_private']),
            ];

            $json = json_encode($folderPerms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'FOLDER_PERMISSIONS'") !== false) {
                $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/s", "define('FOLDER_PERMISSIONS', '$json');", $content);
            } else {
                $content .= "\ndefine('FOLDER_PERMISSIONS', '$json');\n";
            }
            if (function_exists('opcache_invalidate'))
                opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            fm_log_action($db, 'update_folder_acl', $path, 'Ordner-Regel gesetzt');
            header('Location: admin_settings.php?success=' . urlencode('Ordner-Regel gespeichert.'));
            exit;
        } else {
            $error = '❌ Bitte Ordnerpfad angeben.';
        }
    }

    // ── Ordner-ACL löschen ────────────────────────────────────────────────────
    if ($action === 'delete_folder_acl') {
        $path = $_POST['folder_path'] ?? '';
        $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
        if (isset($folderPerms[$path])) {
            unset($folderPerms[$path]);
            $json = json_encode($folderPerms, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'FOLDER_PERMISSIONS'") !== false) {
                $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/s", "define('FOLDER_PERMISSIONS', '$json');", $content);
            } else {
                $content .= "\ndefine('FOLDER_PERMISSIONS', '$json');\n";
            }
            if (function_exists('opcache_invalidate'))
                opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            fm_log_action($db, 'delete_folder_acl', $path, 'Ordner-Regel gelöscht');
            header('Location: admin_settings.php?success=' . urlencode('Ordner-Regel entfernt.'));
            exit;
        }
    }

    // ── Benutzerspezifische Berechtigung speichern ────────────────────────────
    if ($action === 'update_user_perm') {
        $targetUser   = trim($_POST['target_user'] ?? '');
        $targetFolder = trim(str_replace('\\', '/', $_POST['up_folder'] ?? ''), '/');
        $permKey      = $targetUser !== '' ? ($targetFolder !== '' ? $targetUser . '::' . $targetFolder : $targetUser) : '';
        if ($permKey !== '') {
            $uPermsNow = defined('USER_PERMISSIONS') ? (json_decode(USER_PERMISSIONS, true) ?? []) : [];
            $uPermsNow[$permKey] = [
                'delete' => !empty($_POST['up_delete']),
                'rename' => !empty($_POST['up_rename']),
                'upload' => !empty($_POST['up_upload']),
                'create' => !empty($_POST['up_create']),
                'edit'   => !empty($_POST['up_edit']),
            ];
            $json    = json_encode($uPermsNow, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $safeJson = str_replace("'", "\\'", $json);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'USER_PERMISSIONS'") !== false) {
                $content = preg_replace("/define\('USER_PERMISSIONS', '.*?'\);/s", "define('USER_PERMISSIONS', '" . $safeJson . "');", $content);
            } else {
                $content .= "\ndefine('USER_PERMISSIONS', '" . $safeJson . "');\n";
            }
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            fm_log_action($db, 'update_user_perm', $permKey, 'Benutzer-Rechte gesetzt');
            header('Location: admin_settings.php?success=' . urlencode('Benutzer-Berechtigungen gespeichert.'));
            exit;
        }
    }

    // ── Benutzerspezifische Berechtigung löschen ──────────────────────────────
    if ($action === 'delete_user_perm') {
        $permKey   = trim($_POST['perm_key'] ?? '');
        $uPermsNow = defined('USER_PERMISSIONS') ? (json_decode(USER_PERMISSIONS, true) ?? []) : [];
        if ($permKey !== '' && isset($uPermsNow[$permKey])) {
            unset($uPermsNow[$permKey]);
            $json     = json_encode($uPermsNow, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $safeJson = str_replace("'", "\\'", $json);
            $content  = file_get_contents($securityFile);
            $content  = preg_replace("/define\('USER_PERMISSIONS', '.*?'\);/s", "define('USER_PERMISSIONS', '" . $safeJson . "');", $content);
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            fm_log_action($db, 'delete_user_perm', $permKey, 'Benutzer-Regel gelöscht');
            header('Location: admin_settings.php?success=' . urlencode('Benutzer-Regel entfernt.'));
            exit;
        }
    }

    // ── PHP-Update Check (simuliert) ──────────────────────────────────────────
    if ($action === 'php_update') {
        $success = '✅ System-Check: PHP ' . phpversion() . ' ist aktuell.';
    }

    // ── Dateimanager-Update ───────────────────────────────────────────────────
    if ($action === 'update_dateimanager') {
        $zipUrl = "https://web-service.ubodigat.com/install/webprojekt-template.zip";
        $tmpZip = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'webprojekt-template_update.zip';

        // 1. Download updated ZIP archive via cURL
        $ch = curl_init($zipUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $zipData = curl_exec($ch);
        curl_close($ch);

        if ($zipData === false || strlen($zipData) < 1000) {
            $error = '❌ Download-Fehler: Die Update-Datei konnte nicht heruntergeladen werden.';
        } else {
            if (file_put_contents($tmpZip, $zipData)) {
                // 2. Extract with ZipArchive
                $zip = new ZipArchive();
                if ($zip->open($tmpZip) === true) {
                    $basePath = realpath(__DIR__ . '/..');
                    $extractedCount = 0;
                    
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $originalName = $zip->getNameIndex($i);
                        // Normalize backslashes (Windows) to forward slashes (Linux) for safe paths
                        $filename = str_replace('\\', '/', $originalName);
                        if (strpos($filename, 'webprojekt-template/') === 0) {
                            $filename = substr($filename, strlen('webprojekt-template/'));
                        }
                        if ($filename === '') {
                            continue;
                        }
                        
                        // Skip system configuration, installer status, and uploads files to preserve user settings
                        if (
                            strpos($filename, 'config/security.php') !== false ||
                            strpos($filename, 'filemanager/config.php') !== false ||
                            strpos($filename, 'install/.installed') !== false ||
                            strpos($filename, 'uploads/') === 0
                        ) {
                            continue;
                        }

                        // Determine destination path
                        $destPath = $basePath . '/' . $filename;
                        
                        // Ensure directory exists
                        if (substr($filename, -1) === '/') {
                            if (!is_dir($destPath)) {
                                mkdir($destPath, 0755, true);
                            }
                        } else {
                            $dir = dirname($destPath);
                            if (!is_dir($dir)) {
                                mkdir($dir, 0755, true);
                            }
                            
                            // Copy file content
                            $fp = $zip->getStream($originalName); // Open stream using original name in ZIP index
                            if ($fp) {
                                file_put_contents($destPath, stream_get_contents($fp));
                                fclose($fp);
                                $extractedCount++;
                            }
                        }
                    }
                    $zip->close();
                    @unlink($tmpZip);
                    
                    // Invalidate opcache if active
                    if (function_exists('opcache_reset')) {
                        opcache_reset();
                    }

                    // Update local version.txt
                    $remoteVersionUrl = "https://web-service.ubodigat.com/install/version.txt";
                    $chVersion = curl_init($remoteVersionUrl);
                    curl_setopt($chVersion, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($chVersion, CURLOPT_SSL_VERIFYPEER, false);
                    $newVersion = curl_exec($chVersion);
                    curl_close($chVersion);
                    if ($newVersion) {
                        file_put_contents($versionFile, trim($newVersion));
                    }

                    fm_log_action($db, 'update_dateimanager', '', 'Dateimanager aktualisiert (' . $extractedCount . ' Dateien)');
                    $success = '✅ Dateimanager erfolgreich aktualisiert! ' . $extractedCount . ' Dateien wurden aktualisiert.';
                } else {
                    $error = '❌ Archiv-Fehler: Das Update-Archiv konnte nicht geöffnet werden.';
                }
            } else {
                $error = '❌ System-Fehler: Das Update-Archiv konnte nicht temporär gespeichert werden.';
            }
        }
    }

    // ── Installation bereinigen ───────────────────────────────────────────────
    if ($action === 'cleanup_install') {
        $installDir = __DIR__ . '/../install/';
        if (is_dir($installDir)) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($installDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($files as $fileinfo) {
                ($fileinfo->isDir() ? 'rmdir' : 'unlink')($fileinfo->getRealPath());
            }
            rmdir($installDir);
            fm_log_action($db, 'cleanup_install', '', 'Installationsdateien gelöscht');
            $success = '✅ Installationsdateien gelöscht.';
        } else {
            $error = '❌ Installationsordner nicht gefunden.';
        }
    }
}

// ── Daten für die Anzeige ─────────────────────────────────────────────────────
$users = $db->query("SELECT id, nutzername, auth_secret, is_admin FROM benutzer ORDER BY id");

function getFolderList(string $dir, string $base, array &$folders = []): array
{
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..')
            continue;
        $full = $dir . DIRECTORY_SEPARATOR . $f;
        if (is_dir($full)) {
            $rel = trim(str_replace([$base, DIRECTORY_SEPARATOR], ['', '/'], $full), '/');
            if (!in_array($rel, ['config', 'install', 'sql', 'filemanager', '.git', '.trash'], true)) {
                $folders[] = $rel;
                getFolderList($full, $base, $folders);
            }
        }
    }
    return $folders;
}
$basePath = (string) realpath(__DIR__ . '/..');
$availableFolders = getFolderList($basePath, $basePath);
sort($availableFolders);

$fPerms  = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
$uPerms  = defined('USER_PERMISSIONS')   ? (json_decode(USER_PERMISSIONS,   true) ?? []) : [];
$allUsersRes = $db->query("SELECT id, nutzername FROM benutzer ORDER BY nutzername");
$allUsers = [];
while ($row = $allUsersRes->fetch_assoc()) {
    $allUsers[] = $row;
}
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>⚙️ Admin-Einstellungen</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css?v=216">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/otpauth@9.3.5/dist/otpauth.umd.js"></script>
    <style>
        body {
            display: flex;
            justify-content: center;
            padding: 20px;
            min-height: 100vh;
            margin: 0;
            box-sizing: border-box;
        }

        .box {
            width: 100%;
            max-width: 900px;
            background: var(--bg-card);
            padding: 30px;
            border-radius: 16px;
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-sizing: border-box;
        }

        .section {
            margin-bottom: 30px;
            padding: 25px;
            border-radius: 12px;
            position: relative;
        }

        body.dark-mode .section {
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        body:not(.dark-mode) .section {
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.1);
        }

        input,
        select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            box-sizing: border-box;
            border: 1px solid;
        }

        body.dark-mode input,
        body.dark-mode select {
            background: rgba(0, 0, 0, 0.5);
            color: white;
            border-color: #333;
        }

        body:not(.dark-mode) input,
        body:not(.dark-mode) select {
            background: #fff;
            color: #333;
            border-color: #ccc;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary) !important;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }

        .section-header:hover h2, .section-header:hover h3 {
            color: var(--primary);
        }

        .user-list td {
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        body:not(.dark-mode) .user-list td {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .user-list th {
            padding: 10px 12px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            color: #94a3b8;
            background: rgba(255, 255, 255, 0.04);
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        body:not(.dark-mode) .user-list th {
            color: #475569;
            background: #f1f5f9;
            border-bottom: 2px solid #e2e8f0;
        }

        .nav-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .alert {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 14px 28px;
            border-radius: 12px;
            z-index: 10000;
            font-weight: 600;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
            pointer-events: auto;
            transition: opacity 0.5s;
            white-space: nowrap;
        }

        .alert-success {
            background: #059669;
            color: white;
        }

        .alert-danger,
        .alert-error {
            background: #dc2626;
            color: white;
        }

        /* ── Einklappbare Sektionen ──────────────────────────────────────────────── */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            user-select: none;
            margin-bottom: 0;
            padding-bottom: 15px;
        }
        .section-header:hover { opacity: 0.9; }
        .section-header h2, .section-header h3 { margin: 0; }
        .section-toggle {
            font-size: 20px;
            line-height: 1;
            color: #94a3b8;
            transition: transform 0.2s ease;
            flex-shrink: 0;
            margin-left: 10px;
        }
        .section.collapsed .section-toggle { transform: rotate(-90deg); }
        .section.collapsed .section-body { display: none; }
        .section-body { padding-top: 5px; }

        /* ── Protokoll-Overlay Light Mode ────────────────────────────────────────── */
        #auditLogOverlay > div {
            background: #1e293b;
            color: #f1f5f9;
            border: 1px solid rgba(255,255,255,0.1);
        }
        body:not(.dark-mode) #auditLogOverlay > div {
            background: #f8fafc !important;
            color: #1e293b !important;
            border: 1px solid #e2e8f0 !important;
        }
        body:not(.dark-mode) #auditLogOverlay [style*="border-bottom:1px solid rgba(255,255,255"] {
            border-bottom-color: #e2e8f0 !important;
        }
        body:not(.dark-mode) #auditSearch {
            background: #fff !important;
            color: #1e293b !important;
            border-color: #cbd5e1 !important;
        }
        body:not(.dark-mode) #auditCat {
            background: #fff !important;
            color: #1e293b !important;
            border-color: #cbd5e1 !important;
        }
        body:not(.dark-mode) #auditCount { color: #94a3b8; }
        body:not(.dark-mode) #auditTable { color: #1e293b; }
        body:not(.dark-mode) #auditThead th { color: #475569 !important; background: #f1f5f9; border-bottom: 2px solid #e2e8f0; }
        body:not(.dark-mode) #auditTbody tr { border-bottom-color: #e2e8f0 !important; }
        body:not(.dark-mode) #auditTbody td { color: #1e293b !important; }
        body:not(.dark-mode) #auditTbody td:first-child { color: #64748b !important; }
        body:not(.dark-mode) #auditTbody tr[style*="rgba(239,68,68"] { background: rgba(239,68,68,0.06) !important; }
        body:not(.dark-mode) #auditTbody td:last-child span { background: rgba(0,0,0,0.06) !important; color: #475569 !important; }

        /* ── Protokoll Spalten (resizable) ───────────────────────────────────────── */
        #auditThead th {
            position: relative;
            resize: horizontal;
            overflow: hidden;
            min-width: 60px;
        }
        #auditThead th:hover { background: rgba(255,255,255,0.04); }
        body:not(.dark-mode) #auditThead th:hover { background: #e8edf5; }
        .audit-arrow { font-size: 12px; margin-left: 4px; }
    </style>
</head>

<body class="dark-mode">
    <div class="box">

        <div class="nav-header">
            <div style="display:flex; align-items:center; gap:15px;">
                <a href="file_manager.php" class="btn btn-secondary" style="width:auto;">⬅ Zurück</a>
                <div style="font-size:12px; opacity:0.7;">👤 Admin:
                    <b><?= htmlspecialchars($_SESSION['admin_user'] ?? 'Unbekannt') ?></b></div>
            </div>
            <button onclick="toggleDarkMode()" class="btn btn-secondary" id="themeToggle" style="width:auto;">🌗
                Tag/Nacht</button>
        </div>

        <h1>⚙️ Admin-Einstellungen</h1>

        <?php if ($success): ?>
            <div class="alert alert-success" id="statusMsg"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger" id="statusMsg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- -- Benutzerverwaltung --------------------------------------------------- -->
        <div class="section collapsed" id="sec-users">
            <div class="section-header" onclick="toggleSection('sec-users')">
                <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; flex:1;">
                    <h2 style="margin:0;">👥 Benutzerverwaltung</h2>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;" onclick="event.stopPropagation()">
                        <button onclick="showAuditLog()" class="btn btn-secondary" style="width:auto;">📋 Protokoll</button>
                        <button onclick="showAddUser()" class="btn btn-success" style="width:auto;">➕ Neu</button>
                    </div>
                </div>
                <span class="section-toggle">▾</span>
            </div>
            <div class="section-body">
            <table class="user-list" style="width:100%;">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Rolle</th>
                        <th>2FA</th>
                        <th style="text-align:right;">Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($u = $users->fetch_assoc()):
                        $has2fa = !empty($u['auth_secret']);
                        $uid = (int) $u['id'];
                        $isAdminUser = !isset($u['is_admin']) || (int) $u['is_admin'] === 1;
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($u['nutzername']) ?></td>
                            <td><?= $isAdminUser ? '<span style="color:var(--primary);">👑 Admin</span>' : '<span style="color:#10b981;">👤 Benutzer</span>' ?></td>
                            <td><?= $has2fa ? '<span style="color:#10b981;">✅ Aktiv</span>' : '<span style="opacity:0.5;">—</span>' ?></td>
                            <td style="text-align:right; white-space:nowrap;">
                                <button onclick='showEditUser(<?= $uid ?>, <?= json_encode($u["nutzername"]) ?>, <?= $has2fa ? "true" : "false" ?>, <?= $isAdminUser ? "true" : "false" ?>)'
                                    class="btn btn-primary btn-small" style="width:auto;">✏️ Bearbeiten</button>
                                <button onclick='deleteUser(<?= $uid ?>, <?= json_encode($u["nutzername"]) ?>)'
                                    class="btn btn-danger btn-small" style="width:auto; margin-left:6px;">🗑️</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            </div><!-- /section-body -->
        </div>

        <!-- ── Globale ACL ──────────────────────────────────────────────────────── -->
        <div class="section collapsed" id="sec-acl">
            <div class="section-header" onclick="toggleSection('sec-acl')">
                <h2>🔐 Berechtigungen für Normalnutzer</h2>
                <span class="section-toggle">▾</span>
            </div>
            <div class="section-body">
            <form method="post"
                style="border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:20px; margin-bottom:20px;">
                <input type="hidden" name="action" value="update_acl">
                <h3>Globale Standardwerte</h3>
                <p style="font-size:12px; color:#94a3b8; margin-bottom:15px;">Diese Regeln gelten, sofern keine
                    ordnerspezifische Regel existiert.</p>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                    <div class="perm-item"><label><input type="checkbox" name="can_delete" <?= defined('USER_CAN_DELETE') && USER_CAN_DELETE ? 'checked' : '' ?>> 🗑️ Löschen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="can_rename" <?= defined('USER_CAN_RENAME') && USER_CAN_RENAME ? 'checked' : '' ?>> 📄 Umbenennen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="can_upload" <?= defined('USER_CAN_UPLOAD') && USER_CAN_UPLOAD ? 'checked' : '' ?>> 📤 Upload</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="can_create" <?= defined('USER_CAN_CREATE') && USER_CAN_CREATE ? 'checked' : '' ?>> ➕ Erstellen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="can_edit" <?= (!defined('USER_CAN_EDIT') || USER_CAN_EDIT) ? 'checked' : '' ?>> ✏️ Bearbeiten</label></div>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top:15px; width:auto;">Globale Rechte
                    speichern</button>
            </form>

            <h3>📁 Ordnerspezifische Regeln</h3>
            <p style="font-size:12px; color:#94a3b8; margin-bottom:15px;">Hier kannst du exakte Berechtigungen für
                einzelne Verzeichnisse festlegen.</p>

            <form method="post"
                style="margin-bottom:25px; background:rgba(255,255,255,0.03); padding:20px; border-radius:12px; border:1px solid rgba(255,255,255,0.05);">
                <input type="hidden" name="action" value="update_folder_acl">

                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:8px;">Ordner auswählen
                        oder Pfad eingeben</label>
                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <select onchange="this.nextElementSibling.value=this.value"
                            style="width:200px; margin-bottom:0; flex-shrink:0;">
                            <option value="">-- Ordner wählen --</option>
                            <?php foreach ($availableFolders as $fold): ?>
                                <option value="<?= htmlspecialchars($fold) ?>"><?= htmlspecialchars($fold) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="folder_path" placeholder="Pfad (z.B. projekte/kunden)" required
                            style="flex:1; min-width:150px;">
                    </div>
                </div>

                <div
                    style="display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap:15px; margin-bottom:20px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="is_private"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">🔒 Privat</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="can_upload"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">📤 Upload</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="can_create"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">➕ Erstellen</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="can_edit"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">✏️ Bearbeiten</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="can_rename"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">📄 Umbenennen</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <label class="switch"><input type="checkbox" name="can_delete"><span
                                class="slider"></span></label>
                        <span style="font-size:13px;">🗑️ Löschen</span>
                    </div>
                </div>

                <button type="submit" class="btn btn-success" style="width:auto; padding:10px 20px;">Regel
                    speichern</button>
            </form>

            <div class="rules-list">
                <?php if (empty($fPerms)): ?>
                    <div
                        style="text-align:center; opacity:0.5; padding:30px; background:rgba(255,255,255,0.02); border-radius:12px;">
                        Keine spezifischen Regeln definiert.</div>
                <?php else: ?>
                    <?php foreach ($fPerms as $p => $r): ?>
                        <div class="rule-card">
                            <div class="rule-info">
                                <span class="rule-path"><?= htmlspecialchars($p) ?></span>
                                <div class="rule-perms">
                                    <span class="perm-badge <?= !empty($r['is_private']) ? 'active' : '' ?>">🔒 Privat</span>
                                    <span class="perm-badge <?= !empty($r['upload']) ? 'active' : '' ?>">📤 Upload</span>
                                    <span class="perm-badge <?= !empty($r['create']) ? 'active' : '' ?>">➕ Erstellen</span>
                                    <span class="perm-badge <?= !empty($r['edit']) ? 'active' : '' ?>">✏️ Bearbeiten</span>
                                    <span class="perm-badge <?= !empty($r['rename']) ? 'active' : '' ?>">📄 Umbenennen</span>
                                    <span class="perm-badge <?= !empty($r['delete']) ? 'active' : '' ?>">🗑️ Löschen</span>
                                </div>
                            </div>
                            <div class="rule-actions">
                                <button type="button" class="btn btn-warning btn-small" title="Regel bearbeiten"
                                    onclick='editRule(<?= json_encode($p) ?>, <?= json_encode($r) ?>)'>✏️</button>
                                <button type="button" class="btn btn-danger btn-small" title="Regel löschen"
                                    onclick='deleteRule(<?= json_encode($p) ?>)'>🗑️</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            </div><!-- /section-body -->
        </div>

        <!-- ── Benutzerspezifische Regeln ──────────────────────────────────────── -->
        <div class="section collapsed" id="sec-userperms">
            <div class="section-header" onclick="toggleSection('sec-userperms')">
                <h2>👤 Benutzerspezifische Berechtigungen</h2>
                <span class="section-toggle">▾</span>
            </div>
            <div class="section-body">
            <p style="font-size:12px; color:#94a3b8; margin-bottom:20px;">
                Hier kannst du für einzelne Benutzer abweichende Rechte festlegen. Diese überschreiben die globalen
                Standardwerte, werden aber von ordnerspezifischen Regeln weiter überschrieben.
            </p>
            <form method="post" style="background:rgba(255,255,255,0.03); padding:20px; border-radius:12px; border:1px solid rgba(255,255,255,0.05); margin-bottom:20px;">
                <input type="hidden" name="action" value="update_user_perm">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
                    <div>
                        <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:6px;">Benutzer</label>
                        <select name="target_user" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.3); color:white; border:1px solid rgba(255,255,255,0.1);">
                            <option value="">— Benutzer wählen —</option>
                            <?php foreach ($allUsers as $u): ?>
                                <option value="<?= htmlspecialchars($u['nutzername']) ?>"><?= htmlspecialchars($u['nutzername']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:6px;">Ordner <span style="opacity:0.5;">(leer = global)</span></label>
                        <select name="up_folder" onchange="this.nextElementSibling.value=this.value" style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.3); color:white; border:1px solid rgba(255,255,255,0.1); margin-bottom:6px;">
                            <option value="">— Alle Ordner (global) —</option>
                            <?php foreach ($availableFolders as $fold): ?>
                                <option value="<?= htmlspecialchars($fold) ?>"><?= htmlspecialchars($fold) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="up_folder" placeholder="oder Pfad eingeben…" style="width:100%; padding:8px 10px; border-radius:8px; background:rgba(0,0,0,0.3); color:white; border:1px solid rgba(255,255,255,0.1); box-sizing:border-box; font-size:13px;">
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:15px;">
                    <div class="perm-item"><label><input type="checkbox" name="up_delete"> 🗑️ Löschen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="up_rename" checked> 📄 Umbenennen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="up_upload" checked> 📤 Upload</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="up_create" checked> ➕ Erstellen</label></div>
                    <div class="perm-item"><label><input type="checkbox" name="up_edit" checked> ✏️ Bearbeiten</label></div>
                </div>
                <button type="submit" class="btn btn-primary" style="width:auto;">Regel speichern</button>
            </form>

            <div class="rules-list">
                <?php if (empty($uPerms)): ?>
                    <div style="text-align:center; opacity:0.5; padding:30px; background:rgba(255,255,255,0.02); border-radius:12px;">
                        Keine benutzerspezifischen Regeln definiert.</div>
                <?php else: ?>
                    <?php foreach ($uPerms as $permKey => $r): ?>
                        <?php
                            // Compound key: user::folder or just username
                            if (strpos($permKey, '::') !== false) {
                                [$dispUser, $dispFolder] = explode('::', $permKey, 2);
                            } else {
                                $dispUser = $permKey;
                                $dispFolder = '';
                            }
                        ?>
                        <div class="rule-card">
                            <div class="rule-info">
                                <span class="rule-path">
                                    👤 <?= htmlspecialchars($dispUser) ?>
                                    <?php if ($dispFolder !== ''): ?>
                                        <span style="opacity:0.5; font-size:12px; margin-left:6px;">→ 📁 <?= htmlspecialchars($dispFolder) ?></span>
                                    <?php else: ?>
                                        <span style="opacity:0.5; font-size:12px; margin-left:6px;">(global)</span>
                                    <?php endif; ?>
                                </span>
                                <div class="rule-perms">
                                    <span class="perm-badge <?= !empty($r['upload']) ? 'active' : '' ?>">📤 Upload</span>
                                    <span class="perm-badge <?= !empty($r['create']) ? 'active' : '' ?>">➕ Erstellen</span>
                                    <span class="perm-badge <?= !empty($r['edit'])   ? 'active' : '' ?>">✏️ Bearbeiten</span>
                                    <span class="perm-badge <?= !empty($r['rename']) ? 'active' : '' ?>">📄 Umbenennen</span>
                                    <span class="perm-badge <?= !empty($r['delete']) ? 'active' : '' ?>">🗑️ Löschen</span>
                                </div>
                            </div>
                            <div class="rule-actions">
                                <button type="button" class="btn btn-warning btn-small" title="Regel bearbeiten"
                                    onclick='prefillUserPermForm(
                                        <?= json_encode($dispUser) ?>,
                                        <?= json_encode($dispFolder) ?>,
                                        <?= json_encode(['upload'=>!empty($r['upload']),'create'=>!empty($r['create']),'edit'=>!empty($r['edit']),'rename'=>!empty($r['rename']),'delete'=>!empty($r['delete'])]) ?>
                                    )'>✏️</button>
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="action" value="delete_user_perm">
                                    <input type="hidden" name="perm_key" value="<?= htmlspecialchars($permKey) ?>">
                                    <button type="submit" class="btn btn-danger btn-small" title="Regel löschen">🗑️</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            </div><!-- /section-body -->
        </div>

        <!-- ── Hintergrundbilder ────────────────────────────────────────────────── -->
        <div class="section collapsed" id="sec-design">
            <div class="section-header" onclick="toggleSection('sec-design')">
                <h2>🖼️ Design & Hintergründe</h2>
                <span class="section-toggle">▾</span>
            </div>
            <div class="section-body">
            <?php
                $bgWebCurrent = defined('WEB_LOGIN_BG')        ? WEB_LOGIN_BG        : '';
                $bgFmCurrent  = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
            ?>
            <div class="bg-cards-grid">

                <!-- Web-Login Background -->
                <form method="post" enctype="multipart/form-data" class="bg-upload-form">
                    <input type="hidden" name="action"  value="update_bg">
                    <input type="hidden" name="bg_type" value="web">
                    <div class="bg-card">
                        <p class="bg-card-title">🌐 Web-Login</p>
                        <div class="bg-dropzone<?= $bgWebCurrent ? ' has-preview' : '' ?>" id="bg-drop-web"
                             onclick="this.querySelector('.bg-file-input').click()">
                            <?php if ($bgWebCurrent): ?>
                                <img class="bg-img-preview" src="<?= htmlspecialchars($bgWebCurrent) ?>" alt="">
                            <?php else: ?>
                                <img class="bg-img-preview" src="" alt="" style="display:none;">
                            <?php endif; ?>
                            <div class="bg-dz-overlay">
                                <span class="bg-dz-icon">🖼️</span>
                                <span class="bg-dz-label"><?= $bgWebCurrent ? 'Bild austauschen' : 'Bild auswählen oder ablegen' ?></span>
                                <span class="bg-dz-hint">JPG · PNG · WEBP · GIF</span>
                            </div>
                            <input class="bg-file-input" type="file" name="bg_file" accept="image/*"
                                   onchange="bgPickerChange(this, 'bg-drop-web', 'bg-name-web')">
                        </div>
                        <span class="bg-filename" id="bg-name-web">
                            <?= $bgWebCurrent ? htmlspecialchars(basename($bgWebCurrent)) : 'Kein Bild gesetzt' ?>
                        </span>
                        <button type="submit" class="btn btn-success" style="width:100%;">💾 Hochladen</button>
                    </div>
                </form>

                <!-- FM-Login Background -->
                <form method="post" enctype="multipart/form-data" class="bg-upload-form">
                    <input type="hidden" name="action"  value="update_bg">
                    <input type="hidden" name="bg_type" value="fm">
                    <div class="bg-card">
                        <p class="bg-card-title">🗂️ Dateimanager-Login</p>
                        <div class="bg-dropzone<?= $bgFmCurrent ? ' has-preview' : '' ?>" id="bg-drop-fm"
                             onclick="this.querySelector('.bg-file-input').click()">
                            <?php if ($bgFmCurrent): ?>
                                <img class="bg-img-preview" src="<?= htmlspecialchars($bgFmCurrent) ?>" alt="">
                            <?php else: ?>
                                <img class="bg-img-preview" src="" alt="" style="display:none;">
                            <?php endif; ?>
                            <div class="bg-dz-overlay">
                                <span class="bg-dz-icon">🖼️</span>
                                <span class="bg-dz-label"><?= $bgFmCurrent ? 'Bild austauschen' : 'Bild auswählen oder ablegen' ?></span>
                                <span class="bg-dz-hint">JPG · PNG · WEBP · GIF</span>
                            </div>
                            <input class="bg-file-input" type="file" name="bg_file" accept="image/*"
                                   onchange="bgPickerChange(this, 'bg-drop-fm', 'bg-name-fm')">
                        </div>
                        <span class="bg-filename" id="bg-name-fm">
                            <?= $bgFmCurrent ? htmlspecialchars(basename($bgFmCurrent)) : 'Kein Bild gesetzt' ?>
                        </span>
                        <button type="submit" class="btn btn-success" style="width:100%;">💾 Hochladen</button>
                    </div>
                </form>

            </div><!-- /bg-cards-grid -->
            </div><!-- /section-body -->
        </div>

        <!-- ── System-Info ──────────────────────────────────────────────────────── -->
        <div class="section collapsed" id="sec-system" style="border:none;">
            <div class="section-header" onclick="toggleSection('sec-system')">
                <h2>ℹ️ System-Info & Wartung</h2>
                <span class="section-toggle">▾</span>
            </div>
            <div class="section-body">
            <p style="font-size:13px; opacity:0.7; margin-bottom:15px;">
                Version: <code><?= htmlspecialchars($currentVersionStr) ?></code>&nbsp;&nbsp;
                PHP: <code><?= phpversion() ?></code>&nbsp;&nbsp;
                Root: <code><?= htmlspecialchars($basePath) ?></code>
            </p>
            <div id="versionUpdateBanner" style="display:none; margin-bottom:20px; padding:16px 18px; background:rgba(16,185,129,0.08); border:1px solid rgba(16,185,129,0.35); border-radius:12px; font-size:13px; color:#34d399;">
                <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;">
                    <div>
                        <span style="font-size:16px; margin-right:6px;">✨</span>
                        <b>Neue Version verfügbar: <span id="lblRemoteVersion"></span></b>
                    </div>
                    <button onclick="document.getElementById('bannerChangelog').style.display = document.getElementById('bannerChangelog').style.display==='none' ? 'block' : 'none'"
                        style="background:rgba(16,185,129,0.15); border:1px solid rgba(16,185,129,0.4); color:#34d399; border-radius:8px; padding:4px 12px; font-size:12px; cursor:pointer;">
                        📋 Was ist neu?
                    </button>
                </div>
                <div id="bannerChangelog" style="display:none; margin-top:12px; padding:12px 14px; background:rgba(0,0,0,0.15); border-radius:8px; font-size:12px; line-height:1.7; color:inherit; white-space:pre-wrap; max-height:260px; overflow-y:auto; font-family:monospace;"></div>
            </div>
            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:15px;">
                <form method="post">
                    <input type="hidden" name="action" value="php_update">
                    <button type="submit" class="btn btn-primary" style="width:200px;">🚀 PHP-Update prüfen</button>
                </form>
                <form method="post" id="updateFmForm">
                    <input type="hidden" name="action" value="update_dateimanager">
                    <button type="button" class="btn btn-success" style="width:200px;" onclick="confirmFmUpdate()">🔄 Version aktualisieren</button>
                </form>
                <form method="post" id="cleanupForm">
                    <input type="hidden" name="action" value="cleanup_install">
                    <button type="button" class="btn btn-danger" style="white-space:nowrap;" onclick="confirmCleanup()">🧹 Installation bereinigen</button>
                </form>
            </div>
            <p style="font-size:12px; color:#94a3b8; margin-top:15px;">
                ⚠️ Der Ordner <code>config/</code> wird für Sicherheitseinstellungen benötigt und darf nicht gelöscht
                werden.
            </p>
            </div><!-- /section-body -->
        </div>
    </div>

    <script>
        // ── Dark Mode ─────────────────────────────────────────────────────────────────
        // ── Akzentfarbe laden (localStorage) ─────────────────────────────────────────
        (function () {
            const color = localStorage.getItem('fm_accent_color');
            const hover = localStorage.getItem('fm_accent_hover');
            if (color) {
                document.documentElement.style.setProperty('--primary', color);
                if (hover) document.documentElement.style.setProperty('--primary-hover', hover);
            }
        })();
        function toggleDarkMode() {
            const isDark = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDark ? 'true' : 'false');
        }
        if (localStorage.getItem('darkMode') !== 'false') document.body.classList.add('dark-mode');

        // ── Einklappbare Sektionen ────────────────────────────────────────────────────
        function toggleSection(id) {
            const sec = document.getElementById(id);
            if (!sec) return;
            sec.classList.toggle('collapsed');
            const state = {};
            document.querySelectorAll('[id^="sec-"]').forEach(s => {
                state[s.id] = s.classList.contains('collapsed');
            });
            localStorage.setItem('sectionStateV2', JSON.stringify(state));
        }
        (function () {
            const saved = JSON.parse(localStorage.getItem('sectionStateV2') || '{}');
            document.querySelectorAll('[id^="sec-"]').forEach(s => {
                if (saved[s.id] === false) s.classList.remove('collapsed');
            });
        })();

        // ── Hilfsfunktionen ───────────────────────────────────────────────────────────
        function escapeHtml(str) {
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
        }

        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            if (!input) return;
            input.type = input.type === 'password' ? 'text' : 'password';
            btn.textContent = input.type === 'text' ? '🙈' : '👁️';
        }

        // ── Auto-Hide Status-Alert ────────────────────────────────────────────────────
        setTimeout(() => {
            const msg = document.getElementById('statusMsg');
            if (msg) msg.style.opacity = '0';
        }, 6000);

        // -- Benutzer anlegen ----------------------------------------------------------
        function showAddUser() {
            customModal({
                title: '➕ Neuen Benutzer anlegen',
                message: `
            <form id="addUserForm" method="post" style="text-align:left;">
                <input type="hidden" name="action" value="add_user">
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Benutzername</label>
                    <input type="text" name="username" required placeholder="z.B. admin"
                        style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.3); color:white; box-sizing:border-box;">
                </div>
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Rolle</label>
                    <select name="is_admin" style="width:100%; padding:10px; border-radius:8px;">
                        <option value="1">Admin</option>
                        <option value="0">Benutzer</option>
                    </select>
                </div>
                <div style="margin-bottom:20px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Passwort</label>
                    <div class="password-wrapper" style="margin-bottom:0;">
                        <input type="password" name="password" id="pass_new_admin" required placeholder="Sicheres Passwort">
                        <button type="button" onclick="togglePassword('pass_new_admin',this)" class="toggle-password">👁️</button>
                    </div>
                </div>
                <button type="submit" class="btn btn-success" style="width:100%;">Benutzer anlegen</button>
            </form>`
            });
        }

        // -- Benutzer bearbeiten -------------------------------------------------------
        function showEditUser(id, name, has2fa, isAdmin) {
            customModal({
                title: '✏️ Bearbeiten: ' + escapeHtml(name),
                message: `
            <form method="post" style="text-align:left;">
                <input type="hidden" name="action" value="edit_user">
                <input type="hidden" name="user_id" value="${id}">
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Benutzername</label>
                    <input type="text" name="username" value="${escapeHtml(name)}" required
                        style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.3); color:white; box-sizing:border-box;">
                </div>
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Rolle</label>
                    <select name="is_admin" style="width:100%; padding:10px; border-radius:8px;">
                        <option value="1" ${isAdmin ? 'selected' : ''}>Admin</option>
                        <option value="0" ${!isAdmin ? 'selected' : ''}>Benutzer</option>
                    </select>
                </div>
                <div style="margin-bottom:15px;">
                    <label style="color:#94a3b8; font-size:12px; display:block; margin-bottom:6px;">Neues Passwort (optional)</label>
                    <div class="password-wrapper" style="margin-bottom:0;">
                        <input type="password" name="password" id="pass_edit_${id}" placeholder="Leer lassen = unver�ndert">
                        <button type="button" onclick="togglePassword('pass_edit_${id}',this)" class="toggle-password">👁️</button>
                    </div>
                </div>
                <div style="margin-bottom:20px; padding:15px; background:rgba(255,255,255,0.05); border-radius:10px;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="font-weight:600;">🔐 2-Faktor-Authentifizierung</span>
                        <span style="font-size:12px; color:${has2fa ? '#10b981' : '#94a3b8'};">${has2fa ? '✅ Aktiviert' : '⚫ Nicht aktiv'}</span>
                    </div>
                    <div style="margin-top:10px;">
                        ${has2fa
                        ? `<button type="button" onclick="disable2FA(${id}, '${escapeHtml(name)}')" class="btn btn-danger btn-small" style="width:auto;">🔓 Deaktivieren</button>`
                        : `<button type="button" onclick="show2FASetup(${id}, '${escapeHtml(name)}')" class="btn btn-success btn-small" style="width:auto;">🔐 2FA einrichten</button>`
                    }
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%;">Änderungen speichern</button>
            </form>`
            });
        }

        // ── Protokoll ─────────────────────────────────────────────────────────────────
        const AUDIT_LABELS = {
            admin_login:'🔑 Admin-Login', user_login:'🔑 Anmeldung', login_failed:'🚫 Login fehlgeschlagen',
            logout:'🚪 Abgemeldet',
            upload:'⬆️ Upload', download:'⬇️ Download', download_zip:'📦 ZIP-Download',
            file_view:'👁️ Vorschau',
            create_file:'📄 Datei erstellt', create_folder:'📁 Ordner erstellt',
            rename:'✏️ Umbenannt', edit_file:'✏️ Datei bearbeitet', unzip_file:'📦 Entpackt',
            copy_file:'📋 Kopiert', move_file:'✂️ Verschoben',
            delete:'🗑️ Papierkorb', trash_restore:'↩️ Wiederhergestellt',
            trash_delete:'💀 Endgültig gelöscht', trash_empty:'🗑️ Papierkorb geleert',
            add_user:'👤 Nutzer angelegt', edit_user:'✏️ Nutzer bearbeitet',
            delete_user:'👤 Nutzer gelöscht', disable_2fa:'🔓 2FA deaktiviert (Admin)',
            my_2fa_enable:'🔐 2FA aktiviert', my_2fa_disable:'🔓 2FA deaktiviert',
            confirm_2fa_setup:'🔐 2FA eingerichtet',
            set_visibility:'👁️ Sichtbarkeit', media_metadata_save:'🎵 Metadaten',
            update_bg:'🖼️ Hintergrundbild', update_acl:'🔒 Globale Rechte',
            update_folder_acl:'📁 Ordner-Rechte', delete_folder_acl:'🗑️ Ordner-Rechte gelöscht',
            update_user_perm:'👤 Nutzer-Rechte', delete_user_perm:'🗑️ Nutzer-Rechte gelöscht',
            update_dateimanager:'🔄 Dateimanager-Update', cleanup_install:'🧹 Installation bereinigt'
        };
        const AUDIT_CATS = [
            { k:'',             l:'Alle Kategorien',    a:null },
            { k:'login',        l:'🔑 Anmeldung',       a:['admin_login','user_login','login_failed','logout'] },
            { k:'files',        l:'📁 Dateien',          a:['upload','download','file_view','download_zip','create_file','create_folder','rename','edit_file','unzip_file','copy_file','move_file','media_metadata_save'] },
            { k:'trash',        l:'🗑️ Papierkorb',      a:['delete','trash_restore','trash_delete','trash_empty'] },
            { k:'users',        l:'👥 Benutzer',         a:['add_user','edit_user','delete_user','disable_2fa','my_2fa_enable','my_2fa_disable','confirm_2fa_setup'] },
            { k:'visibility',   l:'👁️ Sichtbarkeit',     a:['set_visibility'] },
            { k:'admin',        l:'⚙️ Administration',   a:['update_bg','update_acl','update_folder_acl','delete_folder_acl','update_user_perm','delete_user_perm','update_dateimanager','cleanup_install'] }
        ];
        const AUDIT_COLS = [
            { key:'created_at', label:'Zeit' },
            { key:'actor',      label:'Wer' },
            { key:'action',     label:'Aktion' },
            { key:'target_path',label:'Pfad' },
            { key:'details',    label:'Details' }
        ];
        let _auditLogs = null;
        function _closeAuditLog() { _auditLogs = null; const o = document.getElementById('auditLogOverlay'); if (o) o.remove(); }
        async function _auditRefresh() { _auditLogs = null; await showAuditLog(); }
        let _auditSort = { col: 0, dir: -1 };

        async function showAuditLog() {
            let overlay = document.getElementById('auditLogOverlay');
            if (!overlay) {
                const catOpts = AUDIT_CATS.map(c => `<option value="${c.k}">${c.l}</option>`).join('');
                overlay = document.createElement('div');
                overlay.id = 'auditLogOverlay';
                overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
                overlay.innerHTML = `
                    <div style="border-radius:16px;width:100%;max-width:1200px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden;">
                        <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 24px;border-bottom:1px solid rgba(255,255,255,0.08);flex-shrink:0;">
                            <h2 style="margin:0;font-size:18px;">📋 Protokoll</h2>
                            <button onclick="_closeAuditLog()" style="background:none;border:none;color:#94a3b8;font-size:22px;cursor:pointer;line-height:1;">✕</button>
                        </div>
                        <div style="display:flex;gap:10px;padding:12px 24px;border-bottom:1px solid rgba(255,255,255,0.06);flex-shrink:0;flex-wrap:wrap;align-items:center;">
                            <input id="auditSearch" type="search" placeholder="🔍 Suche…" oninput="_auditRender()"
                                style="flex:1;min-width:160px;padding:8px 12px;border-radius:8px;background:rgba(0,0,0,0.3);color:white;border:1px solid rgba(255,255,255,0.12);font-size:13px;">
                            <select id="auditCat" onchange="_auditRender()"
                                style="padding:8px 12px;border-radius:8px;background:#0f172a;color:white;border:1px solid rgba(255,255,255,0.12);font-size:13px;cursor:pointer;width:auto;">
                                ${catOpts}
                            </select>
                            <span id="auditCount" style="font-size:12px;color:#64748b;white-space:nowrap;"></span>
                            <button onclick="_auditRefresh()" title="Neu laden" style="padding:7px 11px;border-radius:8px;background:rgba(99,102,241,0.15);color:#818cf8;border:1px solid rgba(99,102,241,0.3);font-size:13px;cursor:pointer;">&#8635;</button>
                        </div>
                        <div style="overflow:auto;flex:1;">
                            <table id="auditTable" style="width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed;">
                                <colgroup>
                                    <col style="width:130px;">
                                    <col style="width:110px;">
                                    <col style="width:175px;">
                                    <col style="width:auto;min-width:160px;">
                                    <col style="width:175px;">
                                </colgroup>
                                <thead>
                                    <tr id="auditThead" style="position:sticky;top:0;z-index:1;border-bottom:2px solid rgba(255,255,255,0.12);"></tr>
                                </thead>
                                <tbody id="auditTbody">
                                    <tr><td colspan="5" style="padding:40px;text-align:center;opacity:0.6;">Wird geladen…</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>`;
                overlay.addEventListener('click', e => { if (e.target === overlay) _closeAuditLog(); });
                document.body.appendChild(overlay);
                _buildAuditHeaders();
            }
            overlay.style.display = 'flex';
            try {
                const res = await fetch('admin_settings.php?audit_log=1', { credentials: 'same-origin' });
                const data = await res.json();
                _auditLogs = Array.isArray(data.logs) ? data.logs : [];
                _auditRender();
            } catch (e) {
                document.getElementById('auditTbody').innerHTML =
                    '<tr><td colspan="5" style="padding:30px;text-align:center;color:#f87171;">Protokoll konnte nicht geladen werden.</td></tr>';
            }
        }

        function _buildAuditHeaders() {
            const tr = document.getElementById('auditThead');
            if (!tr) return;
            tr.innerHTML = AUDIT_COLS.map((c, i) => `
                <th data-col="${i}" onclick="_auditSortBy(${i})" title="Nach ${c.label} sortieren"
                    style="text-align:left;padding:10px 12px;font-weight:600;cursor:pointer;user-select:none;white-space:nowrap;letter-spacing:0.4px;font-size:11px;text-transform:uppercase;">
                    ${c.label}<span class="audit-arrow" data-col="${i}"> ↕</span>
                </th>`).join('');
        }

        function _auditSortBy(col) {
            if (_auditSort.col === col) _auditSort.dir *= -1;
            else { _auditSort.col = col; _auditSort.dir = (col === 0) ? -1 : 1; }
            _auditRender();
        }

        function _auditRender() {
            if (_auditLogs === null) return;
            const search = (document.getElementById('auditSearch')?.value || '').toLowerCase().trim();
            const cat    = document.getElementById('auditCat')?.value || '';
            const catActions = cat ? (AUDIT_CATS.find(c => c.k === cat)?.a ?? null) : null;

            let rows = _auditLogs.filter(r => {
                if (catActions && !catActions.includes(r.action)) return false;
                if (!search) return true;
                const label = (AUDIT_LABELS[r.action] || r.action || '').toLowerCase();
                return (r.actor||'').toLowerCase().includes(search)
                    || label.includes(search)
                    || (r.target_path||'').toLowerCase().includes(search)
                    || (r.details||'').toLowerCase().includes(search);
            });

            const col = AUDIT_COLS[_auditSort.col].key;
            const dir = _auditSort.dir;
            rows = rows.slice().sort((a, b) => {
                const va = (a[col] || '').toLowerCase();
                const vb = (b[col] || '').toLowerCase();
                return va < vb ? -dir : va > vb ? dir : 0;
            });

            // Update sort arrows
            const isDark = document.body.classList.contains('dark-mode');
            document.querySelectorAll('#auditThead .audit-arrow').forEach(el => {
                const c = parseInt(el.dataset.col);
                const th = el.closest('th');
                if (c === _auditSort.col) {
                    el.textContent = ' ' + (_auditSort.dir === -1 ? '▼' : '▲');
                    el.style.color = 'var(--primary)';
                    th.style.color = isDark ? '#e2e8f0' : '#1e293b';
                    th.style.borderBottom = '2px solid var(--primary)';
                } else {
                    el.textContent = ' ↕';
                    el.style.color = isDark ? 'rgba(255,255,255,0.25)' : 'rgba(0,0,0,0.25)';
                    th.style.color = isDark ? '#94a3b8' : '#475569';
                    th.style.borderBottom = '';
                }
            });

            const countEl = document.getElementById('auditCount');
            if (countEl) countEl.textContent = rows.length === _auditLogs.length
                ? `${_auditLogs.length} Einträge` : `${rows.length} / ${_auditLogs.length}`;

            const tbody = document.getElementById('auditTbody');
            if (!tbody) return;
            if (rows.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="padding:30px;text-align:center;opacity:0.5;">Keine Einträge gefunden.</td></tr>';
                return;
            }
            tbody.innerHTML = rows.map(row => {
                const dt  = row.created_at ? row.created_at.replace('T',' ').substring(0,16) : '';
                const lbl = AUDIT_LABELS[row.action] || escapeHtml(row.action || '');
                const isFail = row.status === 'failure';
                const rowBg = isFail ? 'rgba(239,68,68,0.07)' : '';
                const det = row.details ? escapeHtml(row.details) : '';
                const detBadge = det
                    ? `<span style="display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;background:rgba(255,255,255,0.07);color:#94a3b8;white-space:nowrap;max-width:160px;overflow:hidden;text-overflow:ellipsis;" title="${det}">${det}</span>`
                    : '';
                return `<tr style="border-bottom:1px solid rgba(255,255,255,0.05);background:${rowBg};">
                    <td style="padding:8px 10px;white-space:nowrap;color:#64748b;font-size:12px;">${escapeHtml(dt)}</td>
                    <td style="padding:8px 10px;white-space:nowrap;font-weight:500;">${escapeHtml(row.actor||'')}</td>
                    <td style="padding:8px 10px;white-space:nowrap;">${lbl}</td>
                    <td style="padding:8px 10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#94a3b8;" title="${escapeHtml(row.target_path||'')}">${escapeHtml(row.target_path||'')}</td>
                    <td style="padding:8px 10px;text-align:left;">${detBadge}</td>
                </tr>`;
            }).join('');
        }

        // -- Benutzer l�schen ----------------------------------------------------------
        async function deleteUser(id, name) {
            const ok = await customModal({
                title: '🗑️ Benutzer löschen',
                message: `Benutzer <b>${escapeHtml(name)}</b> wirklich löschen?`,
                type: 'confirm', confirmText: 'Ja, löschen', cancelText: 'Abbrechen'
            });
            if (ok) {
                const f = document.createElement('form');
                f.method = 'post';
                f.innerHTML = `<input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="${id}">`;
                document.body.appendChild(f);
                f.submit();
            }
        }

        // ── Regel löschen ─────────────────────────────────────────────────────────────
        async function deleteRule(path) {
            const ok = await customModal({
                title: '🗑️ Regel löschen',
                message: `Möchtest du die Regel für den Ordner <b>${escapeHtml(path)}</b> wirklich löschen?`,
                type: 'confirm', confirmText: 'Ja, löschen', cancelText: 'Abbrechen'
            });
            if (ok) {
                const f = document.createElement('form');
                f.method = 'post';
                f.innerHTML = `<input type="hidden" name="action" value="delete_folder_acl"><input type="hidden" name="folder_path" value="${escapeHtml(path)}">`;
                document.body.appendChild(f);
                f.submit();
            }
        }

        // ── Benutzerspezifische Berechtigung vorausfüllen (Bearbeiten) ───────────────
        function prefillUserPermForm(user, folder, perms) {
            const sec = document.getElementById('sec-userperms');
            if (sec && sec.classList.contains('collapsed')) toggleSection('sec-userperms');
            const form = document.querySelector('#sec-userperms form');
            if (!form) return;
            const userSel = form.querySelector('[name="target_user"]');
            const folderSel = form.querySelector('select[name="up_folder"]');
            const folderInput = form.querySelector('input[name="up_folder"]');
            if (userSel) userSel.value = user;
            if (folderSel) folderSel.value = folder;
            if (folderInput) folderInput.value = folder;
            ['upload','create','edit','rename','delete'].forEach(k => {
                const cb = form.querySelector(`[name="up_${k}"]`);
                if (cb) cb.checked = !!perms[k];
            });
            setTimeout(() => {
                form.scrollIntoView({ behavior: 'smooth', block: 'start' });
                form.style.outline = '2px solid var(--primary)';
                setTimeout(() => { form.style.outline = ''; }, 1800);
            }, 120);
        }

        // ── 2FA deaktivieren ─────────────────────────────────────────────────────────
        async function disable2FA(id, name) {
            const ok = await customModal({
                title: '🔓 2FA deaktivieren',
                message: `2FA für <b>${escapeHtml(name)}</b> wirklich deaktivieren?`,
                type: 'confirm', confirmText: 'Deaktivieren', cancelText: 'Abbrechen'
            });
            if (ok) {
                const f = document.createElement('form');
                f.method = 'post';
                f.innerHTML = `<input type="hidden" name="action" value="disable_2fa"><input type="hidden" name="user_id" value="${id}">`;
                document.body.appendChild(f);
                f.submit();
            }
        }

        // ── 2FA einrichten (OTPAuth + QR-Code) ───────────────────────────────────────
        async function show2FASetup(userId, userName) {
            // Schritt 1: Secret vom Server holen
            let data;
            try {
                const res = await fetch('admin_settings.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=get_2fa_secret&user_id=${userId}`
                });
                data = await res.json();
            } catch (e) {
                customModal({ title: '❌ Fehler', message: 'Netzwerkfehler beim Laden des Secrets.' });
                return;
            }
            if (data.error) { customModal({ title: '❌ Fehler', message: escapeHtml(data.error) }); return; }

            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(data.uri)}`;

            // Schritt 2: Bestehende Modals schließen, dann 2FA-Modal öffnen
            $('.modal-overlay').remove();
            const overlay = $('<div class="modal-overlay modal-front"></div>');
            const card = $(`
        <div class="modal-card" style="max-width:420px; text-align:center;">
            <div class="modal-header" style="position:relative;">
                🔐 2FA Einrichten: ${escapeHtml(data.username)}
                <button class="modal-close" onclick="$(this).closest('.modal-overlay').remove()">×</button>
            </div>
            <div class="modal-body">
                <p style="font-size:13px; opacity:0.8; margin-bottom:15px;">
                    Scanne den QR-Code mit <b>Google Authenticator</b>, <b>Authy</b> oder einer anderen TOTP-App.
                </p>
                <div style="background:white; padding:10px; display:inline-block; border-radius:8px; margin-bottom:15px;">
                    <img src="${qrUrl}" alt="QR Code" style="display:block; width:180px; height:180px;"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block'">
                    <p style="display:none; color:#333; font-size:11px; margin:0; padding:5px;">QR nicht ladbar – Secret manuell eingeben</p>
                </div>
                <p style="font-size:11px; margin-bottom:8px; opacity:0.5;">Oder Secret manuell eingeben:</p>
                <div style="font-family:monospace; font-size:18px; letter-spacing:3px; background:rgba(0,0,0,0.4); padding:12px; border-radius:8px; margin-bottom:10px; color:#2DE2E6; cursor:pointer; user-select:all;"
                     onclick="navigator.clipboard.writeText('${data.secret}'); this.textContent='✅ Kopiert!'; setTimeout(()=>this.textContent='${data.secret}',2000);">
                    ${data.secret}
                </div>
                <p style="font-size:11px; margin-bottom:20px; opacity:0.5;">Klicke auf den Secret zum Kopieren</p>
                <input type="text" id="twofa-code-input" placeholder="6-stelligen Code eingeben"
                    maxlength="6" inputmode="numeric" pattern="[0-9]*"
                    style="text-align:center; letter-spacing:5px; font-size:22px; width:100%; padding:14px; border-radius:10px; border:1px solid rgba(255,255,255,0.2); background:rgba(0,0,0,0.4); color:white; box-sizing:border-box;">
                <div id="twofa-error" style="color:#f87171; font-size:13px; margin-top:8px; display:none;"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="$(this).closest('.modal-overlay').remove()">Abbrechen</button>
                <button class="btn btn-success" id="btn-finish-2fa">✅ Einrichtung abschließen</button>
            </div>
        </div>`);

            overlay.append(card);
            $('body').append(overlay);
            setTimeout(() => $('#twofa-code-input').focus(), 300);

            // Enter-Taste im Input
            card.find('#twofa-code-input').on('keydown', e => {
                if (e.key === 'Enter') card.find('#btn-finish-2fa').trigger('click');
            });

            // Schritt 3: Bestätigen
            card.find('#btn-finish-2fa').on('click', async () => {
                const code = $('#twofa-code-input').val().trim().replace(/\s/g, '');
                const errDiv = card.find('#twofa-error');

                if (!code || code.length !== 6) {
                    errDiv.text('Bitte gib den 6-stelligen Code ein.').show();
                    return;
                }

                // Client-seitige Vorprüfung mit OTPAuth
                if (window.OTPAuth) {
                    try {
                        const totp = new OTPAuth.TOTP({ secret: data.secret, algorithm: 'SHA1', digits: 6, period: 30 });
                        const delta = totp.validate({ token: code, window: 1 });
                        if (delta === null) {
                            errDiv.text('Code ungültig (App-Prüfung). Bitte erneut versuchen.').show();
                            return;
                        }
                    } catch (e) {
                        console.warn('OTPAuth client check failed:', e);
                    }
                }

                const btn = card.find('#btn-finish-2fa').prop('disabled', true).text('Prüfe…');

                try {
                    const vRes = await fetch('admin_settings.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `action=confirm_2fa_setup&user_id=${userId}&code=${encodeURIComponent(code)}`
                    });
                    const vData = await vRes.json();
                    if (vData.success) {
                        overlay.remove();
                        customModal({ title: '✅ 2FA aktiviert', message: `2FA für <b>${escapeHtml(userName)}</b> wurde erfolgreich eingerichtet.` });
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        errDiv.text(vData.error || 'Ungültiger Code. Bitte erneut versuchen.').show();
                        btn.prop('disabled', false).text('✅ Einrichtung abschließen');
                    }
                } catch (e) {
                    errDiv.text('Netzwerkfehler – bitte erneut versuchen.').show();
                    btn.prop('disabled', false).text('✅ Einrichtung abschließen');
                }
            });
        }


        async function confirmCleanup() {
            const ok = await customModal({
                title: '🧹 Installation bereinigen',
                message: '<b>Achtung:</b> Der <code>/install</code>-Ordner wird unwiderruflich gelöscht.<br>Das Setup kann danach nicht mehr erneut aufgerufen werden.',
                type: 'confirm', confirmText: 'Ja, löschen', cancelText: 'Abbrechen'
            });
            if (ok) document.getElementById('cleanupForm').submit();
        }

        async function confirmFmUpdate() {
            const ok = await customModal({
                title: '🔄 Dateimanager aktualisieren',
                message: 'Möchtest du den Dateimanager wirklich auf die neueste Version von Github/Web-Service aktualisieren?<br><br>Deine Einstellungen und hochgeladenen Hintergrundbilder bleiben dabei <b>vollständig erhalten</b>.',
                type: 'confirm', confirmText: 'Jetzt aktualisieren', cancelText: 'Abbrechen'
            });
            if (ok) {
                const btn = document.querySelector('#updateFmForm button');
                btn.disabled = true;
                btn.innerText = '⚡ Aktualisierung läuft...';
                document.getElementById('updateFmForm').submit();
            }
        }
    </script>
    <script src="script.js?v=219"></script>
    <script>
        function editRule(path, rules) {
            document.querySelector('input[name="folder_path"]').value = path;
            document.querySelector('input[name="is_private"]').checked = !!rules.is_private;
            document.querySelector('input[name="can_upload"]').checked = !!rules.upload;
            document.querySelector('input[name="can_create"]').checked = !!rules.create;
            document.querySelector('input[name="can_edit"]').checked = !!rules.edit;
            document.querySelector('input[name="can_rename"]').checked = !!rules.rename;
            document.querySelector('input[name="can_delete"]').checked = !!rules.delete;

            // Scroll zum Formular
            document.querySelector('input[name="folder_path"]').scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Highlight Effekt
            const form = document.querySelector('form[style*="margin-bottom:25px"]');
            if (form) {
                form.style.borderColor = 'var(--primary)';
                setTimeout(() => { form.style.borderColor = 'rgba(255,255,255,0.05)'; }, 2000);
            }
        }

        const EXTENSION_ASYNC_MESSAGE = 'A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received';
        let extensionAsyncWarningShown = false;
        window.addEventListener('unhandledrejection', event => {
            const reason = event && event.reason;
            const message = typeof reason === 'string'
                ? reason
                : (reason && typeof reason.message === 'string' ? reason.message : '');
            if (message.includes(EXTENSION_ASYNC_MESSAGE)) {
                event.preventDefault();
                if (!extensionAsyncWarningShown) {
                    extensionAsyncWarningShown = true;
                    console.info('Hinweis: Eine Browser-Erweiterung hat eine asynchrone Rejection ausgelöst.');
                }
            }
        });

        // 🖼️ Vorschau bei Dateiauswahl
        function bgPickerChange(input, dropId, nameId) {
            const drop = document.getElementById(dropId);
            const nameEl = document.getElementById(nameId);
            const label = drop.querySelector('.bg-dz-label');
            if (!input.files || !input.files[0]) return;
            const file = input.files[0];
            const reader = new FileReader();
            reader.onload = e => {
                let img = drop.querySelector('.bg-img-preview');
                if (!img) {
                    img = document.createElement('img');
                    img.className = 'bg-img-preview';
                    drop.prepend(img);
                }
                img.style.display = '';
                img.src = e.target.result;
                drop.classList.add('has-preview');
                if (label) label.textContent = 'Bild austauschen';
                if (nameEl) nameEl.textContent = file.name;
            };
            reader.readAsDataURL(file);
        }

        // 🖼️ Client-Side Background Image Compression to bypass php.ini upload_max_filesize limit
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.bg-upload-form').forEach(bgForm => {
                bgForm.addEventListener('submit', function (e) {
                    const fileInput = bgForm.querySelector('input[name="bg_file"]');
                    const file = fileInput.files[0];
                    if (!file) return;

                    // Only compress images larger than 1.5MB
                    if (file.size > 1.5 * 1024 * 1024 && file.type.startsWith('image/')) {
                        e.preventDefault(); // Stop normal form submit

                        // Show a nice loading/compression message
                        const submitBtn = bgForm.querySelector('button[type="submit"]');
                        const origText = submitBtn.innerText;
                        submitBtn.disabled = true;
                        submitBtn.innerText = '⚡ Bild wird komprimiert...';

                        const reader = new FileReader();
                        reader.onload = function (event) {
                            const img = new Image();
                            img.onload = function () {
                                const canvas = document.createElement('canvas');
                                let width = img.width;
                                let height = img.height;
                                const maxDim = 1920; // Perfect full HD resolution

                                if (width > maxDim || height > maxDim) {
                                    if (width > height) {
                                        height = Math.round((height * maxDim) / width);
                                        width = maxDim;
                                    } else {
                                        width = Math.round((width * maxDim) / height);
                                        height = maxDim;
                                    }
                                }

                                canvas.width = width;
                                canvas.height = height;
                                const ctx = canvas.getContext('2d');
                                ctx.drawImage(img, 0, 0, width, height);

                                // Export as high quality JPEG
                                canvas.toBlob((blob) => {
                                    if (blob) {
                                        // Create a new FormData and submit it via AJAX fetch!
                                        const formData = new FormData();
                                        formData.append('action', 'update_bg');
                                        formData.append('bg_type', bgForm.querySelector('[name="bg_type"]').value);
                                        formData.append('bg_file', blob, 'compressed_bg.jpg');

                                        fetch('admin_settings.php', {
                                            method: 'POST',
                                            body: formData
                                        })
                                        .then(res => {
                                            if (res.ok) {
                                                window.location.href = 'admin_settings.php?success=' + encodeURIComponent('Hintergrundbild komprimiert & aktualisiert.');
                                            } else {
                                                alert('Fehler beim Upload des komprimierten Bildes.');
                                                submitBtn.disabled = false;
                                                submitBtn.innerText = origText;
                                            }
                                        })
                                        .catch(() => {
                                            alert('Upload-Fehler.');
                                            submitBtn.disabled = false;
                                            submitBtn.innerText = origText;
                                        });
                                    } else {
                                        // Fallback: submit original
                                        bgForm.submit();
                                    }
                                }, 'image/jpeg', 0.85); // 0.85 is the sweet spot for visual excellence and tiny size!
                            };
                            img.src = event.target.result;
                        };
                        reader.readAsDataURL(file);
                    }
                });
            });

            // Version Check
            fetch('admin_settings.php?check_version=1', { credentials: 'same-origin' })
                .then(res => {
                    if (!res.ok) throw new Error('HTTP ' + res.status);
                    return res.json();
                })
                .then(data => {
                    if (data.update_available) {
                        const banner = document.getElementById('versionUpdateBanner');
                        const lblRemote = document.getElementById('lblRemoteVersion');
                        const clDiv = document.getElementById('bannerChangelog');
                        if (banner && lblRemote) {
                            lblRemote.innerText = 'v' + data.remote;
                            banner.style.display = 'block';
                            if (clDiv && data.changelog) {
                                clDiv.textContent = data.changelog;
                            }
                        }
                    }
                })
                .catch(err => console.warn('Fehler beim Versions-Check:', err));
        });
    </script>
</body>

</html>
