<?php
declare(strict_types=1);
session_start();

// 1. Sicherheit: Nur Admins!
if (empty($_SESSION['admin_access'])) {
    header('Location: admin_login.php');
    exit;
}

$configFile = __DIR__ . '/config.php';
require_once $configFile;
$db = new mysqli($db_host, $db_user, $db_pass, $db_name);

$securityFile = __DIR__ . '/../config/security.php';
if (!file_exists($securityFile)) {
    die('❌ security.php fehlt.');
}
require_once $securityFile;

// Hilfsfunktion für 2FA Secret
function generate2FASecret($length = 16) {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < $length; $i++) $secret .= $chars[random_int(0, 31)];
    return $secret;
}

$success = '';
$error = '';

// 2. DB Migration: 2FA Spalte hinzufügen falls fehlt
$res = $db->query("SHOW COLUMNS FROM benutzer LIKE 'auth_secret'");
if ($res->num_rows === 0) {
    if (!$db->query("ALTER TABLE benutzer ADD COLUMN auth_secret VARCHAR(32) NULL DEFAULT NULL")) {
        $error = "❌ Fehler bei Migration: " . $db->error;
    }
}

// 2. Verarbeitung
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Benutzer anlegen
    if ($action === 'add_user') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        if ($user && $pass) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO benutzer (nutzername, passwort) VALUES (?, ?)");
            $stmt->bind_param('ss', $user, $hash);
            if ($stmt->execute())
                $success = "✅ Admin '$user' hinzugefügt.";
            else
                $error = "❌ Fehler: " . $db->error;
        }
    }

    // Benutzer bearbeiten (NEU)
    if ($action === 'edit_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $newName = trim($_POST['username'] ?? '');
        $newPass = $_POST['password'] ?? '';

        if ($newName) {
            $setup2fa = isset($_POST['setup_2fa']);
            if ($newPass) {
                $hash = password_hash($newPass, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ?, passwort = ? WHERE id = ?");
                $stmt->bind_param('ssi', $newName, $hash, $id);
            } else {
                $stmt = $db->prepare("UPDATE benutzer SET nutzername = ? WHERE id = ?");
                $stmt->bind_param('si', $newName, $id);
            }
            if ($stmt->execute()) {
                $success = "✅ Benutzer aktualisiert.";
                if ($setup2fa) {
                    $res = $db->query("SELECT auth_secret FROM benutzer WHERE id = $id");
                    $u = $res->fetch_assoc();
                    if (empty($u['auth_secret'])) {
                        $secret = generate2FASecret();
                        $db->query("UPDATE benutzer SET auth_secret = '$secret' WHERE id = $id");
                        $success .= " | 🔐 2FA Secret: **$secret** (Bitte in App speichern!)";
                    }
                }
            } else {
                $error = "❌ Fehler.";
            }
        }
    }

    // Benutzer löschen
    if ($action === 'delete_user') {
        $id = (int) ($_POST['user_id'] ?? 0);
        $db->query("DELETE FROM benutzer WHERE id = $id");
        $success = "✅ Benutzer gelöscht.";
    }

    if ($action === 'update_user_pass') {
        $newPass = $_POST['user_pass'] ?? '';
        if (strlen($newPass) < 4) {
            $error = '❌ Passwort zu kurz (min. 4 Zeichen).';
        } else {
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FILEMANAGER_ACCESS_HASH', '.*?'\);/", "define('FILEMANAGER_ACCESS_HASH', '{$hash}');", $content);
            file_put_contents($securityFile, $content);
            $success = '✅ Normalnutzer-Passwort erfolgreich aktualisiert.';
        }
    }

    // Hintergrund-Update
    if ($action === 'update_bg') {
        $type = $_POST['bg_type'] ?? 'web';
        $const = ($type === 'web') ? 'WEB_LOGIN_BG' : 'FILEMANAGER_LOGIN_BG';

        if (isset($_FILES['bg_file']) && $_FILES['bg_file']['error'] === UPLOAD_ERR_OK) {
            $name = 'bg_' . bin2hex(random_bytes(8)) . '.webp';
            $target = __DIR__ . '/../uploads/' . $name;
            if (!is_dir(__DIR__ . '/../uploads'))
                mkdir(__DIR__ . '/../uploads', 0755, true);

            if (move_uploaded_file($_FILES['bg_file']['tmp_name'], $target)) {
                $path = '/uploads/' . $name;
                $content = file_get_contents($securityFile);
                $content = preg_replace("/define\('$const', '.*?'\);/", "define('$const', '$path');", $content);
                file_put_contents($securityFile, $content);
                $success = "✅ Hintergrundbild aktualisiert.";
            } else {
                $error = "❌ Fehler beim Verschieben.";
            }
        }
    }

    // ACL Einstellungen (NEU)
    if ($action === 'update_acl') {
        $can_del = isset($_POST['can_delete']) ? 'true' : 'false';
        $can_ren = isset($_POST['can_rename']) ? 'true' : 'false';
        $can_up = isset($_POST['can_upload']) ? 'true' : 'false';
        $can_cre = isset($_POST['can_create']) ? 'true' : 'false';

        $content = file_get_contents($securityFile);
        $content = preg_replace("/define\('USER_CAN_DELETE', .*?\);/", "define('USER_CAN_DELETE', $can_del);", $content);
        $content = preg_replace("/define\('USER_CAN_RENAME', .*?\);/", "define('USER_CAN_RENAME', $can_ren);", $content);
        $content = preg_replace("/define\('USER_CAN_UPLOAD', .*?\);/", "define('USER_CAN_UPLOAD', $can_up);", $content);
        $content = preg_replace("/define\('USER_CAN_CREATE', .*?\);/", "define('USER_CAN_CREATE', $can_cre);", $content);

        if (file_put_contents($securityFile, $content))
            $success = "✅ Globale Berechtigungen aktualisiert.";
        else
            $error = "❌ Fehler beim Speichern der Rechte.";
    }

    // Ordnerspezifische ACL (NEU)
    if ($action === 'disable_2fa') {
        $id = (int)($_POST['user_id'] ?? 0);
        if ($db->query("UPDATE benutzer SET auth_secret = NULL WHERE id = $id")) {
            $success = "🔓 2FA wurde deaktiviert.";
        } else {
            $error = "❌ Fehler beim Deaktivieren.";
        }
    }

    if ($action === 'update_folder_acl') {
        $path = trim($_POST['folder_path'] ?? '');
        $path = str_replace('\\', '/', $path);
        $path = trim($path, '/');

        if ($path !== '') {
            $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];
            // Sicherstellen, dass das neue Element unten dran gehängt wird
            if (isset($folderPerms[$path]))
                unset($folderPerms[$path]);

            $folderPerms[$path] = [
                'delete' => isset($_POST['can_delete']),
                'rename' => isset($_POST['can_rename']),
                'upload' => isset($_POST['can_upload']),
                'create' => isset($_POST['can_create'])
            ];
            $json = json_encode($folderPerms);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/", "define('FOLDER_PERMISSIONS', '$json');", $content);
            file_put_contents($securityFile, $content);
            // PRG Pattern: Reload nach Save
            header('Location: admin_settings.php?success=' . urlencode('Rechte für Ordner gespeichert.'));
            exit;
        }
    }

    if ($action === 'delete_folder_acl') {
        $path = $_POST['folder_path'] ?? '';
        $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];
        if (isset($folderPerms[$path])) {
            unset($folderPerms[$path]);
            $json = json_encode($folderPerms);
            $content = file_get_contents($securityFile);
            $content = preg_replace("/define\('FOLDER_PERMISSIONS', '.*?'\);/", "define('FOLDER_PERMISSIONS', '$json');", $content);
            file_put_contents($securityFile, $content);
            header('Location: admin_settings.php?success=' . urlencode('Regel entfernt.'));
            exit;
        }
    }

    if (isset($_GET['success'])) {
        $success = "✅ " . htmlspecialchars($_GET['success']);
    }

    if ($action === 'php_update') {
        // Simulierter Update-Trigger (In echter Root-Umgebung müsste dies ein sudo-command sein)
        $success = "✅ System-Check ausgeführt. PHP ist auf dem neuesten Stand (" . phpversion() . ").";
    }

    if ($action === 'cleanup_install') {
        $installDir = __DIR__ . '/../install/';
        if (is_dir($installDir)) {
            // Primitive rekursive Löschfunktion
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($installDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ($files as $fileinfo) {
                $todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
                $todo($fileinfo->getRealPath());
            }
            rmdir($installDir);
            $success = "✅ Installationsdateien wurden gelöscht.";
        } else {
            $error = "❌ Installationsordner nicht gefunden.";
        }
    }
}

// Benutzerliste laden
$users = $db->query("SELECT id, nutzername FROM benutzer");

// Ordnerliste für ACL-Dropdown laden
function getFolderList($dir, $base, &$folders = [])
{
    $files = scandir($dir);
    foreach ($files as $f) {
        if ($f === '.' || $f === '..')
            continue;
        $full = $dir . DIRECTORY_SEPARATOR . $f;
        if (is_dir($full)) {
            $rel = str_replace([$base, DIRECTORY_SEPARATOR], ['', '/'], $full);
            $rel = trim($rel, '/');
            if (!in_array($rel, ['config', 'install', 'sql', 'filemanager', '.git'])) {
                $folders[] = $rel;
                getFolderList($full, $base, $folders);
            }
        }
    }
    return $folders;
}
$basePath = realpath(__DIR__ . '/..');
$availableFolders = getFolderList($basePath, $basePath);
sort($availableFolders);
?>
<!DOCTYPE html>
<html lang="de">

    <head>
        <meta charset="UTF-8">
        <title>⚙️ Admin-Einstellungen</title>
        <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="script.js"></script>
        <style>
            body {
                display: flex;
                justify-content: center;
                padding: 20px;
                min-height: 100vh;
            }

            .box {
                width: 100%;
                max-width: 900px;
                background: var(--card);
                padding: 30px;
                border-radius: 16px;
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }

            .section {
                margin-bottom: 30px;
                padding: 25px;
                background: rgba(0, 0, 0, 0.2);
                border-radius: 12px;
                border: 1px solid rgba(255, 255, 255, 0.05);
                position: relative;
            }

            input,
            select {
                width: 100%;
                padding: 12px;
                border-radius: 8px;
                border: 1px solid #333;
                background: rgba(0, 0, 0, 0.5);
                color: white;
                margin-bottom: 15px;
                box-sizing: border-box;
            }

            .user-list td {
                padding: 12px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }

            .nav-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 25px;
            }

            .alert {
                position: absolute;
                top: 10px;
                right: 10px;
                z-index: 100;
                transition: opacity 0.5s;
                pointer-events: none;
                width: auto;
                max-width: 300px;
            }
        </style>
    </head>

    <body class="dark-mode">
        <div class="box">
            <div class="nav-header">
                <div style="display:flex; align-items:center; gap:15px;">
                    <a href="file_manager.php" class="btn btn-secondary" style="width: auto;">⬅ Zurück</a>
                    <div style="font-size: 12px; opacity: 0.7;">👤 Admin: <b><?= htmlspecialchars($_SESSION['admin_user'] ?? 'Unbekannt') ?></b></div>
                </div>
                <button onclick="toggleDarkMode()" class="btn btn-info" id="themeToggle" style="width: auto;">🌗 Tag/Nacht</button>
            </div>
            <h1>⚙️ Admin-Einstellungen</h1>

        <?php if ($success): ?>
            <div class="alert alert-success" id="statusMsg"><?= $success ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger" id="statusMsg"><?= $error ?></div>
        <?php endif; ?>

        <div class="section">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                <h2>👥 Administratoren</h2>
                <button onclick="showAddUser()" class="btn btn-success" style="width: auto;">➕ Neu</button>
            </div>
            <table class="user-list">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>2FA</th>
                        <th style="text-align:right;">Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($u = $users->fetch_assoc()): 
                        $has2fa = !empty($u['auth_secret']);
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($u['nutzername']) ?></td>
                            <td><?= $has2fa ? '✅' : '❌' ?></td>
                            <td style="text-align:right;">
                                <button onclick="showEditUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['nutzername']) ?>', <?= $has2fa ? 'true' : 'false' ?>)" class="btn btn-primary btn-small" style="width:auto; min-width:unset;">✏️</button>
                                <button onclick="deleteUser(<?= $u['id'] ?>, '<?= htmlspecialchars($u['nutzername']) ?>')" class="btn btn-danger btn-small" style="width:auto; min-width:unset;">🗑️</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <script>
            function showAddUser() {
                customModal({
                    title: '👤 Neuen Admin anlegen',
                    message: `
                        <form id="addForm" method="post" style="text-align:left;">
                            <input type="hidden" name="action" value="add_user">
                            <div class="field" style="margin-bottom:15px;">
                                <label>Benutzername</label>
                                <input type="text" name="username" required placeholder="z.B. admin" style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.2); color:white;">
                            </div>
                            <div class="field" style="margin-bottom:20px;">
                                <label>Passwort</label>
                                <div class="password-wrapper">
                                    <input type="password" name="password" id="pass_new_admin" required placeholder="Passwort" style="width:100%;">
                                    <button type="button" onclick="togglePassword('pass_new_admin', this)" class="toggle-password">👁️</button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success" style="width:100%;">Benutzer erstellen</button>
                        </form>
                    `
                });
            }

            function showEditUser(id, name, has2fa) {
                customModal({
                    title: '✏️ Benutzer bearbeiten: ' + name,
                    message: `
                        <form method="post" style="text-align:left;">
                            <input type="hidden" name="action" value="edit_user">
                            <input type="hidden" name="user_id" value="${id}">
                            
                            <div class="field" style="margin-bottom:15px;">
                                <label>Benutzername</label>
                                <input type="text" name="username" value="${name}" required style="width:100%; padding:10px; border-radius:8px; border:1px solid rgba(255,255,255,0.1); background:rgba(0,0,0,0.2); color:white;">
                            </div>
                            
                            <div class="field" style="margin-bottom:15px;">
                                <label>Neues Passwort (optional)</label>
                                <div class="password-wrapper">
                                    <input type="password" name="password" id="pass_edit_user" placeholder="Unverändert lassen..." style="width:100%;">
                                    <button type="button" onclick="togglePassword('pass_edit_user', this)" class="toggle-password">👁️</button>
                                </div>
                            </div>
                            
                            <div class="field" style="margin-bottom:20px; padding:15px; background:rgba(255,255,255,0.05); border-radius:10px;">
                                <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                                    <input type="checkbox" name="setup_2fa" value="1" ${has2fa ? 'checked disabled' : ''}>
                                    <span>🔐 2-Faktor-Authentisierung (2FA)</span>
                                </label>
                                ${has2fa ? `
                                    <p style="font-size:11px; color:#10b981; margin-top:5px;">Aktiviert. <a href="#" onclick="disable2FA(${id}, '${name}')" style="color:var(--danger); text-decoration:underline;">Hier deaktivieren</a></p>
                                ` : '<p style="font-size:11px; opacity:0.6; margin-top:5px;">Klick zum Aktivieren beim Speichern.</p>'}
                            </div>
                            
                            <button type="submit" class="btn btn-primary" style="width:100%;">Änderungen speichern</button>
                        </form>
                    `
                });
            }

            async function disable2FA(id, name) {
                if (confirm('Möchtest du 2FA für ' + name + ' wirklich deaktivieren?')) {
                    const f = document.createElement('form');
                    f.method = 'post';
                    f.innerHTML = `<input type="hidden" name="action" value="disable_2fa"><input type="hidden" name="user_id" value="${id}">`;
                    document.body.appendChild(f);
                    f.submit();
                }
            }

            async function deleteUser(id, name) {
                const confirmed = await customModal({
                    title: '🗑️ Benutzer löschen',
                    message: `Möchtest du den Benutzer <b>${name}</b> wirklich dauerhaft löschen?`,
                    type: 'confirm',
                    confirmText: 'Ja, löschen',
                    cancelText: 'Abbrechen'
                });
                if (confirmed) {
                    const f = document.createElement('form');
                    f.method = 'post';
                    f.innerHTML = `<input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="${id}">`;
                    document.body.appendChild(f);
                    f.submit();
                }
            }
        </script>

            <div class="section">
                <h2>🔑 Normaler Benutzerzugang</h2>
                <form method="post">
                    <input type="hidden" name="action" value="update_user_pass">
                    <label>Dateimanager-Passwort (Normalnutzer)</label>
                    <input type="password" name="user_pass" required placeholder="Neues Passwort">
                    <button type="submit" class="btn btn-primary">Speichern</button>
                </form>
            </div>

            <div class="section">
                <h2>🔐 Berechtigungen für Normalnutzer</h2>

                <form method="post"
                    style="border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 20px; margin-bottom: 20px;">
                    <input type="hidden" name="action" value="update_acl">
                    <h3>Globale Standardwerte</h3>
                    <p style="font-size: 12px; color: #94a3b8; margin-bottom: 15px;">Diese Regeln gelten, sofern keine
                        ordnerspezifische Regel existiert.</p>
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div class="perm-item"><label><input type="checkbox" name="can_delete" <?= defined('USER_CAN_DELETE') && USER_CAN_DELETE ? 'checked' : '' ?>> 🗑️ Löschen</label></div>
                        <div class="perm-item"><label><input type="checkbox" name="can_rename" <?= defined('USER_CAN_RENAME') && USER_CAN_RENAME ? 'checked' : '' ?>> 📄 Umbenennen</label></div>
                        <div class="perm-item"><label><input type="checkbox" name="can_upload" <?= defined('USER_CAN_UPLOAD') && USER_CAN_UPLOAD ? 'checked' : '' ?>> 📤 Upload</label></div>
                        <div class="perm-item"><label><input type="checkbox" name="can_create" <?= defined('USER_CAN_CREATE') && USER_CAN_CREATE ? 'checked' : '' ?>> ➕ Erstellen</label></div>
                    </div>
                    <button type="submit" class="btn btn-primary" style="margin-top:15px; width:auto;">Globale Rechte
                        speichern</button>
                </form>

                <h3>📁 Ordnerspezifische Regeln</h3>
                <form method="post"
                    style="margin-bottom: 20px; background: rgba(255,255,255,0.03); padding: 15px; border-radius: 8px;">
                    <input type="hidden" name="action" value="update_folder_acl">
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                        <div style="grid-column: span 2;">
                            <label>Ordner auswählen oder Pfad eingeben</label>
                            <div style="display:flex; gap:10px;">
                                <select onchange="this.nextElementSibling.value = this.value" style="width:200px;">
                                    <option value="">-- Wählen --</option>
                                    <?php foreach ($availableFolders as $fold): ?>
                                        <option value="<?= htmlspecialchars($fold) ?>"><?= htmlspecialchars($fold) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="text" name="folder_path"
                                    placeholder="Pfad manuell eingeben (falls verschachtelt)" required>
                            </div>
                            <p style="font-size:11px; opacity:0.6; margin-top:5px;">💡 Der Pfad muss relativ zum Root sein,
                                z.B. <code>projekte/kunden</code></p>
                        </div>
                        <div class="perm-item"><label><input type="checkbox" name="can_delete"> 🗑️ Löschen erlauben</label>
                        </div>
                        <div class="perm-item"><label><input type="checkbox" name="can_rename"> 📄 Umbenennen
                                erlauben</label></div>
                        <div class="perm-item"><label><input type="checkbox" name="can_upload"> 📤 Upload erlauben</label>
                        </div>
                        <div class="perm-item"><label><input type="checkbox" name="can_create"> ➕ Erstellen erlauben</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success" style="width:auto;">Regel hinzufügen /
                        aktualisieren</button>
                </form>

                <table class="user-list">
                    <thead>
                        <tr style="font-size: 11px; opacity: 0.6;">
                            <th>Ordnerpfad</th>
                            <th style="text-align:center;">Del</th>
                            <th style="text-align:center;">Ren</th>
                            <th style="text-align:center;">Up</th>
                            <th style="text-align:center;">Cre</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $fPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];
                        if (empty($fPerms)): ?>
                            <tr>
                                <td colspan="6" style="text-align:center; opacity:0.5; padding:20px;">Keine spezifischen Regeln
                                    definiert.</td>
                            </tr>
                        <?php else:
                            foreach ($fPerms as $p => $r): ?>
                                <tr>
                                    <td style="font-family:monospace; font-size:12px;"><?= htmlspecialchars($p) ?></td>
                                    <td style="text-align:center;"><?= $r['delete'] ? '✅' : '❌' ?></td>
                                    <td style="text-align:center;"><?= $r['rename'] ? '✅' : '❌' ?></td>
                                    <td style="text-align:center;"><?= $r['upload'] ? '✅' : '❌' ?></td>
                                    <td style="text-align:center;"><?= $r['create'] ? '✅' : '❌' ?></td>
                                    <td style="text-align:right;">
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="action" value="delete_folder_acl">
                                            <input type="hidden" name="folder_path" value="<?= htmlspecialchars($p) ?>">
                                            <button type="submit" class="btn btn-danger btn-small"
                                                style="width:auto; min-width:unset;">🗑️</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach;
                        endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="section">
                <h2>🖼️ Design & Hintergründe</h2>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_bg">
                    <label>Bereich auswählen</label>
                    <select name="bg_type">
                        <option value="web">Web-Login (Besucher)</option>
                        <option value="fm">Filemanager-Login</option>
                    </select>
                    <label>Neues Bild hochladen</label>
                    <label class="custom-file-upload">
                        <input type="file" name="bg_file" accept="image/*" required
                            onchange="this.parentElement.querySelector('span').innerText = this.files[0].name"
                            style="display:none;">
                        <span>📁 Datei auswählen...</span>
                    </label>
                    <button type="submit" class="btn btn-success" style="margin-top:15px;">Aktualisieren</button>
                </form>
            </div>

            <div class="section">
                <h2 style="display:flex; align-items:center; gap:10px;">
                    🔧 Rechteverwaltung (chmod)
                    <button class="btn btn-info btn-small" onclick="showChmodInfo()"
                        style="width:30px; height:30px; border-radius:50%; padding:0; min-width:unset;"
                        title="Hilfe">ⓘ</button>
                </h2>
                <p style="font-size:13px; opacity:0.7;">Wähle eine Datei im Dateimanager aus, um die Rechte anzupassen.</p>
                <form onsubmit="return handleChmod(event)" style="display:flex; gap:10px;">
                    <input type="text" id="chmodPath" placeholder="Pfad (z.B. config/security.php)">
                    <input type="text" id="chmodMode" placeholder="Mode (z.B. 0644)" style="width:100px;">
                    <button type="submit" class="btn btn-primary">Anwenden</button>
                </form>
            </div>

            <div class="section" style="border:none;">
                <h2>ℹ️ System-Info & Wartung</h2>
                <p style="font-size:13px; opacity:0.7;">
                    PHP-Version: <code><?= phpversion() ?></code><br>
                    Root: <code><?= htmlspecialchars(realpath(__DIR__ . '/..')) ?></code>
                </p>
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <form method="post">
                        <input type="hidden" name="action" value="php_update">
                        <button type="submit" class="btn btn-primary" style="width:200px;">🚀 Auf PHP-Update prüfen</button>
                    </form>
                    <form method="post">
                        <input type="hidden" name="action" value="cleanup_install">
                        <button type="submit" class="btn btn-danger" style="width:200px; padding:12px;"
                            onclick="return confirm('Sicher? Der /install Ordner wird unwiderruflich gelöscht.')">🧹
                            Installation bereinigen</button>
                    </form>
                </div>
                <p style="font-size:12px; color:#94a3b8; margin-top:15px;">
                    ⚠️ <b>Hinweis:</b> Der Ordner <code>config/</code> wird für die Sicherheitseinstellungen benötigt und
                    darf nicht gelöscht werden.
                </p>
            </div>
        </div>

        <script>
            function toggleDarkMode() {
                const isDark = document.body.classList.toggle('dark-mode');
                localStorage.setItem('darkMode', isDark ? 'true' : 'false');
            }

            if (localStorage.getItem('darkMode') === 'true') {
                document.body.classList.add('dark-mode');
            } else if (localStorage.getItem('darkMode') === 'false') {
                document.body.classList.remove('dark-mode');
            }

            function togglePassword(inputId, btn) {
                const input = document.getElementById(inputId);
                if (input.type === "password") {
                    input.type = "text";
                    btn.textContent = "👁️‍🗨️";
                } else {
                    input.type = "password";
                    btn.textContent = "👁️";
                }
            }


            function showChmodInfo() {
                customModal({
                    title: 'ⓘ chmod Expert-Guide',
                    message: `<div style="text-align:left; line-height:1.4; font-size:13px; max-height:400px; overflow-y:auto;">
                        <p>Die Rechte werden durch eine dreistellige Zahl (z.B. <b>755</b>) ausgedrückt:</p>
                        <div style="background:rgba(255,255,255,0.05); padding:10px; border-radius:8px; margin:10px 0;">
                            <b>Werte-Logik:</b><br>
                            • <b>4</b> = Lesen (Read)<br>
                            • <b>2</b> = Schreiben (Write)<br>
                            • <b>1</b> = Ausführen (Execute)
                        </div>
                        <p><b>Die Kombinationen (Summen):</b></p>
                        <ul style="padding-left:20px;">
                            <li><b>7</b> (4+2+1): Lesen, Schreiben & Ausführen (Vollzugriff)</li>
                            <li><b>6</b> (4+2): Lesen & Schreiben</li>
                            <li><b>5</b> (4+1): Lesen & Ausführen</li>
                            <li><b>4</b>: Nur Lesen</li>
                            <li><b>3</b> (2+1): Schreiben & Ausführen (selten)</li>
                            <li><b>2</b>: Nur Schreiben (selten)</li>
                            <li><b>1</b>: Nur Ausführen (z.B. für Verzeichnisse)</li>
                            <li><b>0</b>: Keinerlei Rechte</li>
                        </ul>
                        <p><b>Stellen-Bedeutung:</b><br>
                        1. Stelle: <b>Besitzer</b> (Du)<br>
                        2. Stelle: <b>Gruppe</b> (Andere Systemnutzer)<br>
                        3. Stelle: <b>Öffentlichkeit</b> (Alle anderen)</p>
                        <hr style="opacity:0.1; margin:10px 0;">
                        <p><i>💡 Im Dateimanager kannst du dies bequem über Checkboxen einstellen!</i></p>
                    </div>`
                });
            }

            // Auto-Hide Alerts nach 15s
            setTimeout(() => {
                const msg = document.getElementById('statusMsg');
                if (msg) msg.style.opacity = '0';
            }, 15000);

            async function handleChmod(e) {
                e.preventDefault();
                const path = document.getElementById('chmodPath').value;
                const mode = document.getElementById('chmodMode').value;
                const res = await fetch('api.php', {
                    method: 'POST',
                    body: JSON.stringify({ action: 'chmod', path, mode })
                });
                const data = await res.json();
                customModal({
                    title: data.success ? '✅ Erfolg' : '❌ Fehler',
                    message: data.success || data.error
                });
            }
        </script>
    </body>

</html>