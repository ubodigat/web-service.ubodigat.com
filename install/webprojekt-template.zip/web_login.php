<?php
declare(strict_types=1);

/* =========================================================
   🔐 KONFIGURATION LADEN
   ========================================================= */
$securityFile = __DIR__ . '/config/security.php';

// Falls Setup noch nicht lief, abbrechen
if (!file_exists($securityFile)) {
    http_response_code(503);
    die('❌ System noch nicht eingerichtet. Bitte erst das Setup ausführen.');
}
require_once $securityFile;

/* =========================================================
   ⚙️ LOGIK-PRÜFUNG
   ========================================================= */

// 1. Ist der Schutz überhaupt aktiviert?
// Falls nein: Direkt weiter zur Startseite (kein Login nötig).
if (!defined('WEB_ACCESS_ENABLED') || WEB_ACCESS_ENABLED !== true) {
    header('Location: ./');
    exit;
}

// 2. Ist der Nutzer schon eingeloggt?
// Falls ja: Direkt weiter.
if (!empty($_COOKIE['web_access']) && $_COOKIE['web_access'] === '1') {
    header('Location: ./');
    exit;
}

/* =========================================================
   📩 LOGIN VERARBEITUNG
   ========================================================= */
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputPass = $_POST['password'] ?? '';

    // Passwort gegen den Hash aus security.php prüfen
    if (defined('WEB_ACCESS_HASH') && password_verify($inputPass, WEB_ACCESS_HASH)) {
        
        // ✅ Login erfolgreich: Cookie setzen
        setcookie(
            'web_access',
            '1',
            [
                'expires'  => time() + 86400, // Gültig für 24 Stunden
                'path'     => '/',            // Gültig für die gesamte Domain
                'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'), // Nur über HTTPS senden (wenn verfügbar)
                'httponly' => true,           // JavaScript kann nicht zugreifen (XSS-Schutz)
                'samesite' => 'Strict'        // Schutz vor CSRF
            ]
        );

        // Weiterleitung zur Startseite (oder Projektseite)
        header('Location: ./');
        exit;
    } else {
        // ❌ Login fehlgeschlagen
        $error = 'Falsches Passwort';
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>🔐 Zugriff geschützt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --bg-grad: radial-gradient(circle at top, #0f172a, #020617);
            --card-bg: rgba(15, 23, 42, 0.95);
            --border: rgba(51, 65, 85, 0.5);
            --text: #e5e7eb;
            --input-bg: #020617;
            --accent: #38bdf8;
            --btn-grad: linear-gradient(135deg, #22c55e, #4ade80);
            --danger: #f87171;
        }
        body {
            margin: 0;
            min-height: 100vh;
            background: var(--bg-grad);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, sans-serif;
            color: var(--text);
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 16px;
            width: 100%;
            max-width: 380px;
            text-align: center;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
            border: 1px solid var(--border);
            backdrop-filter: blur(10px);
        }
        h2 { margin: 0 0 20px; font-size: 22px; }
        p { color: #94a3b8; margin-bottom: 24px; font-size: 15px; }
        
        input {
            width: 100%;
            box-sizing: border-box;
            padding: 14px;
            margin-bottom: 16px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--input-bg);
            color: var(--text);
            font-size: 16px;
            transition: border-color 0.2s;
        }
        input:focus { outline: none; border-color: var(--accent); }
        
        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            background: var(--btn-grad);
            color: #022c22;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: transform 0.1s;
        }
        button:active { transform: scale(0.98); }
        
        .error {
            margin-top: 16px;
            color: var(--danger);
            font-weight: 600;
            font-size: 14px;
            background: rgba(248, 113, 113, 0.1);
            padding: 10px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>🔐 Geschützter Bereich</h2>
    <p>Bitte geben Sie das Webseiten-Passwort ein.</p>
    
    <form method="post">
        <input type="password" name="password" placeholder="Passwort" required autofocus>
        <button type="submit">🔓 Freischalten</button>
        
        <?php if ($error): ?>
            <div class="error">⚠️ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </form>
</div>

</body>
</html>