<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration & Sicherheit laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    die('❌ Konfigurationsdateien fehlen. Bitte Setup ausführen.');
}
require_once $securityFile;
require_once $configFile;

// 2. Variablen definieren
$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';
// Timeout aus Security-Config oder Standard 30 Min
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

// 3. Zugriffsprüfung (Session UND Cookie für .htaccess Konsistenz)
if (
    (empty($_SESSION[$session_key]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookie_name])
) {
    $url = urlencode($_SERVER['REQUEST_URI']);
    header("Location: login_filemanager.php?redirect=$url");
    exit;
}

// 4. Timeout prüfen
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    // Timeout abgelaufen -> Universal-Logout
    header("Location: logout_admin.php?timeout=1");
    exit;
}

// 5. Keep-Alive: Session & Cookie aktualisieren
$_SESSION['filemanager_last_action'] = time();

// WICHTIG: Cookie bei jeder Aktivität verlängern, 
// damit die .htaccess den User nicht blockiert, solange er aktiv ist.
setcookie(
    $cookie_name,
    '1',
    [
        'expires' => time() + $timeout,
        'path' => '/filemanager',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict'
    ]
);

// 6. Admin-Status & Pfad
$isAdmin = !empty($_SESSION['admin_access']);
$rootDir = realpath(__DIR__ . '/..');

// 7. Hintergrundbild
$bgPath = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
$bgStyle = "";
if ($bgPath !== '') {
    $bgStyle = "<style>
        body::before {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background-image: url('..{$bgPath}');
            background-size: cover;
            background-position: center;
            z-index: -2;
        }
        body::after {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(15, 23, 42, 0.75); /* dunkler Schleier */
            z-index: -1;
        }
    </style>";
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>📂 Web-Dateimanager</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=208" />
    <?= $bgStyle ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
    <script>
        require.config({
            paths: {
                vs: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.1/min/vs"
            }
        });
    </script>
</head>

<body>
    <div class="container">

        <div class="top-controls">
            <div style="display:flex; flex-direction:column;">
                <h2>📂 Web-Dateimanager</h2>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: -5px; margin-left: 2px; opacity: 0.8;">
                    👤 Angemeldet als: <b><?= $isAdmin ? ($_SESSION['admin_user'] ?? 'Administrator') : 'Master-User' ?></b>
                </div>
            </div>
            <div class="right-buttons">
                <?php if ($isAdmin): ?>
                    <button class="btn btn-info" onclick="window.location.href='admin_settings.php'">⚙️
                        Einstellungen</button>
                    <form method="post" action="logout_admin.php" style="display:inline;">
                        <button type="submit" class="btn btn-danger">🚪 Admin-Logout</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-warning" onclick="window.location.href='logout_admin.php'">🚪 Logout</button>
                    <button class="btn btn-info" onclick="window.location.href='admin_login.php'">🔐 Admin-Login</button>
                <?php endif; ?>
                <button class="dark-mode-toggle" onclick="toggleDarkMode()">🌙 Dark Mode</button>
            </div>
        </div>

        <div class="upload-box">
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="upload-row">
                    <label class="custom-upload">
                        📤 Datei auswählen
                        <input type="file" id="uploadFile" name="uploadFile" onchange="showFileName()" hidden>
                    </label>
                    <span id="selectedFileName" class="file-name">Keine Datei ausgewählt</span>
                    <button type="submit" class="btn btn-primary" id="uploadBtn">⬆️ Hochladen</button>
                </div>
            </form>
        </div>

        <div class="input-group">
            <input type="text" id="directoryPath" value="<?= htmlspecialchars($rootDir) ?>">
            <button id="aktualisieren" class="btn btn-success" onclick="loadFiles()">🔄 Aktualisieren</button>
        </div>

        <script>
            const inputPath = document.getElementById("directoryPath");
            const isAdmin = <?= $isAdmin ? "true" : "false" ?>;
            const basePath = "<?= addslashes($rootDir) ?>";  // Frontend-Pfadschutz
            if (!isAdmin) {
                inputPath.addEventListener("input", () => {
                    if (!inputPath.value.startsWith(basePath)) {
                        inputPath.value = basePath;
                    }
                });
                inputPath.addEventListener("keydown", function (e) {
                    const start = inputPath.selectionStart;
                    const baseLength = basePath.length;
                    if (start < baseLength) {
                        const allowed = ["ArrowRight", "ArrowDown", "End", "Tab"];
                        if (!allowed.includes(e.key)) {
                            e.preventDefault();
                            inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                        }
                    }
                });
                inputPath.addEventListener("click", function () {
                    const baseLength = basePath.length;
                    if (inputPath.selectionStart < baseLength) {
                        inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                    }
                });
            }
        </script>

        <div class="input-group" style="margin-bottom:10px;">
            <input type="text" id="newFileName" class="input-half" placeholder="Dateiname"><button id="createFileBtn"
                class="btn btn-primary" onclick="createFile()">➕ Datei erstellen</button>
        </div>

        <div class="input-group">
            <input type="text" id="newFolderName" class="input-half" placeholder="Ordnername"><button
                id="createFolderBtn" class="btn btn-secondary" onclick="createFolder()">📁 Ordner erstellen</button>
        </div>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th style="width: 30%;">Name</th>
                        <th style="width: 15%;">Status Normalnutzer</th>
                        <th style="width: 15%;">Typ</th>
                        <th style="width: 20%;">Letzte Änderung</th>
                        <th style="width: 20%; text-align: right;">Aktionen</th>
                    </tr>
                </thead>
                <tbody id="fileTable"></tbody>
            </table>
        </div>
    </div>

    <div id="editModal" class="edit-modal">
        <h3 id="editTitle">Datei bearbeiten</h3>
        <div id="editor-container">
            <div id="editor"></div>
        </div>
        <div class="modal-buttons">
            <button class="btn btn-danger" onclick="closeEditModal()">❌ Schließen</button>
            <button class="btn btn-success" onclick="saveFile()">💾 Speichern</button>
        </div>
    </div>

    <script src="script.js?v=209"></script>
    <script>
        // Initiale Admin/User-Logik aus PHP übernehmen
        window.isSystemAdmin = <?= json_encode(!empty($_SESSION['admin_access'])) ?>;

        function showFileName() {
            const input = document.getElementById('uploadFile');
            const label = document.getElementById('selectedFileName');
            label.textContent = input.files.length > 0 ? input.files[0].name : "Keine Datei ausgewählt";
        }

        function downloadFile() {
            const path = document.getElementById("directoryPath").value.trim();
            if (!path) {
                customModal({ title: '⚠️ Hinweis', message: 'Bitte wähle erst eine Datei oder einen Ordner aus.' });
                return;
            }
            const fileName = path.split("/").pop();
            const link = document.createElement('a');
            link.href = 'download.php?path=' + encodeURIComponent(path);
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>

</html>