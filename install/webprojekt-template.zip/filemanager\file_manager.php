<?php
declare(strict_types=1);
session_start();
header('Content-Type: text/html; charset=UTF-8');

// 1. Konfiguration & Sicherheit laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    header('Location: ../install/setup.php');
    exit;
}
require_once $securityFile;
require_once $configFile;

// 2. Variablen definieren
$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';
// Timeout aus Security-Config oder Standard 30 Min
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

// 3. Zugriffsprüfung (Session UND Cookie für .htaccess Konsistenz)
if (
    (empty($_SESSION[$session_key]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookie_name])
) {
    $url = urlencode($_SERVER['REQUEST_URI']);
    header("Location: login_filemanager.php?redirect=$url");
    exit;
}

// 4. Timeout prüfen
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    // Timeout abgelaufen -> Universal-Logout
    header("Location: logout_admin.php?timeout=1");
    exit;
}

// 5. Keep-Alive: Session & Cookie aktualisieren
$_SESSION['filemanager_last_action'] = time();

// WICHTIG: Cookie bei jeder Aktivität verlängern, 
// damit die .htaccess den User nicht blockiert, solange er aktiv ist.
setcookie(
    $cookie_name,
    '1',
    [
        'expires' => time() + $timeout,
        'path' => '/filemanager',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict'
    ]
);

// 6. Admin-Status & Pfad
$isAdmin = !empty($_SESSION['admin_access']);
$rootDir = realpath(__DIR__ . '/..');
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Web-Dateimanager</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=212" />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
    <script>
        require.config({
            paths: {
                vs: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.1/min/vs"
            }
        });
    </script>
</head>

<body>
    <div class="container">

        <div class="top-controls">
            <div style="display:flex; flex-direction:column;">
                <h2>📂 Web-Dateimanager</h2>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: -5px; margin-left: 2px; opacity: 0.8;">                    Angemeldet als: <b><?= $isAdmin ? ($_SESSION['admin_user'] ?? 'Administrator') : ($_SESSION['filemanager_user'] ?? 'Benutzer') ?></b>
                </div>
            </div>
            <div class="right-buttons">
                <?php if ($isAdmin): ?>
                    <button class="btn btn-info" onclick="window.location.href='admin_settings.php'">⚙️ Einstellungen</button>
                    <button class="btn btn-secondary" onclick="showTrashManager()">🗑️ Papierkorb</button>
                    <form method="post" action="logout_admin.php" style="display:inline;">
                        <button type="submit" class="btn btn-danger">🚪 Logout</button>
                    </form>
                <?php else: ?>
                    <button class="btn btn-secondary" onclick="showMyProfile()">👤 Konto</button>
                    <button class="btn btn-warning" onclick="window.location.href='logout_admin.php'">🚪 Logout</button>
                    <button class="btn btn-info" onclick="window.location.href='admin_login.php'">🔑 Admin-Login</button>
                <?php endif; ?>
                <button class="btn btn-secondary" onclick="toggleDarkMode()">🌙 Tag/Nacht</button>
            </div>
        </div>

        <div class="upload-box" id="dropZone">
            <form id="uploadForm" enctype="multipart/form-data" style="width: 100%;">
                <div class="upload-row" style="display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
                    <label class="custom-upload" style="border-radius: 24px; padding: 10px 20px; background: var(--primary); color: white; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: var(--transition);">📎 Datei auswählen<input type="file" id="uploadFile" name="uploadFile" onchange="showFileName()" hidden>
                    </label>
                    <span id="selectedFileName" class="file-name" style="flex-grow: 1; min-width: 150px; font-size: 14px; color: var(--text-muted);">Keine Datei ausgew&auml;hlt oder hier ablegen</span>
                    <button type="submit" class="btn btn-warning" id="uploadBtn" style="border-radius: 24px; padding: 10px 25px;">⬆️ Hochladen</button>
                </div>
                <div id="uploadProgressContainer" style="display: none; margin-top: 15px; background: rgba(0,0,0,0.2); border-radius: 12px; height: 10px; overflow: hidden; width: 100%;">
                    <div id="uploadProgressBar" style="height: 100%; width: 0%; background: var(--primary); transition: width 0.2s;"></div>
                </div>
            </form>
        </div>

        <div class="input-group search-group" style="margin-bottom: 15px;">
            <input type="text" id="searchInput" placeholder="Dateien suchen..." class="input-half" oninput="filterTable()">
        </div>

        <div class="input-group">
            <input type="text" id="directoryPath" value="<?= htmlspecialchars($rootDir) ?>">
            <button id="aktualisieren" class="btn btn-success" onclick="loadFiles()">🔄 Aktualisieren</button>
        </div>

        <script>
            const inputPath = document.getElementById("directoryPath");
            const isAdmin = <?= $isAdmin ? "true" : "false" ?>;
            const basePath = "<?= addslashes($rootDir) ?>";  // Frontend-Pfadschutz
            if (!isAdmin) {
                inputPath.addEventListener("input", () => {
                    if (!inputPath.value.startsWith(basePath)) {
                        inputPath.value = basePath;
                    }
                });
                inputPath.addEventListener("keydown", function (e) {
                    const start = inputPath.selectionStart;
                    const baseLength = basePath.length;
                    if (start < baseLength) {
                        const allowed = ["ArrowRight", "ArrowDown", "End", "Tab"];
                        if (!allowed.includes(e.key)) {
                            e.preventDefault();
                            inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                        }
                    }
                });
                inputPath.addEventListener("click", function () {
                    const baseLength = basePath.length;
                    if (inputPath.selectionStart < baseLength) {
                        inputPath.setSelectionRange(inputPath.value.length, inputPath.value.length);
                    }
                });
            }
        </script>

        <div class="input-group" style="margin-bottom:10px;">
            <input type="text" id="newFileName" class="input-half" placeholder="Dateiname"><button id="createFileBtn"
                class="btn btn-primary" onclick="createFile()">📄 Datei erstellen</button>
        </div>

        <div class="input-group">
            <input type="text" id="newFolderName" class="input-half" placeholder="Ordnername"><button
                id="createFolderBtn" class="btn btn-secondary" onclick="createFolder()">📁 Ordner erstellen</button>
        </div>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th data-sort-key="name" style="width: 25%; cursor:pointer;">Name</th>
                        <th data-sort-key="status" style="width: 15%; cursor:pointer;">Status Normalnutzer</th>
                        <th data-sort-key="type" style="width: 10%; cursor:pointer;">Typ</th>
                        <th data-sort-key="size" style="width: 15%; cursor:pointer;">Gr&ouml;&szlig;e</th>
                        <th data-sort-key="date" style="width: 15%; cursor:pointer;">Letzte &Auml;nderung</th>
                        <th style="width: 20%;">Aktionen</th>
                    </tr>
                </thead>
                <tbody id="fileTable"></tbody>
            </table>
        </div>
    </div>

    <div id="editModalOverlay" class="modal-overlay" style="display:none;" onclick="closeEditModal()"></div>
    <div id="editModal" class="edit-modal">
        <button class="modal-close" onclick="closeEditModal()" title="Schlie&szlig;en">x</button>
        <h3 id="editTitle" style="margin-bottom: 15px; padding-right: 40px;">Datei bearbeiten</h3>
        <div id="editor-container">
            <div id="editor"></div>
        </div>
        <div class="modal-buttons">
            <button class="btn btn-success" onclick="saveFile()">💾 Speichern</button>
        </div>
    </div>

    <script src="script.js?v=216"></script>
    <script>
        // Initiale Admin/User-Logik aus PHP uebernehmen
        window.isSystemAdmin = <?= json_encode(!empty($_SESSION['admin_access'])) ?>;

        function showFileName() {
            const input = document.getElementById('uploadFile');
            const label = document.getElementById('selectedFileName');
            label.textContent = input.files.length > 0 ? input.files[0].name : "Keine Datei ausgew\u00e4hlt";
        }

        function downloadFile() {
            const path = document.getElementById("directoryPath").value.trim();
            if (!path) {
                customModal({ title: 'Hinweis', message: 'Bitte w&auml;hle erst eine Datei oder einen Ordner aus.' });
                return;
            }
            const fileName = path.split("/").pop();
            const link = document.createElement('a');
            link.href = 'download.php?path=' + encodeURIComponent(path);
            link.download = fileName;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>

</html>
