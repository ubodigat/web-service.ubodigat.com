﻿<?php
declare(strict_types=1);
session_start();

$securityFile = __DIR__ . '/../config/security.php';
$configFile   = __DIR__ . '/config.php';
if (!file_exists($securityFile) || !file_exists($configFile)) { die('Konfiguration fehlt.'); }
require_once $securityFile;
require_once $configFile;

$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

if ((empty($_SESSION[$session_key]) && empty($_SESSION['admin_access'])) || empty($_COOKIE[$cookie_name])) {
    header('Location: login_filemanager.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
}
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    header('Location: logout_admin.php?timeout=1'); exit;
}
$_SESSION['filemanager_last_action'] = time();
setcookie($cookie_name,'1',['expires'=>time()+$timeout,'path'=>'/filemanager','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Strict']);

$isAdmin = !empty($_SESSION['admin_access']);
$rootDir = realpath(__DIR__ . '/..');

$bgPath  = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
$bgExtra = ($bgPath !== '') ? "<style>body::before{background-image:url('../{$bgPath}');background-size:cover;background-position:center;}</style>" : '';
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Web-Dateimanager</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=300"/>
    <?= $bgExtra ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js"></script>
    <script>require.config({paths:{vs:"https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.1/min/vs"}});</script>
</head>
<body class="dark-mode">
<div class="container">

    <div class="top-controls">
        <div style="display:flex;flex-direction:column;">
            <h2>Web-Dateimanager</h2>
            <div style="font-size:11px;color:var(--text-muted);margin-top:-5px;opacity:0.8;">
                Angemeldet als: <b><?= $isAdmin ? htmlspecialchars($_SESSION['admin_user'] ?? 'Administrator') : 'Master-User' ?></b>
            </div>
        </div>
        <div class="right-buttons">
            <?php if ($isAdmin): ?>
                <button class="btn btn-info" onclick="location.href='admin_settings.php'">Einstellungen</button>
                <form method="post" action="logout_admin.php" style="display:inline;">
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
            <?php else: ?>
                <button class="btn btn-warning" onclick="location.href='logout_admin.php'">Logout</button>
                <button class="btn btn-info"    onclick="location.href='admin_login.php'">Admin-Login</button>
            <?php endif; ?>
            <button class="btn btn-secondary" onclick="toggleDarkMode()">Tag/Nacht</button>
        </div>
    </div>

    <div class="upload-box" id="uploadDropZone">
        <form id="uploadForm" enctype="multipart/form-data">
            <div class="upload-row">
                <label class="custom-upload-btn">
                    Datei auswaehlen
                    <input type="file" id="uploadFile" name="uploadFile" multiple hidden>
                </label>
                <span id="selectedFileName" class="file-name">Keine Datei ausgewaehlt - oder hier ablegen</span>
                <button type="submit" class="btn btn-warning upload-submit-btn">Hochladen</button>
            </div>
            <div id="upload-progress-wrap" style="display:none;margin-top:12px;">
                <div class="progress-track"><div id="upload-progress-bar" class="progress-fill" style="width:0%"></div></div>
                <div id="upload-progress-label" style="font-size:12px;text-align:center;margin-top:5px;color:var(--text-muted);">0 %</div>
            </div>
        </form>
        <div class="drop-overlay">Datei loslassen zum Hochladen</div>
    </div>

    <div class="input-group">
        <input type="text" id="directoryPath" value="<?= htmlspecialchars($rootDir) ?>">
        <button class="btn btn-success" onclick="loadFiles()">Aktualisieren</button>
    </div>

    <div class="input-group" style="margin-bottom:10px;">
        <input type="text" id="searchInput" placeholder="In aktuellem Ordner suchen..." oninput="filterFiles(this.value)">
        <button class="btn btn-secondary" onclick="filterFiles('');document.getElementById('searchInput').value='';">X</button>
    </div>

    <div class="input-group" style="margin-bottom:10px;">
        <input type="text" id="newFileName" placeholder="Dateiname">
        <button class="btn btn-primary" onclick="createFile()">Datei erstellen</button>
    </div>
    <div class="input-group" style="margin-bottom:20px;">
        <input type="text" id="newFolderName" placeholder="Ordnername">
        <button class="btn btn-secondary" onclick="createFolder()">Ordner erstellen</button>
    </div>

    <div class="table-responsive">
        <table id="fileTableContainer">
            <thead>
                <tr>
                    <th style="width:25%;">Name</th>
                    <th style="width:10%;">Status</th>
                    <th style="width: 8%;">Typ</th>
                    <th style="width:10%;">Groesse</th>
                    <th style="width:15%;">Letzte Aenderung</th>
                    <th style="width:32%;text-align:right;">Aktionen</th>
                </tr>
            </thead>
            <tbody id="fileTable"></tbody>
        </table>
    </div>
</div>

<div id="editModalOverlay" class="edit-modal-overlay" onclick="closeEditModal()"></div>
<div id="editModal" class="edit-modal">
    <div class="edit-modal-header">
        <h3 id="editTitle" style="margin:0;flex:1;">Datei bearbeiten</h3>
        <span style="font-size:12px;color:var(--text-muted);margin-right:auto;padding-left:10px;">Strg+S speichert</span>
        <button class="btn btn-danger"  onclick="closeEditModal()">Schliessen</button>
        <button class="btn btn-success" onclick="saveFile()" style="margin-left:8px;">Speichern</button>
    </div>
    <div id="editor-container"><div id="editor"></div></div>
</div>

<script src="script.js?v=300"></script>
<script>
    window.isSystemAdmin = <?= json_encode($isAdmin) ?>;
    window.basePath      = <?= json_encode($rootDir) ?>;

    document.getElementById('uploadFile').addEventListener('change', function() {
        const lbl = document.getElementById('selectedFileName');
        lbl.textContent = this.files.length === 0 ? 'Keine Datei ausgewaehlt' :
                          this.files.length === 1 ? this.files[0].name :
                          this.files.length + ' Dateien ausgewaehlt';
    });
</script>
</body>
</html>