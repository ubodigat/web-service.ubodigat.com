<?php
declare(strict_types=1);
session_start();

$security = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';
if (!file_exists($security) || !file_exists($configFile)) {
    header('Location: ../install/setup.php');
    exit;
}
require_once $security;
require_once $configFile;
require_once __DIR__ . '/fm_common.php';

$bgPath = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
if ($bgPath !== '') {
    $rootUrlPath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
    $bgUrl = $rootUrlPath . '/' . ltrim($bgPath, '/');
    $bg = "background-image:url('" . htmlspecialchars($bgUrl) . "') !important; background-size:cover !important; background-position:center !important; background-repeat:no-repeat !important; background-attachment:fixed !important;";
} else {
    $bg = "background:radial-gradient(circle at top,#0f172a,#020617);";
}


$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';

function doLogout(string $cookie_name): void
{
    session_unset();
    session_destroy();
    setcookie($cookie_name, '', time() - 3600, '/filemanager');
}

if (isset($_SESSION[$session_key]) && $_SESSION[$session_key] === true) {
    if (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) {
        $last = (int) ($_SESSION['filemanager_last_action'] ?? 0);
        if ($last > 0 && (time() - $last) > FILEMANAGER_TIMEOUT) {
            doLogout($cookie_name);
        } else {
            $_SESSION['filemanager_last_action'] = time();
        }
    } else {
        $_SESSION['filemanager_last_action'] = time();
    }
}

if (
    isset($_SESSION[$session_key]) &&
    $_SESSION[$session_key] === true &&
    isset($_COOKIE[$cookie_name]) &&
    $_COOKIE[$cookie_name] === '1'
) {
    header('Location: file_manager.php');
    exit;
}

$error = '';
$showOTP = false;

// Hilfsfunktion: Session-Variablen setzen und einloggen
function doLogin(string $sessionKey, string $cookieName, int $userId, string $user, int $isAdminUser): void
{
    session_regenerate_id(true);
    $_SESSION[$sessionKey] = true;
    $_SESSION['filemanager_last_action'] = time();
    $_SESSION['filemanager_user'] = $user;
    $_SESSION['filemanager_user_id'] = $userId;
    $_SESSION['filemanager_user_role'] = ($isAdminUser === 1) ? 'admin' : 'user';
    $_SESSION['admin_access'] = ($isAdminUser === 1);
    $_SESSION['admin_user'] = $user;

    $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
        ? time() + FILEMANAGER_TIMEOUT
        : time() + 86400;

    setcookie($cookieName, '1', [
        'expires'  => $cookieExpires,
        'path'     => '/filemanager',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $step = $_POST['step'] ?? 'login';
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    // ── Schritt 2: OTP-Prüfung (Passwort wurde bereits in Schritt 1 verifiziert) ──
    if ($step === '2fa' && !empty($_SESSION['pending_2fa_uid'])) {
        $otp        = trim($_POST['otp_code'] ?? '');
        $pendingUid = (int)$_SESSION['pending_2fa_uid'];
        $pendingTs  = (int)($_SESSION['pending_2fa_ts'] ?? 0);

        if ($pendingTs > 0 && (time() - $pendingTs) > 300) {
            unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_ts']);
            $error = '❌ Zeitüberschreitung. Bitte erneut anmelden.';
        } else {
            try {
                $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
                $stmt = $db->prepare("SELECT id, nutzername, auth_secret, is_admin FROM benutzer WHERE id = ? LIMIT 1");
                $stmt->bind_param('i', $pendingUid);
                $stmt->execute();
                $stmt->bind_result($userId, $user, $secret, $isAdminUser);

                if ($stmt->fetch()) {
                    if (verifyTOTP($secret, $otp)) {
                        unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_ts']);
                        doLogin($session_key, $cookie_name, (int)$userId, (string)$user, (int)$isAdminUser);
                        if ($logDb = fm_open_db()) {
                            fm_log_action($logDb, 'user_login', '', 'Anmeldung erfolgreich (2FA)');
                            $logDb->close();
                        }
                        header('Location: file_manager.php');
                        exit;
                    } else {
                        if ($logDb = fm_open_db()) {
                            fm_log_action($logDb, 'login_failed', '', '2FA-Code ungültig', 'failure');
                            $logDb->close();
                        }
                        $error = '❌ Ungültiger 2FA-Code. Bitte erneut versuchen.';
                        $showOTP = true;
                    }
                } else {
                    unset($_SESSION['pending_2fa_uid'], $_SESSION['pending_2fa_ts']);
                    $error = '❌ Sitzungsfehler – bitte erneut anmelden.';
                }
                $stmt->close();
                $db->close();
            } catch (Throwable $e) {
                $error = '❌ Datenbankfehler';
            }
        }

    // ── Schritt 1: Passwort-Prüfung ──────────────────────────────────────────────
    } else {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';

        if ($user !== '' && $pass !== '') {
            try {
                $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
                fm_ensure_schema($db);

                $stmt = $db->prepare("SELECT id, passwort, auth_secret, is_admin FROM benutzer WHERE nutzername = ? LIMIT 1");
                $stmt->bind_param('s', $user);
                $stmt->execute();
                $stmt->bind_result($userId, $hash, $secret, $isAdminUser);

                if ($stmt->fetch() && password_verify($pass, $hash)) {
                    if (!empty($secret)) {
                        // 2FA erforderlich – Benutzer-ID in Session merken
                        $_SESSION['pending_2fa_uid'] = (int)$userId;
                        $_SESSION['pending_2fa_ts']  = time();
                        $showOTP = true;
                    } else {
                        // Kein 2FA – direkt einloggen
                        doLogin($session_key, $cookie_name, (int)$userId, (string)$user, (int)$isAdminUser);
                        if ($logDb = fm_open_db()) {
                            fm_log_action($logDb, 'user_login', '', 'Anmeldung erfolgreich');
                            $logDb->close();
                        }
                        header('Location: file_manager.php');
                        exit;
                    }
                } else {
                    if ($logDb = fm_open_db()) {
                        fm_log_action($logDb, 'login_failed', '', 'Zugangsdaten falsch', 'failure');
                        $logDb->close();
                    }
                    $error = '❌ Ungültige Zugangsdaten';
                }
                $stmt->close();
                $db->close();
            } catch (Throwable $e) {
                $error = '❌ Datenbankfehler';
            }
        } else {
            $error = '❌ Bitte Benutzername und Passwort eingeben';
        }
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Filemanager Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --primary: #10b981;
            --primary-hover: #059669;
            --bg: #020617;
            --card-bg: rgba(15, 23, 42, 0.8);
            --border: rgba(255, 255, 255, 0.1);
            --text: #f8fafc;
            --text-muted: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: var(--text);
            padding: 20px;
            overflow: hidden;
            background: #020617;
            position: relative;
        }

        .bg-blur {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            <?= $bg ?>
            filter: blur(7px);
            -webkit-filter: blur(7px);
            transform: scale(1.05);
            z-index: 1;
            pointer-events: none;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.6s ease-out;
            position: relative;
            z-index: 2;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo-container {
            margin-bottom: 24px;
        }

        .logo {
            width: 140px;
            filter: drop-shadow(0 0 10px rgba(16, 185, 129, 0.3));
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: -0.025em;
        }

        p.subtitle {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 32px;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-muted);
            margin-left: 4px;
        }

        .input-wrapper {
            position: relative;
        }

        input {
            width: 100%;
            padding: 14px 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: white;
            font-size: 15px;
            transition: all 0.2s;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(0, 0, 0, 0.4);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }

        .toggle-password:hover {
            color: white;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: #064e3b;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 12px;
        }

        .btn-login:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .error-msg {
            margin-top: 16px;
            padding: 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 10px;
            color: #f87171;
            font-size: 14px;
            font-weight: 500;
        }

        .footer-note {
            margin-top: 32px;
            font-size: 12px;
            color: var(--text-muted);
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <div class="bg-blur"></div>
    <div class="login-card">
        <div class="logo-container">
            <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
        </div>

        <h2>Filemanager-Zugriff</h2>
        <p class="subtitle">Willkommen! Bitte melde dich mit Benutzername und Passwort an.</p>

        <?php if (!empty($showOTP)): ?>
        <!-- Schritt 2: Nur OTP-Code eingeben, Passwort bereits verifiziert -->
        <form method="post">
            <input type="hidden" name="step" value="2fa">
            <div style="text-align:center; margin-bottom:24px;">
                <div style="font-size:36px; margin-bottom:8px;">🔐</div>
                <div style="font-size:15px; font-weight:600; margin-bottom:4px;">Zwei-Faktor-Authentifizierung</div>
                <div style="font-size:13px; color:var(--text-muted);">Gib den Code aus deiner Authenticator-App ein.</div>
            </div>
            <div class="input-group">
                <label>Code (6 Stellen)</label>
                <div class="input-wrapper">
                    <input type="text" name="otp_code" placeholder="000000" inputmode="numeric"
                        autocomplete="one-time-code" autofocus required maxlength="6"
                        style="text-align:center; letter-spacing:8px; font-size:24px; padding:14px;">
                </div>
            </div>
            <button type="submit" class="btn-login">🔑 Bestätigen</button>
            <?php if ($error): ?>
                <div class="error-msg"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <div style="margin-top:16px; text-align:center;">
                <a href="login_filemanager.php" style="color:var(--text-muted); font-size:13px; text-decoration:none;">← Zurück zur Anmeldung</a>
            </div>
        </form>
        <?php else: ?>
        <!-- Schritt 1: Benutzername + Passwort -->
        <form method="post">
            <input type="hidden" name="step" value="login">
            <div class="input-group">
                <label>Benutzername</label>
                <div class="input-wrapper">
                    <input type="text" name="username" id="username" placeholder="Benutzername" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
            </div>
            <div class="input-group">
                <label>Passwort</label>
                <div class="input-wrapper">
                    <input type="password" name="password" id="password" placeholder="••••••••" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('password', this)" tabindex="-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn-login">Einloggen</button>
            <?php if ($error): ?>
                <div class="error-msg"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
        </form>
        <?php endif; ?>

        <div style="margin-top: 25px; text-align: center;">
            <a href="../" style="color: var(--primary); text-decoration: none; font-size: 14px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">
                <span>⬅️</span> Zurück zur Startseite
            </a>
        </div>

        <div class="footer-note">
            Benutzer werden in der Datenbank verwaltet.
        </div>
    </div>

    <script>
        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            const isPassword = input.type === "password";
            input.type = isPassword ? "text" : "password";

            // Icon tauschen
            btn.innerHTML = isPassword
                ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
                : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
        }
    </script>
</body>

</html>
