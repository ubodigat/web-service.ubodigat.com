<?php
declare(strict_types=1);
session_start();

$security = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';
if (!file_exists($security) || !file_exists($configFile)) {
    header('Location: ../install/setup.php');
    exit;
}
require_once $security;
require_once $configFile;
require_once __DIR__ . '/fm_common.php';

$bgPath = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
if ($bgPath !== '') {
    $rootUrlPath = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
    $bgUrl = $rootUrlPath . '/' . ltrim($bgPath, '/');
    $bg = "background-image:url('" . htmlspecialchars($bgUrl) . "') !important; background-size:cover !important; background-position:center !important; background-repeat:no-repeat !important; background-attachment:fixed !important;";
} else {
    $bg = "background:radial-gradient(circle at top,#0f172a,#020617);";
}


$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';

function doLogout(string $cookie_name): void
{
    session_unset();
    session_destroy();
    setcookie($cookie_name, '', time() - 3600, '/filemanager');
}

if (isset($_SESSION[$session_key]) && $_SESSION[$session_key] === true) {
    if (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) {
        $last = (int) ($_SESSION['filemanager_last_action'] ?? 0);
        if ($last > 0 && (time() - $last) > FILEMANAGER_TIMEOUT) {
            doLogout($cookie_name);
        } else {
            $_SESSION['filemanager_last_action'] = time();
        }
    } else {
        $_SESSION['filemanager_last_action'] = time();
    }
}

if (
    isset($_SESSION[$session_key]) &&
    $_SESSION[$session_key] === true &&
    isset($_COOKIE[$cookie_name]) &&
    $_COOKIE[$cookie_name] === '1'
) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    $otp = trim($_POST['otp_code'] ?? '');

    if ($user !== '' && $pass !== '') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            fm_ensure_schema($db);

            $stmt = $db->prepare("SELECT id, passwort, auth_secret, is_admin FROM benutzer WHERE nutzername = ? LIMIT 1");
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($userId, $hash, $secret, $isAdminUser);

            if ($stmt->fetch() && password_verify($pass, $hash)) {
                $has2FA = !empty($secret);
                if ($has2FA && $otp === '') {
                    $showOTP = true;
                } else {
                    $otpValid = true;
                    if ($has2FA) {
                        $otpValid = verifyTOTP($secret, $otp);
                    }

                    if ($otpValid) {
                        session_regenerate_id(true);
                        $_SESSION[$session_key] = true;
                        $_SESSION['filemanager_last_action'] = time();
                        $_SESSION['filemanager_user'] = $user;
                        $_SESSION['filemanager_user_id'] = (int) $userId;
                        $_SESSION['filemanager_user_role'] = ((int) $isAdminUser === 1) ? 'admin' : 'user';
                        $_SESSION['admin_access'] = ((int) $isAdminUser === 1);
                        $_SESSION['admin_user'] = $user;

                        $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
                            ? time() + FILEMANAGER_TIMEOUT
                            : time() + 86400;

                        setcookie(
                            $cookie_name,
                            '1',
                            [
                                'expires' => $cookieExpires,
                                'path' => '/filemanager',
                                'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                                'httponly' => true,
                                'samesite' => 'Strict',
                            ]
                        );

                        header('Location: file_manager.php');
                        exit;
                    } else {
                        $error = '❌ Ungültiger 2FA-Code';
                        $showOTP = true;
                    }
                }
            } elseif (defined('FILEMANAGER_ACCESS_HASH') && password_verify($pass, FILEMANAGER_ACCESS_HASH)) {
                session_regenerate_id(true);
                $_SESSION[$session_key] = true;
                $_SESSION['filemanager_last_action'] = time();
                $_SESSION['filemanager_user'] = $user !== '' ? $user : 'Legacy-User';
                $_SESSION['filemanager_user_role'] = 'user';
                $_SESSION['admin_access'] = false;

                $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
                    ? time() + FILEMANAGER_TIMEOUT
                    : time() + 86400;

                setcookie(
                    $cookie_name,
                    '1',
                    [
                        'expires' => $cookieExpires,
                        'path' => '/filemanager',
                        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                        'httponly' => true,
                        'samesite' => 'Strict',
                    ]
                );

                header('Location: file_manager.php');
                exit;
            } else {
                $error = '❌ Ungültige Zugangsdaten';
            }

            $stmt->close();
            $db->close();
        } catch (Throwable $e) {
            if (defined('FILEMANAGER_ACCESS_HASH') && password_verify($pass, FILEMANAGER_ACCESS_HASH)) {
                session_regenerate_id(true);
                $_SESSION[$session_key] = true;
                $_SESSION['filemanager_last_action'] = time();
                $_SESSION['filemanager_user'] = $user !== '' ? $user : 'Legacy-User';
                $_SESSION['filemanager_user_role'] = 'user';
                $_SESSION['admin_access'] = false;

                $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
                    ? time() + FILEMANAGER_TIMEOUT
                    : time() + 86400;

                setcookie(
                    $cookie_name,
                    '1',
                    [
                        'expires' => $cookieExpires,
                        'path' => '/filemanager',
                        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                        'httponly' => true,
                        'samesite' => 'Strict',
                    ]
                );

                header('Location: file_manager.php');
                exit;
            }

            $error = '❌ Datenbankfehler';
        }
    } else {
        $error = '❌ Bitte Benutzername und Passwort eingeben';
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Filemanager Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --primary: #10b981;
            --primary-hover: #059669;
            --bg: #020617;
            --card-bg: rgba(15, 23, 42, 0.8);
            --border: rgba(255, 255, 255, 0.1);
            --text: #f8fafc;
            --text-muted: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: var(--text);
            padding: 20px;
            overflow: hidden;
            background: #020617;
            position: relative;
        }

        .bg-blur {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            <?= $bg ?>
            filter: blur(7px);
            -webkit-filter: blur(7px);
            transform: scale(1.05);
            z-index: 1;
            pointer-events: none;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.6s ease-out;
            position: relative;
            z-index: 2;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo-container {
            margin-bottom: 24px;
        }

        .logo {
            width: 140px;
            filter: drop-shadow(0 0 10px rgba(16, 185, 129, 0.3));
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: -0.025em;
        }

        p.subtitle {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 32px;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-muted);
            margin-left: 4px;
        }

        .input-wrapper {
            position: relative;
        }

        input {
            width: 100%;
            padding: 14px 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: white;
            font-size: 15px;
            transition: all 0.2s;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(0, 0, 0, 0.4);
            box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.1);
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }

        .toggle-password:hover {
            color: white;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: #064e3b;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 12px;
        }

        .btn-login:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .error-msg {
            margin-top: 16px;
            padding: 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 10px;
            color: #f87171;
            font-size: 14px;
            font-weight: 500;
        }

        .footer-note {
            margin-top: 32px;
            font-size: 12px;
            color: var(--text-muted);
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <div class="bg-blur"></div>
    <div class="login-card">
        <div class="logo-container">
            <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
        </div>

        <h2>Filemanager-Zugriff</h2>
        <p class="subtitle">Willkommen! Bitte melde dich mit Benutzername und Passwort an.</p>

        <form method="post">
            <div class="input-group">
                <label>Benutzername</label>
                <div class="input-wrapper">
                    <input type="text" name="username" id="username" placeholder="Benutzername" required autofocus value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
            </div>
            <div class="input-group">
                <label>Passwort</label>
                <div class="input-wrapper">
                    <input type="password" name="password" id="password" placeholder="••••••••" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('password', this)"
                        tabindex="-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
            </div>
            <?php if (!empty($showOTP)): ?>
                <div class="input-group">
                    <label>2FA-Code</label>
                    <div class="input-wrapper">
                        <input type="text" name="otp_code" id="otp_code" placeholder="123456" inputmode="numeric" autocomplete="one-time-code" autofocus required>
                    </div>
                </div>
                <div class="footer-note" style="margin-top: 10px; color: #fbbf24;">
                    Zwei-Faktor-Code erforderlich.
                </div>
            <?php endif; ?>
            <button type="submit" class="btn-login">Einloggen</button>

            <?php if ($error): ?>
                <div class="error-msg"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
        </form>

        <div style="margin-top: 25px; text-align: center;">
            <a href="../" style="color: var(--primary); text-decoration: none; font-size: 14px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; transition: opacity 0.2s;" onmouseover="this.style.opacity='0.8'" onmouseout="this.style.opacity='1'">
                <span>⬅️</span> Zurück zur Startseite
            </a>
        </div>

        <div class="footer-note">
            Benutzer werden jetzt in der Datenbank verwaltet.<br>
            Legacy-Zugang bleibt kompatibel, falls noch aktiv.
        </div>
    </div>

    <script>
        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            const isPassword = input.type === "password";
            input.type = isPassword ? "text" : "password";

            // Icon tauschen
            btn.innerHTML = isPassword
                ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
                : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
        }
    </script>
</body>

</html>
