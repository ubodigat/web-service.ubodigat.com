<?php
declare(strict_types=1);
session_start();

$security = __DIR__ . '/../config/security.php';
if (!file_exists($security)) {
    http_response_code(500);
    die('❌ security.php fehlt. Bitte zuerst /install/setup.php ausführen.');
}
require_once $security;

$bgPath = defined('FILEMANAGER_LOGIN_BG') ? FILEMANAGER_LOGIN_BG : '';
$bg = ($bgPath !== '')
    ? "background-image:url('.." . $bgPath . "'); background-size:cover; background-position:center;"
    : "background:radial-gradient(circle at top,#0f172a,#020617);";


$session_key = 'filemanager_access';
$cookie_name = 'filemanager_access';

function doLogout(string $cookie_name): void
{
    session_unset();
    session_destroy();
    setcookie($cookie_name, '', time() - 3600, '/filemanager');
}

if (isset($_SESSION[$session_key]) && $_SESSION[$session_key] === true) {
    if (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) {
        $last = (int) ($_SESSION['filemanager_last_action'] ?? 0);
        if ($last > 0 && (time() - $last) > FILEMANAGER_TIMEOUT) {
            doLogout($cookie_name);
        } else {
            $_SESSION['filemanager_last_action'] = time();
        }
    } else {
        $_SESSION['filemanager_last_action'] = time();
    }
}

if (
    isset($_SESSION[$session_key]) &&
    $_SESSION[$session_key] === true &&
    isset($_COOKIE[$cookie_name]) &&
    $_COOKIE[$cookie_name] === '1'
) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    if ($pass !== '' && defined('FILEMANAGER_ACCESS_HASH') && password_verify($pass, FILEMANAGER_ACCESS_HASH)) {

        session_regenerate_id(true);
        $_SESSION[$session_key] = true;
        $_SESSION['filemanager_last_action'] = time();

        $cookieExpires = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
            ? time() + FILEMANAGER_TIMEOUT
            : time() + 86400;

        setcookie(
            $cookie_name,
            '1',
            [
                'expires'  => $cookieExpires,
                'path'     => '/filemanager',
                'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                'httponly' => true,
                'samesite' => 'Strict',
            ]
        );

        header('Location: file_manager.php');
        exit;

    } else {
        $error = '❌ Falsches Passwort';
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Filemanager Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css?v=5">
</head>

<body>
<div class="login-box">
    <div class="logo-container">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
    </div>

    <h2>Filemanager-Zugriff</h2>
    <p class="subtitle">Willkommen! Bitte gib das Zugangspasswort ein.</p>

    <form method="post">
        <div class="input-group">
            <label>Passwort</label>
            <div class="input-wrapper">
                <input type="password" name="password" id="password" placeholder="••••••••" required autofocus>
                <button type="button" class="toggle-password" onclick="togglePassword('password', this)" tabindex="-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </div>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:20px;">Einloggen</button>

        <?php if ($error): ?>
            <div class="error-msg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </form>

    <div class="footer-note">
        Passwort wurde im Setup festgelegt.<br>
        (Wird nicht im Code gespeichert)
    </div>
</div>

<script>
    function togglePassword(inputId, btn) {
        const input = document.getElementById(inputId);
        const isPassword = input.type === "password";
        input.type = isPassword ? "text" : "password";

        // Icon tauschen
        btn.innerHTML = isPassword
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    }
</script>
</body>

</html>