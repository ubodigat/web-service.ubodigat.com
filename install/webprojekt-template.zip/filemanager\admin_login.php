<?php
declare(strict_types=1);
session_start();

// 1. DB-Konfiguration laden
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    die('❌ Konfigurationsdatei fehlt. Bitte erst das Setup ausführen.');
}
require_once $configFile;

// 2. Security-Konfiguration laden (für Timeout & Background)
$securityFile = __DIR__ . '/../config/security.php';
if (file_exists($securityFile)) {
    require_once $securityFile;
}

$bgPath = defined('WEB_LOGIN_BG') ? WEB_LOGIN_BG : '';
$bg = ($bgPath !== '')
    ? "background-image:url('.." . $bgPath . "'); background-size: cover; background-position: center;"
    : "background: radial-gradient(circle at top, #0f172a, #020617);";

// 3. TOTP Funktionen
function verifyTOTP($secret, $code)
{
    if (!$secret)
        return true;
    if (!$code)
        return false;
    $time = floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        if (calculateTOTP($secret, $time + $i) == $code)
            return true;
    }
    return false;
}

function calculateTOTP($secret, $time)
{
    $secret = strtoupper($secret);
    $base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $charsFlipped = array_flip(str_split($base32chars));
    $output = '';
    $v = 0;
    $vbits = 0;
    foreach (str_split($secret) as $char) {
        if (!isset($charsFlipped[$char]))
            continue;
        $v = ($v << 5) | $charsFlipped[$char];
        $vbits += 5;
        if ($vbits >= 8) {
            $vbits -= 8;
            $output .= chr(($v >> $vbits) & 255);
        }
    }
    $timeStr = pack('N*', 0) . pack('N*', $time);
    $hmac = hash_hmac('sha1', $timeStr, $output, true);
    $offset = ord($hmac[19]) & 0xf;
    $otp = (
        ((ord($hmac[$offset + 0]) & 0x7f) << 24) |
        ((ord($hmac[$offset + 1]) & 0xff) << 16) |
        ((ord($hmac[$offset + 2]) & 0xff) << 8) |
        (ord($hmac[$offset + 3]) & 0xff)
    ) % 1000000;
    return str_pad((string) $otp, 6, '0', STR_PAD_LEFT);
}

// 4. Wenn schon eingeloggt, weiterleiten
if (!empty($_SESSION['admin_access'])) {
    header('Location: file_manager.php');
    exit;
}

// AJAX 2FA Check
if (isset($_GET['check_2fa'])) {
    header('Content-Type: application/json');
    $checkUser = trim($_GET['check_2fa']);
    $has2FA = false;
    if ($checkUser !== '') {
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            $stmt = $db->prepare("SELECT auth_secret FROM benutzer WHERE nutzername = ?");
            if ($stmt) {
                $stmt->bind_param('s', $checkUser);
                $stmt->execute();
                $stmt->bind_result($secret);
                if ($stmt->fetch() && !empty($secret)) {
                    $has2FA = true;
                }
                $stmt->close();
            }
            $db->close();
        } catch (Exception $e) {}
    }
    echo json_encode(['has2FA' => $has2FA]);
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    $otp = trim($_POST['otp_code'] ?? '');

    if ($user !== '' && $pass !== '') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            $db->set_charset('utf8mb4');

            // DB Migration für 2FA falls Spalte fehlt
            $checkColumn = $db->query("SHOW COLUMNS FROM benutzer LIKE 'auth_secret'");
            if ($checkColumn && $checkColumn->num_rows === 0) {
                $db->query("ALTER TABLE benutzer ADD COLUMN auth_secret VARCHAR(255) DEFAULT NULL AFTER passwort");
            }

            // Passwort und 2FA-Secret holen
            $stmt = $db->prepare("SELECT id, passwort, auth_secret FROM benutzer WHERE nutzername = ?");
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($userId, $hash, $secret);

            if ($stmt->fetch() && password_verify($pass, $hash)) {

                // Hat der User 2FA aktiviert?
                $has2FA = !empty($secret);

                if ($has2FA && empty($otp)) {
                    // Schritt 1: Passwort korrekt, aber 2FA fehlt -> OTP Feld anzeigen
                    $showOTP = true;
                    // Wir merken uns den Usernamen für den nächsten POST (im Hidden Field oder via POST-Payload)
                } else {
                    // Entweder kein 2FA oder OTP wurde mitgeschickt
                    $otpValid = true;
                    if ($has2FA) {
                        $otpValid = verifyTOTP($secret, $otp);
                    }

                    if ($otpValid) {
                        // ✅ ERFOLG: Einloggen
                        session_regenerate_id(true);
                        $_SESSION['admin_access'] = true;
                        $_SESSION['admin_user'] = $user;
                        $_SESSION['admin_id'] = $userId;
                        $_SESSION['filemanager_access'] = true;
                        $_SESSION['filemanager_last_action'] = time();

                        $timeoutDuration = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
                        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

                        setcookie('filemanager_access', '1', [
                            'expires'  => time() + $timeoutDuration,
                            'path'     => '/filemanager',
                            'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
                            'httponly' => true,
                            'samesite' => 'Strict',
                        ]);

                        $stmt->close();
                        $db->close();
                        header('Location: file_manager.php');
                        exit;
                    } else {
                        $error = '❌ Ungültiger 2FA-Code';
                        $showOTP = true; // Wieder anzeigen
                    }
                }
            } else {
                $error = '❌ Ungültige Zugangsdaten';
            }
            $stmt->close();
            $db->close();
        } catch (mysqli_sql_exception $e) {
            $error = '❌ Datenbankfehler';
        }
    } else {
        $error = '❌ Bitte alle Felder ausfüllen';
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Admin Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css?v=5">
</head>

<body>
<div class="login-box">
    <div class="logo-container">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
    </div>

    <h2>Admin-Zugriff</h2>
    <p class="subtitle">Willkommen zurück! Bitte melde dich an.</p>

    <form method="post">
        <div class="input-group">
            <label>Benutzername</label>
            <div class="input-wrapper">
                <input type="text" name="username" placeholder="z.B. admin" required autofocus
                    value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>
        </div>

        <div class="input-group">
            <label>Passwort</label>
            <div class="input-wrapper">
                <input type="password" name="password" id="pass" placeholder="••••••••" required>
                <button type="button" class="toggle-password" onclick="togglePassword('pass', this)" tabindex="-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </div>
        </div>

        <div id="otp-container" style="display: <?= !empty($showOTP) ? 'block' : 'none' ?>; animation: fadeIn 0.4s ease-out;">
            <div class="input-group">
                <label>2-Faktor-Code (OTP)</label>
                <div class="input-wrapper">
                    <input type="text" name="otp_code" placeholder="123456" maxlength="6"
                        style="text-align:center; font-size:20px; letter-spacing:4px;">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:20px;"><?= !empty($showOTP) ? 'Verifizieren' : 'Einloggen' ?></button>

        <?php if ($error): ?>
            <div class="error-msg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </form>

    <div class="footer-note">
        Tabelle: <code>benutzer</code>
    </div>
</div>

<script>
    function togglePassword(inputId, btn) {
        const input = document.getElementById(inputId);
        const isPassword = input.type === "password";
        input.type = isPassword ? "text" : "password";

        // Icon tauschen
        btn.innerHTML = isPassword
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    }

    // AJAX 2FA Check
    document.addEventListener('DOMContentLoaded', () => {
        const userInput = document.querySelector('input[name="username"]');
        const otpContainer = document.getElementById('otp-container');
        const otpInput = document.querySelector('input[name="otp_code"]');
        const btn = document.querySelector('.btn-login');

        const check2FA = async () => {
            const username = userInput.value.trim();
            if (username.length > 0) {
                try {
                    const res = await fetch('admin_login.php?check_2fa=' + encodeURIComponent(username));
                    const data = await res.json();
                    if (data.has2FA) {
                        otpContainer.style.display = 'block';
                        otpInput.setAttribute('required', 'required');
                        btn.textContent = 'Verifizieren';
                    } else {
                        otpContainer.style.display = 'none';
                        otpInput.removeAttribute('required');
                        btn.textContent = 'Einloggen';
                    }
                } catch (e) {
                    console.error('2FA Check failed', e);
                }
            } else {
                otpContainer.style.display = 'none';
                otpInput.removeAttribute('required');
                btn.textContent = 'Einloggen';
            }
        };

        userInput.addEventListener('blur', check2FA);
        if (userInput.value) check2FA();
    });
</script>
</body>

</html>