<?php
declare(strict_types=1);
session_start();

// 1. DB-Konfiguration laden
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    die('❌ Konfigurationsdatei fehlt. Bitte erst das Setup ausführen.');
}
require_once $configFile;

// 2. Security-Konfiguration laden (für Timeout & Background)
$securityFile = __DIR__ . '/../config/security.php';
if (file_exists($securityFile)) {
    require_once $securityFile;
}

$bgPath = defined('WEB_LOGIN_BG') ? WEB_LOGIN_BG : '';
$bg = ($bgPath !== '')
    ? "background-image:url('.." . $bgPath . "'); background-size: cover; background-position: center;"
    : "background: radial-gradient(circle at top, #0f172a, #020617);";

// 3. TOTP Funktionen
function verifyTOTP($secret, $code)
{
    if (!$secret)
        return true;
    if (!$code)
        return false;
    $time = floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        if (calculateTOTP($secret, $time + $i) == $code)
            return true;
    }
    return false;
}

function calculateTOTP($secret, $time)
{
    $secret = strtoupper($secret);
    $base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $charsFlipped = array_flip(str_split($base32chars));
    $output = '';
    $v = 0;
    $vbits = 0;
    foreach (str_split($secret) as $char) {
        if (!isset($charsFlipped[$char]))
            continue;
        $v = ($v << 5) | $charsFlipped[$char];
        $vbits += 5;
        if ($vbits >= 8) {
            $vbits -= 8;
            $output .= chr(($v >> $vbits) & 255);
        }
    }
    $timeStr = pack('N*', 0) . pack('N*', $time);
    $hmac = hash_hmac('sha1', $timeStr, $output, true);
    $offset = ord($hmac[19]) & 0xf;
    $otp = (
        ((ord($hmac[$offset + 0]) & 0x7f) << 24) |
        ((ord($hmac[$offset + 1]) & 0xff) << 16) |
        ((ord($hmac[$offset + 2]) & 0xff) << 8) |
        (ord($hmac[$offset + 3]) & 0xff)
    ) % 1000000;
    return str_pad((string) $otp, 6, '0', STR_PAD_LEFT);
}

// 4. Wenn schon eingeloggt, weiterleiten
if (!empty($_SESSION['admin_access'])) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';

    if ($user !== '' && $pass !== '') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            $db->set_charset('utf8mb4');

            $stmt = $db->prepare("SELECT passwort FROM benutzer WHERE nutzername = ?");
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($hash);

            if ($stmt->fetch() && password_verify($pass, $hash)) {

                // ✅ SICHERHEIT: Session-ID regenerieren (Gegen Session Fixation)
                session_regenerate_id(true);

                // Session-Variablen setzen
                $_SESSION['admin_access'] = true;
                $_SESSION['filemanager_access'] = true; // Damit .htaccess/PHP zufrieden ist
                $_SESSION['filemanager_last_action'] = time();

                // ✅ TIMEOUT: Wert aus Setup oder Standard 30 Min
                $timeoutDuration = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0)
                    ? FILEMANAGER_TIMEOUT
                    : 1800;

                // ✅ HTTPS: Automatische Erkennung
                $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

                // Cookie setzen (Wichtig für .htaccess Whitelist)
                setcookie(
                    'filemanager_access',
                    '1',
                    [
                        'expires' => time() + $timeoutDuration,
                        'path' => '/filemanager',
                        'secure' => $isSecure,
                        'httponly' => true,
                        'samesite' => 'Strict'
                    ]
                );

                // Aufräumen
                $stmt->close();
                $db->close();

                header('Location: file_manager.php');
                exit;
            }
        } catch (mysqli_sql_exception $e) {
            // Fehler stillschweigend behandeln (Sicherheit)
        }
    }

    $error = '❌ Ungültige Zugangsdaten';
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Admin Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box
        }

        body {
            margin: 0;
            min-height: 100vh;
            <?= $bg ?>
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: #e5e7eb;
            padding: 24px;
        }

        .card {
            width: 100%;
            max-width: 380px;
            background: rgba(15, 23, 42, .92);
            backdrop-filter: blur(16px);
            border-radius: 18px;
            padding: 36px;
            box-shadow: 0 30px 80px rgba(0, 0, 0, .7);
            border: 1px solid rgba(34, 48, 74, .7);
            text-align: center;
        }

        .logo {
            width: 150px;
            margin-bottom: 18px
        }

        .error {
            margin-top: 14px;
            color: #f87171;
            font-weight: 700;
        }

        small {
            display: block;
            margin-top: 16px;
            color: #94a3b8;
            font-size: 0.85rem;
        }
    </style>
</head>

<body>

    <form method="post" class="card">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
        <h2>👑 Admin-Zugriff</h2>

        <input type="text" name="username" placeholder="Benutzername" required autofocus>
        <div style="position:relative;">
            <input type="password" name="password" id="pass" placeholder="Passwort" required
                value="<?= htmlspecialchars($_POST['password'] ?? '') ?>">
            <button type="button" class="toggle-password" onclick="togglePassword('pass', this)"
                style="position:absolute; right:12px; top:14px; background:none; border:none; opacity:0.5; color:white; cursor:pointer;">👁️</button>
        </div>

        <?php if (!empty($showOTP)): ?>
            <div id="otp_zone" style="margin-top:20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top:20px;">
                <label style="display:block; margin-bottom:10px; font-size:12px; opacity:0.7;">🔒 2-Faktor-Code
                    (OTP)</label>
                <input type="text" name="otp_code" placeholder="6-stelliger Code" maxlength="6" autofocus
                    style="text-align:center; font-size:24px; letter-spacing:5px; background:rgba(255,165,0,0.05); border:1px solid var(--warning);">
            </div>
        <?php endif; ?>

        <button type="submit" class="btn-login"><?= !empty($showOTP) ? 'Verifizieren' : 'Einloggen' ?></button>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <small>Verwendet die Datenbank-Tabelle <code>benutzer</code>.</small>
    </form>

    <script>
        function togglePassword(inputId, btn) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
                btn.textContent = "👁️‍🗨️";
            } else {
                input.type = "password";
                btn.textContent = "👁️";
            }
        }
    </script>
</body>

</html>