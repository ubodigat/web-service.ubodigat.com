<?php
declare(strict_types=1);
session_start();

// 1. DB-Konfiguration laden
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    die('❌ Konfigurationsdatei fehlt. Bitte erst das Setup ausführen.');
}
require_once $configFile;

// 2. Security-Konfiguration laden (für Timeout & Background)
$securityFile = __DIR__ . '/../config/security.php';
if (file_exists($securityFile)) {
    require_once $securityFile;
}

$bgPath = defined('WEB_LOGIN_BG') ? WEB_LOGIN_BG : '';
$bg = ($bgPath !== '')
    ? "background-image:url('.." . $bgPath . "'); background-size: cover; background-position: center;"
    : "background: radial-gradient(circle at top, #0f172a, #020617);";

// 3. TOTP Funktionen
function verifyTOTP($secret, $code)
{
    if (!$secret)
        return true;
    if (!$code)
        return false;
    $time = floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        if (calculateTOTP($secret, $time + $i) == $code)
            return true;
    }
    return false;
}

function calculateTOTP($secret, $time)
{
    $secret = strtoupper($secret);
    $base32chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $charsFlipped = array_flip(str_split($base32chars));
    $output = '';
    $v = 0;
    $vbits = 0;
    foreach (str_split($secret) as $char) {
        if (!isset($charsFlipped[$char]))
            continue;
        $v = ($v << 5) | $charsFlipped[$char];
        $vbits += 5;
        if ($vbits >= 8) {
            $vbits -= 8;
            $output .= chr(($v >> $vbits) & 255);
        }
    }
    $timeStr = pack('N*', 0) . pack('N*', $time);
    $hmac = hash_hmac('sha1', $timeStr, $output, true);
    $offset = ord($hmac[19]) & 0xf;
    $otp = (
        ((ord($hmac[$offset + 0]) & 0x7f) << 24) |
        ((ord($hmac[$offset + 1]) & 0xff) << 16) |
        ((ord($hmac[$offset + 2]) & 0xff) << 8) |
        (ord($hmac[$offset + 3]) & 0xff)
    ) % 1000000;
    return str_pad((string) $otp, 6, '0', STR_PAD_LEFT);
}

// 4. Wenn schon eingeloggt, weiterleiten
if (!empty($_SESSION['admin_access'])) {
    header('Location: file_manager.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';
    $otp = trim($_POST['otp_code'] ?? '');

    if ($user !== '' && $pass !== '') {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        try {
            $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
            $db->set_charset('utf8mb4');

            // DB Migration für 2FA falls Spalte fehlt
            $checkColumn = $db->query("SHOW COLUMNS FROM benutzer LIKE 'auth_secret'");
            if ($checkColumn && $checkColumn->num_rows === 0) {
                $db->query("ALTER TABLE benutzer ADD COLUMN auth_secret VARCHAR(255) DEFAULT NULL AFTER passwort");
            }

            // Passwort und 2FA-Secret holen
            $stmt = $db->prepare("SELECT id, passwort, auth_secret FROM benutzer WHERE nutzername = ?");
            $stmt->bind_param('s', $user);
            $stmt->execute();
            $stmt->bind_result($userId, $hash, $secret);

            if ($stmt->fetch() && password_verify($pass, $hash)) {

                // Hat der User 2FA aktiviert?
                $has2FA = !empty($secret);

                if ($has2FA && empty($otp)) {
                    // Schritt 1: Passwort korrekt, aber 2FA fehlt -> OTP Feld anzeigen
                    $showOTP = true;
                    // Wir merken uns den Usernamen für den nächsten POST (im Hidden Field oder via POST-Payload)
                } else {
                    // Entweder kein 2FA oder OTP wurde mitgeschickt
                    $otpValid = true;
                    if ($has2FA) {
                        $otpValid = verifyTOTP($secret, $otp);
                    }

                    if ($otpValid) {
                        // ✅ ERFOLG: Einloggen
                        session_regenerate_id(true);
                        $_SESSION['admin_access'] = true;
                        $_SESSION['admin_user'] = $user;
                        $_SESSION['admin_id'] = $userId;
                        $_SESSION['filemanager_access'] = true;
                        $_SESSION['filemanager_last_action'] = time();

                        $timeoutDuration = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
                        $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

                        setcookie('filemanager_access', '1', [
                            'expires' => time() + $timeoutDuration,
                            'path' => '/filemanager',
                            'secure' => $isSecure,
                            'httponly' => true,
                            'samesite' => 'Strict'
                        ]);

                        $stmt->close();
                        $db->close();
                        header('Location: file_manager.php');
                        exit;
                    } else {
                        $error = '❌ Ungültiger 2FA-Code';
                        $showOTP = true; // Wieder anzeigen
                    }
                }
            } else {
                $error = '❌ Ungültige Zugangsdaten';
            }
            $stmt->close();
            $db->close();
        } catch (mysqli_sql_exception $e) {
            $error = '❌ Datenbankfehler';
        }
    } else {
        $error = '❌ Bitte alle Felder ausfüllen';
    }
}

$logo = "https://web-service.ubodigat.com/ubodigatlogo.svg";
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <title>🔐 Admin Login</title>
    <link rel="icon" type="image/png" href="https://web-service.ubodigat.com/x-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        :root {
            --primary: #3b82f6;
            --primary-hover: #2563eb;
            --bg: #020617;
            --card-bg: rgba(15, 23, 42, 0.8);
            --border: rgba(255, 255, 255, 0.1);
            --text: #f8fafc;
            --text-muted: #94a3b8;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            <?= $bg ?>
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: var(--text);
            padding: 20px;
            overflow: hidden;
            background-size: cover;
            background-position: center;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.6s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo-container {
            margin-bottom: 24px;
        }

        .logo {
            width: 140px;
            filter: drop-shadow(0 0 10px rgba(59, 130, 246, 0.3));
        }

        h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: -0.025em;
        }

        p.subtitle {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 32px;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-muted);
            margin-left: 4px;
        }

        .input-wrapper {
            position: relative;
        }

        input {
            width: 100%;
            padding: 14px 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: white;
            font-size: 15px;
            transition: all 0.2s;
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(0, 0, 0, 0.4);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }

        .toggle-password:hover {
            color: white;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 12px;
        }

        .btn-login:hover {
            background: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(59, 130, 246, 0.3);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .error-msg {
            margin-top: 16px;
            padding: 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 10px;
            color: #f87171;
            font-size: 14px;
            font-weight: 500;
        }

        .footer-note {
            margin-top: 32px;
            font-size: 12px;
            color: var(--text-muted);
        }

        code {
            background: rgba(255, 255, 255, 0.05);
            padding: 2px 4px;
            border-radius: 4px;
            font-family: 'JetBrains Mono', monospace;
        }
    </style>
</head>

<body>
<div class="login-card">
    <div class="logo-container">
        <img src="<?= htmlspecialchars($logo) ?>" class="logo" alt="ubodigat">
    </div>

    <h2>Admin-Zugriff</h2>
    <p class="subtitle">Willkommen zurück! Bitte melde dich an.</p>

    <form method="post">
        <div class="input-group">
            <label>Benutzername</label>
            <div class="input-wrapper">
                <input type="text" name="username" placeholder="z.B. admin" required autofocus
                    value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            </div>
        </div>

        <div class="input-group">
            <label>Passwort</label>
            <div class="input-wrapper">
                <input type="password" name="password" id="pass" placeholder="••••••••" required>
                <button type="button" class="toggle-password" onclick="togglePassword('pass', this)" tabindex="-1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </button>
            </div>
        </div>

        <?php if (!empty($showOTP)): ?>
            <div class="input-group" style="animation: fadeIn 0.4s ease-out;">
                <label>2-Faktor-Code (OTP)</label>
                <div class="input-wrapper">
                    <input type="text" name="otp_code" placeholder="123456" maxlength="6" required
                        style="text-align:center; font-size:20px; letter-spacing:4px;">
                </div>
            </div>
        <?php endif; ?>

        <button type="submit" class="btn-login"><?= !empty($showOTP) ? 'Verifizieren' : 'Einloggen' ?></button>

        <?php if ($error): ?>
            <div class="error-msg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
    </form>

    <div class="footer-note">
        Tabelle: <code>benutzer</code>
    </div>
</div>

<script>
    function togglePassword(inputId, btn) {
        const input = document.getElementById(inputId);
        const isPassword = input.type === "password";
        input.type = isPassword ? "text" : "password";

        // Icon tauschen
        btn.innerHTML = isPassword
            ? '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
            : '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    }
</script>
</body>

</html>