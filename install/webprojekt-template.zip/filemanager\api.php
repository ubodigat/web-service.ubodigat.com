<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

// 1. Konfiguration laden
// Wir gehen davon aus, dass config im selben Ordner oder relativ dazu liegt.
// Hier: Sicherheits-Config liegt standardmäßig in ../config/
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    echo json_encode(['error' => 'Konfiguration fehlt.', 'redirect' => '../install/setup.php']);
    exit;
}

require_once $securityFile;
require_once $configFile;
require_once __DIR__ . '/fm_common.php';

// Hilfsfunktionen für Dateigrößen
function formatSize($bytes) {
    if ($bytes === 0) return '0 B';
    $k = 1024;
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes) / log($k));
    return sprintf("%.2f", $bytes / pow($k, $i)) . ' ' . $sizes[$i];
}

function getFolderSize($dir) {
    $size = 0;
    foreach (glob(rtrim($dir, '/').'/*', GLOB_NOSORT) as $each) {
        $size += is_file($each) ? filesize($each) : getFolderSize($each);
    }
    return $size;
}

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    echo json_encode(['error' => 'Nicht eingeloggt.']);
    exit;
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    echo json_encode(['error' => 'Session abgelaufen.', 'redirect' => 'logout_admin.php?timeout=1']);
    exit;
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad (VORLAGEN-TAUGLICH!)
// Der Filemanager darf standardmäßig nur in SEINEM EIGENEN Ordner arbeiten (und Unterordnern).
// Wenn er woanders arbeiten soll, muss das in der config.php stehen.
// Hier als Fallback: Das aktuelle Verzeichnis (__DIR__).
$baseDir = realpath(__DIR__ . '/..');

$isAdmin = !empty($_SESSION['admin_access']);

// -------------------------------------------------------------------
// Hilfsfunktion: Pfad validieren
// -------------------------------------------------------------------
function resolvePath(string $inputPath, string $baseDir): ?string
{
    $realPath = realpath($inputPath);

    // Sonderfall: Bei Erstellung existiert Datei noch nicht -> Parent prüfen
    if (!$realPath) {
        $dir = dirname($inputPath);
        $realDir = realpath($dir);
        if ($realDir) {
            $realPath = $realDir . DIRECTORY_SEPARATOR . basename($inputPath);
        } else {
            return null;
        }
    }

    // Sandbox Check: Pfad muss mit BaseDir beginnen
    $realBase = realpath($baseDir);
    if ($realBase && strpos($realPath, $realBase) === 0) {
        return $realPath;
    }

    return null; // Ausbruchsversuch!
}

// -------------------------------------------------------------------
// Hilfsfunktion: Sichtbarkeits-Pfad normalisieren
// -------------------------------------------------------------------
function normalizeVisibilityPath(string $path, string $baseDir): string
{
    $realP = realpath($path);
    $realB = realpath($baseDir);

    if ($realP && $realB && stripos($realP, $realB) === 0) {
        $rel = substr($realP, strlen($realB));
    } else {
        $rel = $path;
    }

    return trim(str_replace(['\\', $baseDir], ['/', ''], $rel), '/');
}

function isSystemBlockedPath(string $path, string $baseDir): bool
{
    $realBase = realpath($baseDir) ?: $baseDir;
    $realPath = realpath($path);

    if ($realPath === false) {
        $realParent = realpath(dirname($path));
        if ($realParent === false) {
            return true;
        }
        $realPath = rtrim($realParent, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . basename($path);
    }

    if (stripos($realPath, $realBase) !== 0) {
        return true;
    }

    $relPath = trim(str_replace('\\', '/', substr($realPath, strlen($realBase))), '/');
    if ($relPath === '') {
        return false;
    }

    $firstSegment = explode('/', $relPath)[0] ?? '';
    $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env', 'web_login.php'];
    return in_array($firstSegment, $sensitive, true);
}

function ensureNotSystemBlocked(string $path, string $baseDir): void
{
    if (isSystemBlockedPath($path, $baseDir)) {
        throw new Exception("Dieser Eintrag ist durch das System gesperrt und kann nicht bearbeitet werden.");
    }
}

// -------------------------------------------------------------------
// Hilfsfunktion: Berechtigungen prüfen
// -------------------------------------------------------------------
function hasPermission(string $action, string $path, string $baseDir, bool $isAdmin): bool
{
    if ($isAdmin)
        return true;

    $relPath = $path;
    // Wir arbeiten mit relativen Pfaden zum Basisverzeichnis
    if (strpos($relPath, $baseDir) === 0) {
        $relPath = substr($relPath, strlen($baseDir));
    }
    $relPath = str_replace('\\', '/', $relPath);
    $relPath = trim($relPath, '/');

    // Globale Defaults
    $canDelete = defined('USER_CAN_DELETE') ? USER_CAN_DELETE : false;
    $canRename = defined('USER_CAN_RENAME') ? USER_CAN_RENAME : true;
    $canUpload = defined('USER_CAN_UPLOAD') ? USER_CAN_UPLOAD : true;
    $canCreate = defined('USER_CAN_CREATE') ? USER_CAN_CREATE : true;
    $canEdit   = defined('USER_CAN_EDIT') ? USER_CAN_EDIT : true;

    // Ordnerspezifische Overrides laden
    $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];

    // Prüfe ob für diesen Pfad (oder einen Parent) Regeln existieren
    // Wir suchen den tiefsten passenden Pfad
    $bestMatch = '';
    foreach ($folderPerms as $p => $rules) {
        if ($relPath === $p || (strpos($relPath, $p . '/') === 0)) {
            if (strlen($p) >= strlen($bestMatch)) {
                $bestMatch = $p;
            }
        }
    }

    if ($bestMatch !== '' && isset($folderPerms[$bestMatch])) {
        $rules = $folderPerms[$bestMatch];
        $canDelete = isset($rules['delete']) ? $rules['delete'] : $canDelete;
        $canRename = isset($rules['rename']) ? $rules['rename'] : $canRename;
        $canUpload = isset($rules['upload']) ? $rules['upload'] : $canUpload;
        $canCreate = isset($rules['create']) ? $rules['create'] : $canCreate;
        $canEdit   = isset($rules['edit']) ? $rules['edit'] : $canEdit;
    }

    switch ($action) {
        case 'delete':
            return $canDelete;
        case 'rename':
            return $canRename;
        case 'upload':
            return $canUpload;
        case 'create':
            return $canCreate;
        case 'save':
        case 'edit':
            return $canEdit;
        default:
            return false;
    }
}

function getMediaMetaFile(string $baseDir): string
{
    return rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'media_metadata.json';
}

function mediaKeyFromPath(string $path, string $baseDir): string
{
    $realBase = realpath($baseDir) ?: $baseDir;
    $realPath = realpath($path) ?: $path;
    if (strpos($realPath, $realBase) === 0) {
        $realPath = substr($realPath, strlen($realBase));
    }
    return trim(str_replace('\\', '/', $realPath), '/');
}

function loadMediaMetadata(string $baseDir): array
{
    $file = getMediaMetaFile($baseDir);
    if (!is_file($file)) {
        return [];
    }
    $raw = file_get_contents($file);
    $decoded = json_decode((string) $raw, true);
    return is_array($decoded) ? $decoded : [];
}

function saveMediaMetadata(string $baseDir, array $data): void
{
    $file = getMediaMetaFile($baseDir);
    $dir = dirname($file);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
}

function isMediaFileByName(string $name): bool
{
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $imageExt = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'];
    $videoExt = ['mp4', 'webm', 'mov', 'm4v', 'ogg', 'ogv'];
    return in_array($ext, $imageExt, true) || in_array($ext, $videoExt, true);
}
// -------------------------------------------------------------------
// Request Verarbeitung
// -------------------------------------------------------------------

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_REQUEST['action'] ?? '';
$path = $input['path'] ?? $_REQUEST['path'] ?? $_REQUEST['dir'] ?? '';

// Pfad normalisieren
if (!$path) {
    $path = $baseDir;
}

// Sicherheits-Check des Pfades
$targetPath = resolvePath($path, $baseDir);

if (!$targetPath) {
    echo json_encode(['status' => 'error', 'message' => 'Zugriff verweigert (Ungültiger Pfad)']);
    exit;
}

try {
    // Sichtbarkeits-Check: Darf der Nutzer diesen Ordner überhaupt sehen?
    if (!$isAdmin) {
        $relVis = '';
        $realB = realpath($baseDir) ?: $baseDir;
        $realT = realpath($targetPath) ?: $targetPath;
        if (stripos($realT, $realB) === 0) {
            $relVis = trim(str_replace('\\', '/', substr($realT, strlen($realB))), '/');
        }
        
        $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];
        $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
        
        $parts = explode('/', $relVis);
        $check = '';
        foreach ($parts as $part) {
            if ($part === '') continue;
            $check = trim($check . '/' . $part, '/');
            if ((isset($visSettings[$check]) && $visSettings[$check] === 'private') || 
                (isset($folderPerms[$check]) && !empty($folderPerms[$check]['is_private']))) {
                throw new Exception("Zugriff verweigert (Ordner ist privat).");
            }
        }
    }

    switch ($action) {
        case 'list':
            if (!is_dir($targetPath))
                throw new Exception("Verzeichnis nicht gefunden.");

            $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];
            $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
            $realBase    = realpath($baseDir) ?: $baseDir;

            $files  = scandir($targetPath);
            $result = [];
            foreach ($files as $f) {
                if ($f === '.' || $f === '..') continue;
                if (in_array($f, ['api.php', 'media_api.php', 'upload.php', 'download.php', 'config.php', 'admin_login.php', 'login_filemanager.php'])) continue;

                $full     = $targetPath . DIRECTORY_SEPARATOR . $f;
                $realFull = realpath($full) ?: $full;

                // Relativer Pfad für Sichtbarkeits-Check
                $relItem = '';
                if (stripos($realFull, $realBase) === 0) {
                    $relItem = trim(str_replace('\\', '/', substr($realFull, strlen($realBase))), '/');
                }

                // Effektive Sichtbarkeit prüfen (inkl. Eltern-Ordner & Ordner-Regeln)
                $isPrivateItem = false;
                $isSystemBlocked = isSystemBlockedPath($full, $baseDir);

                $parts = explode('/', $relItem);
                if ($isSystemBlocked) {
                    $isPrivateItem = true;
                } else {
                    $check = '';
                    foreach ($parts as $part) {
                        $check = trim($check . '/' . $part, '/');
                        // Check 1: Explizite Sichtbarkeits-Einstellung
                        if (isset($visSettings[$check]) && $visSettings[$check] === 'private') {
                            $isPrivateItem = true;
                            break;
                        }
                        // Check 2: Ordnerspezifische Regel (is_private Flag)
                        if (isset($folderPerms[$check]) && !empty($folderPerms[$check]['is_private'])) {
                            $isPrivateItem = true;
                            break;
                        }
                    }
                }

                $isFolder = is_dir($full);
                $sizeBytes = $isFolder ? getFolderSize($full) : filesize($full);
                
                $result[] = [
                    'name'            => $f,
                    'type'            => $isFolder ? 'folder' : 'file',
                    'date'            => date('d.m.Y H:i', filemtime($full)),
                    'modifiedTimestamp'=> filemtime($full),
                    'sizeBytes'       => $sizeBytes,
                    'sizeFormatted'   => formatSize($sizeBytes),
                    'isPrivate'       => $isPrivateItem,
                    'isSystemBlocked' => $isSystemBlocked,
                    '_relPath'        => $relItem,   // intern für Filter
                ];
            }
            // Sortierung: Ordner zuerst
            usort($result, fn($a, $b) => strcmp($b['type'], $a['type']));

            // Filterung für Nicht-Admins
            if (!$isAdmin) {
                $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env', 'web_login.php'];
                $result = array_values(array_filter($result, function ($file) use ($sensitive, $visSettings) {
                    if (in_array($file['name'], $sensitive)) return false;
                    // Eigenes privat-Flag prüfen
                    if ($file['isPrivate']) return false;
                    // Alle Parent-Ordner prüfen
                    $parts = explode('/', $file['_relPath']);
                    $check = '';
                    foreach ($parts as $part) {
                        $check = trim($check . '/' . $part, '/');
                        if (isset($visSettings[$check]) && $visSettings[$check] === 'private') return false;
                    }
                    return true;
                }));
            }

            // _relPath aus der Antwort entfernen (intern)
            foreach ($result as &$item) unset($item['_relPath']);
            unset($item);

            echo json_encode([
                'success' => true,
                'files' => $result,
                'currentPath' => $targetPath,
                'currentPathBlocked' => isSystemBlockedPath($targetPath, $baseDir),
                'isAdmin' => $isAdmin
            ]);
            break;

        case 'get_content':
        case 'open':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!is_file($targetPath))
                throw new Exception("Keine Datei.");
            echo json_encode(['success' => true, 'content' => file_get_contents($targetPath)]);
            break;

        case 'save_content':
        case 'save':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('save', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Bearbeiten nicht erlaubt).");
            
            if (!$isAdmin) {
                $ext = pathinfo($targetPath, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), ['htaccess', 'env'])) {
                    throw new Exception("Sicherheitswarnung: Dateityp verboten.");
                }
            }
            $content = $input['content'] ?? $_POST['content'] ?? '';
            if (file_put_contents($targetPath, $content) === false)
                throw new Exception("Speichern fehlgeschlagen.");
            echo json_encode(['success' => 'Datei erfolgreich gespeichert.']);
            break;

        case 'create':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $type = $input['type'] ?? $_POST['type'] ?? 'file';
            $name = $input['fileName'] ?? $_POST['fileName'] ?? '';
            if (!$name)
                throw new Exception("Kein Name angegeben.");

            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");

            if (file_exists($newPath))
                throw new Exception("Bereits vorhanden.");
            if ($type === 'folder') {
                if (!mkdir($newPath, 0755))
                    throw new Exception("Ordner erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Ordner erfolgreich erstellt.']);
            } else {
                if (file_put_contents($newPath, "") === false)
                    throw new Exception("Datei erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Datei erfolgreich erstellt.']);
            }
            break;

        case 'create_folder':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Ordnername.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Ordnername.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Ordner existiert bereits.");
            if (!mkdir($newPath, 0755))
                throw new Exception("Konnte Ordner nicht erstellen.");
            echo json_encode(['success' => 'Ordner erstellt.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'create_folder', $newPath, 'Ordner erstellt');
                $auditDb->close();
            }
            break;

        case 'create_file':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Dateiname.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Datei existiert bereits.");
            if (file_put_contents($newPath, "") === false)
                throw new Exception("Konnte Datei nicht erstellen.");
            echo json_encode(['success' => 'Datei erstellt.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'create_file', $newPath, 'Datei erstellt');
                $auditDb->close();
            }
            break;

        case 'delete':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('delete', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Löschen nicht erlaubt).");

            // Papierkorb-Logik: In .trash verschieben statt endgültig löschen
            $trashDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.trash';
            if (!is_dir($trashDir)) {
                mkdir($trashDir, 0755, true);
            }

            $itemName = basename($targetPath);
            $timestamp = date('Ymd_His');
            $trashName = $timestamp . '__' . $itemName;
            $trashTarget = $trashDir . DIRECTORY_SEPARATOR . $trashName;

            if (!rename($targetPath, $trashTarget)) {
                throw new Exception("Verschieben in den Papierkorb fehlgeschlagen.");
            }

            // Metadaten speichern, damit wir den Ursprungspfad kennen
            $trashMetaFile = $trashDir . DIRECTORY_SEPARATOR . '.trash_meta.json';
            $trashMeta = [];
            if (is_file($trashMetaFile)) {
                $trashMeta = json_decode(file_get_contents($trashMetaFile), true) ?? [];
            }
            $trashMeta[$trashName] = [
                'originalPath' => $targetPath,
                'deletedAt' => date('c'),
                'isDir' => is_dir($trashTarget)
            ];
            file_put_contents($trashMetaFile, json_encode($trashMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));

            echo json_encode(['success' => 'In den Papierkorb verschoben.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'delete', $targetPath, 'In den Papierkorb verschoben');
                $auditDb->close();
            }
            break;

        case 'trash_list':
            if (!$isAdmin)
                throw new Exception("Admin-Rechte erforderlich.");
            $trashDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.trash';
            $trashMetaFile = $trashDir . DIRECTORY_SEPARATOR . '.trash_meta.json';
            $trashMeta = [];
            if (is_file($trashMetaFile)) {
                $trashMeta = json_decode(file_get_contents($trashMetaFile), true) ?? [];
            }

            $items = [];
            foreach ($trashMeta as $trashName => $info) {
                $trashPath = $trashDir . DIRECTORY_SEPARATOR . $trashName;
                if (!file_exists($trashPath)) continue;

                $isDir = is_dir($trashPath);
                $sizeBytes = $isDir ? getFolderSize($trashPath) : filesize($trashPath);

                $items[] = [
                    'trashName' => $trashName,
                    'originalName' => basename($info['originalPath'] ?? $trashName),
                    'originalPath' => $info['originalPath'] ?? '',
                    'deletedAt' => $info['deletedAt'] ?? '',
                    'isDir' => $isDir,
                    'sizeFormatted' => formatSize($sizeBytes)
                ];
            }

            usort($items, fn($a, $b) => strcmp($b['deletedAt'], $a['deletedAt']));
            echo json_encode(['success' => true, 'items' => $items]);
            break;

        case 'trash_restore':
            if (!$isAdmin)
                throw new Exception("Admin-Rechte erforderlich.");
            $trashName = $input['trashName'] ?? '';
            if (!$trashName)
                throw new Exception("Kein Element angegeben.");
            $trashDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.trash';
            $trashMetaFile = $trashDir . DIRECTORY_SEPARATOR . '.trash_meta.json';
            $trashPath = $trashDir . DIRECTORY_SEPARATOR . $trashName;

            if (!file_exists($trashPath))
                throw new Exception("Element nicht im Papierkorb gefunden.");

            $trashMeta = [];
            if (is_file($trashMetaFile)) {
                $trashMeta = json_decode(file_get_contents($trashMetaFile), true) ?? [];
            }

            $originalPath = $trashMeta[$trashName]['originalPath'] ?? '';
            if (!$originalPath)
                throw new Exception("Ursprungspfad unbekannt.");
            if (file_exists($originalPath))
                throw new Exception("Am Ursprungspfad existiert bereits eine Datei/Ordner mit diesem Namen.");

            $parentDir = dirname($originalPath);
            if (!is_dir($parentDir)) {
                mkdir($parentDir, 0755, true);
            }

            if (!rename($trashPath, $originalPath))
                throw new Exception("Wiederherstellen fehlgeschlagen.");

            unset($trashMeta[$trashName]);
            file_put_contents($trashMetaFile, json_encode($trashMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
            echo json_encode(['success' => basename($originalPath) . ' wiederhergestellt.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'trash_restore', $originalPath, 'Aus Papierkorb wiederhergestellt');
                $auditDb->close();
            }
            break;

        case 'trash_delete':
            if (!$isAdmin)
                throw new Exception("Admin-Rechte erforderlich.");
            $trashName = $input['trashName'] ?? '';
            if (!$trashName)
                throw new Exception("Kein Element angegeben.");
            $trashDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.trash';
            $trashMetaFile = $trashDir . DIRECTORY_SEPARATOR . '.trash_meta.json';
            $trashPath = $trashDir . DIRECTORY_SEPARATOR . $trashName;

            if (file_exists($trashPath)) {
                if (is_dir($trashPath)) {
                    $it = new RecursiveDirectoryIterator($trashPath, RecursiveDirectoryIterator::SKIP_DOTS);
                    $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                    foreach ($files as $file) {
                        if ($file->isDir()) rmdir($file->getRealPath());
                        else unlink($file->getRealPath());
                    }
                    rmdir($trashPath);
                } else {
                    unlink($trashPath);
                }
            }

            $trashMeta = [];
            if (is_file($trashMetaFile)) {
                $trashMeta = json_decode(file_get_contents($trashMetaFile), true) ?? [];
            }
            unset($trashMeta[$trashName]);
            file_put_contents($trashMetaFile, json_encode($trashMeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
            echo json_encode(['success' => 'Endg?ltig gel?scht.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'trash_delete', $trashPath, 'Endg?ltig gel?scht');
                $auditDb->close();
            }
            break;

        case 'trash_empty':
            if (!$isAdmin)
                throw new Exception("Admin-Rechte erforderlich.");
            $trashDir = rtrim($baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.trash';
            if (is_dir($trashDir)) {
                $it = new RecursiveDirectoryIterator($trashDir, RecursiveDirectoryIterator::SKIP_DOTS);
                $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                foreach ($files as $file) {
                    if ($file->isDir()) rmdir($file->getRealPath());
                    else unlink($file->getRealPath());
                }
            }
            echo json_encode(['success' => 'Papierkorb geleert.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'trash_empty', $trashDir, 'Papierkorb geleert');
                $auditDb->close();
            }
            break;

        case 'rename':
            if (!hasPermission('rename', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Umbenennen nicht erlaubt).");
            $oldName = $input['oldName'] ?? $_POST['oldName'] ?? '';
            $newName = $input['newName'] ?? $_POST['newName'] ?? '';
            if (!$oldName || !$newName)
                throw new Exception("Namen fehlen.");

            $oldPath = $targetPath . DIRECTORY_SEPARATOR . $oldName;
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $newName);

            if (!resolvePath($oldPath, $baseDir) || !resolvePath($newPath, $baseDir)) {
                throw new Exception("Pfad-Fehler.");
            }
            ensureNotSystemBlocked($oldPath, $baseDir);
            ensureNotSystemBlocked($newPath, $baseDir);
            if (rename($oldPath, $newPath)) {
                echo json_encode(['success' => 'Umbenannt.']);
                if ($auditDb = fm_open_db()) {
                    fm_log_action($auditDb, 'rename', $newPath, 'Umbenannt von ' . $oldName);
                    $auditDb->close();
                }
            } else {
                throw new Exception("Umbenennen fehlgeschlagen.");
            }
            break;

        case 'zip_folder':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('create', dirname($targetPath), $baseDir, $isAdmin)) {
                throw new Exception("Zugriff verweigert (ZIP erstellen nicht erlaubt).");
            }
            if (!is_dir($targetPath)) {
                throw new Exception("Nur Ordner k?nnen gepackt werden.");
            }

            $zipPath = $targetPath . '.zip';
            if (file_exists($zipPath)) {
                throw new Exception("Die Datei " . basename($zipPath) . " existiert bereits.");
            }

            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                throw new Exception("ZIP-Datei konnte nicht erstellt werden.");
            }

            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($targetPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen(dirname($targetPath)) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }

            $zip->close();
            echo json_encode(['success' => 'Ordner erfolgreich als ' . basename($zipPath) . ' gepackt.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'zip_folder', $zipPath, 'Ordner als ZIP gepackt');
                $auditDb->close();
            }
            break;

        case 'unzip_file':
            ensureNotSystemBlocked($targetPath, $baseDir);
            if (!hasPermission('create', dirname($targetPath), $baseDir, $isAdmin)) {
                throw new Exception("Zugriff verweigert (Entpacken nicht erlaubt).");
            }
            if (!is_file($targetPath) || strtolower(pathinfo($targetPath, PATHINFO_EXTENSION)) !== 'zip') {
                throw new Exception("Nur ZIP-Dateien k?nnen entpackt werden.");
            }

            $parentDir = dirname($targetPath);
            $zip = new ZipArchive();
            if ($zip->open($targetPath) !== true) {
                throw new Exception("Konnte ZIP-Datei nicht ?ffnen.");
            }

            // Sicherheitschecks
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = $zip->getNameIndex($i);
                if (strpos($filename, '..') !== false || strpos($filename, '/') === 0 || strpos($filename, '\\') === 0) {
                    $zip->close();
                    throw new Exception("Sicherheitswarnung: ZIP enth?lt ung?ltige Pfade ($filename).");
                }
                $parts = explode('/', str_replace('\\', '/', $filename));
                $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env', 'web_login.php'];
                foreach ($parts as $part) {
                    if (in_array(strtolower($part), $sensitive, true)) {
                        $zip->close();
                        throw new Exception("Sicherheitswarnung: ZIP enth?lt systemkritische Segmente ($filename).");
                    }
                }
            }

            $zip->extractTo($parentDir);
            $zip->close();
            echo json_encode(['success' => 'ZIP-Datei erfolgreich entpackt.']);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'unzip_file', $targetPath, 'ZIP entpackt');
                $auditDb->close();
            }
            break;

        case 'set_visibility':
            if (!$isAdmin) throw new Exception("Admin-Rechte erforderlich.");
            $pathInput = $input['path']    ?? '';
            $status    = $input['status']  ?? 'public';
            $cascade   = !empty($input['cascade']);
            ensureNotSystemBlocked($pathInput, $baseDir);

            $relVis      = normalizeVisibilityPath($pathInput, $baseDir);
            $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];

            if ($status === 'private') {
                $visSettings[$relVis] = 'private';
            } else {
                unset($visSettings[$relVis]);
                if ($cascade && $relVis !== '') {
                    foreach (array_keys($visSettings) as $key) {
                        if (strpos($key, $relVis . '/') === 0) unset($visSettings[$key]);
                    }
                }
            }

            $json    = json_encode($visSettings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'VISIBILITY_SETTINGS'") !== false) {
                $content = preg_replace("/define\('VISIBILITY_SETTINGS', '.*?'\);/s", "define('VISIBILITY_SETTINGS', '$json');", $content);
            } else {
                $content .= "\ndefine('VISIBILITY_SETTINGS', '$json');\n";
            }
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            $label = $relVis ?: 'Root';
            $cascadeMsg = ($cascade && $status === 'public') ? ' (inkl. Unterelemente)' : '';
            echo json_encode(['success' => '"' . $label . '" auf ' . ($status === 'private' ? 'Privat' : '?ffentlich') . " gesetzt$cascadeMsg."]);
            if ($auditDb = fm_open_db()) {
                fm_log_action($auditDb, 'set_visibility', $pathInput, 'Sichtbarkeit auf ' . $status . ' gesetzt');
                $auditDb->close();
            }
            break;

        default:
            throw new Exception('Unbekannte Aktion: ' . $action);
    }


} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

