<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');

// 1. Konfiguration laden
// Wir gehen davon aus, dass config im selben Ordner oder relativ dazu liegt.
// Hier: Sicherheits-Config liegt standardmäßig in ../config/
$securityFile = __DIR__ . '/../config/security.php';
$configFile = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    echo json_encode(['error' => 'Konfiguration fehlt.']);
    exit;
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    echo json_encode(['error' => 'Nicht eingeloggt.']);
    exit;
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;
if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    echo json_encode(['error' => 'Session abgelaufen.', 'redirect' => 'logout_admin.php?timeout=1']);
    exit;
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad (VORLAGEN-TAUGLICH!)
// Der Filemanager darf standardmäßig nur in SEINEM EIGENEN Ordner arbeiten (und Unterordnern).
// Wenn er woanders arbeiten soll, muss das in der config.php stehen.
// Hier als Fallback: Das aktuelle Verzeichnis (__DIR__).
$baseDir = realpath(__DIR__ . '/..');

$isAdmin = !empty($_SESSION['admin_access']);

// -------------------------------------------------------------------
// Hilfsfunktion: Pfad validieren
// -------------------------------------------------------------------
function resolvePath(string $inputPath, string $baseDir): ?string
{
    $realPath = realpath($inputPath);

    // Sonderfall: Bei Erstellung existiert Datei noch nicht -> Parent prüfen
    if (!$realPath) {
        $dir = dirname($inputPath);
        $realDir = realpath($dir);
        if ($realDir) {
            $realPath = $realDir . DIRECTORY_SEPARATOR . basename($inputPath);
        } else {
            return null;
        }
    }

    // Sandbox Check: Pfad muss mit BaseDir beginnen
    $realBase = realpath($baseDir);
    if ($realBase && strpos($realPath, $realBase) === 0) {
        return $realPath;
    }

    return null; // Ausbruchsversuch!
}

// -------------------------------------------------------------------
// Hilfsfunktion: Sichtbarkeits-Pfad normalisieren
// -------------------------------------------------------------------
function normalizeVisibilityPath(string $path, string $baseDir): string
{
    $realP = realpath($path);
    $realB = realpath($baseDir);

    if ($realP && $realB && stripos($realP, $realB) === 0) {
        $rel = substr($realP, strlen($realB));
    } else {
        $rel = $path;
    }

    return trim(str_replace(['\\', $baseDir], ['/', ''], $rel), '/');
}

// -------------------------------------------------------------------
// Hilfsfunktion: Berechtigungen prüfen
// -------------------------------------------------------------------
function hasPermission(string $action, string $path, string $baseDir, bool $isAdmin): bool
{
    if ($isAdmin)
        return true;

    $relPath = $path;
    // Wir arbeiten mit relativen Pfaden zum Basisverzeichnis
    if (strpos($relPath, $baseDir) === 0) {
        $relPath = substr($relPath, strlen($baseDir));
    }
    $relPath = str_replace('\\', '/', $relPath);
    $relPath = trim($relPath, '/');

    // Globale Defaults
    $canDelete = defined('USER_CAN_DELETE') ? USER_CAN_DELETE : false;
    $canRename = defined('USER_CAN_RENAME') ? USER_CAN_RENAME : true;
    $canUpload = defined('USER_CAN_UPLOAD') ? USER_CAN_UPLOAD : true;
    $canCreate = defined('USER_CAN_CREATE') ? USER_CAN_CREATE : true;

    // Ordnerspezifische Overrides laden
    $folderPerms = defined('FOLDER_PERMISSIONS') ? json_decode(FOLDER_PERMISSIONS, true) : [];

    // Prüfe ob für diesen Pfad (oder einen Parent) Regeln existieren
    // Wir suchen den tiefsten passenden Pfad
    $bestMatch = '';
    foreach ($folderPerms as $p => $rules) {
        if ($relPath === $p || (strpos($relPath, $p . '/') === 0)) {
            if (strlen($p) >= strlen($bestMatch)) {
                $bestMatch = $p;
            }
        }
    }

    if ($bestMatch !== '' && isset($folderPerms[$bestMatch])) {
        $rules = $folderPerms[$bestMatch];
        $canDelete = isset($rules['delete']) ? $rules['delete'] : $canDelete;
        $canRename = isset($rules['rename']) ? $rules['rename'] : $canRename;
        $canUpload = isset($rules['upload']) ? $rules['upload'] : $canUpload;
        $canCreate = isset($rules['create']) ? $rules['create'] : $canCreate;
    }

    switch ($action) {
        case 'delete':
            return $canDelete;
        case 'rename':
            return $canRename;
        case 'upload':
            return $canUpload;
        case 'create':
            return $canCreate;
        case 'save':
        case 'edit':
            return $canUpload || $canCreate; // Wer hochladen oder erstellen darf, darf i.d.R. auch editieren
        default:
            return false;
    }
}

// -------------------------------------------------------------------
// Request Verarbeitung
// -------------------------------------------------------------------

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_REQUEST['action'] ?? '';
$path = $input['path'] ?? $_REQUEST['path'] ?? $_REQUEST['dir'] ?? '';

// Pfad normalisieren
if (!$path) {
    $path = $baseDir;
}

// Sicherheits-Check des Pfades
$targetPath = resolvePath($path, $baseDir);

if (!$targetPath) {
    echo json_encode(['status' => 'error', 'message' => 'Zugriff verweigert (Ungültiger Pfad)']);
    exit;
}

try {
    // Sichtbarkeits-Check: Darf der Nutzer diesen Ordner überhaupt sehen?
    if (!$isAdmin) {
        $relVis = '';
        $realB = realpath($baseDir) ?: $baseDir;
        $realT = realpath($targetPath) ?: $targetPath;
        if (stripos($realT, $realB) === 0) {
            $relVis = trim(str_replace('\\', '/', substr($realT, strlen($realB))), '/');
        }
        
        $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];
        $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
        
        $parts = explode('/', $relVis);
        $check = '';
        foreach ($parts as $part) {
            if ($part === '') continue;
            $check = trim($check . '/' . $part, '/');
            if ((isset($visSettings[$check]) && $visSettings[$check] === 'private') || 
                (isset($folderPerms[$check]) && !empty($folderPerms[$check]['is_private']))) {
                throw new Exception("Zugriff verweigert (Ordner ist privat).");
            }
        }
    }

    switch ($action) {
        case 'list':
            if (!is_dir($targetPath))
                throw new Exception("Verzeichnis nicht gefunden.");

            $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];
            $folderPerms = defined('FOLDER_PERMISSIONS') ? (json_decode(FOLDER_PERMISSIONS, true) ?? []) : [];
            $realBase    = realpath($baseDir) ?: $baseDir;

            $files  = scandir($targetPath);
            $result = [];
            foreach ($files as $f) {
                if ($f === '.' || $f === '..') continue;
                if (in_array($f, ['api.php', 'upload.php', 'download.php', 'config.php', 'admin_login.php', 'login_filemanager.php'])) continue;

                $full     = $targetPath . DIRECTORY_SEPARATOR . $f;
                $realFull = realpath($full) ?: $full;

                // Relativer Pfad für Sichtbarkeits-Check
                $relItem = '';
                if (stripos($realFull, $realBase) === 0) {
                    $relItem = trim(str_replace('\\', '/', substr($realFull, strlen($realBase))), '/');
                }

                // Effektive Sichtbarkeit prüfen (inkl. Eltern-Ordner & Ordner-Regeln)
                $isPrivateItem = false;
                $parts = explode('/', $relItem);
                $check = '';
                foreach ($parts as $part) {
                    $check = trim($check . '/' . $part, '/');
                    // Check 1: Explizite Sichtbarkeits-Einstellung
                    if (isset($visSettings[$check]) && $visSettings[$check] === 'private') {
                        $isPrivateItem = true;
                        break;
                    }
                    // Check 2: Ordnerspezifische Regel (is_private Flag)
                    if (isset($folderPerms[$check]) && !empty($folderPerms[$check]['is_private'])) {
                        $isPrivateItem = true;
                        break;
                    }
                }

                $result[] = [
                    'name'      => $f,
                    'type'      => is_dir($full) ? 'folder' : 'file',
                    'date'      => date('d.m.Y H:i', filemtime($full)),
                    'isPrivate' => $isPrivateItem,
                    '_relPath'  => $relItem,   // intern für Filter
                ];
            }
            // Sortierung: Ordner zuerst
            usort($result, fn($a, $b) => strcmp($b['type'], $a['type']));

            // Filterung für Nicht-Admins
            if (!$isAdmin) {
                $sensitive = ['filemanager', 'config', 'sql', 'install', 'uploads', '.htaccess', '.env'];
                $result = array_values(array_filter($result, function ($file) use ($sensitive, $visSettings) {
                    if (in_array($file['name'], $sensitive)) return false;
                    // Eigenes privat-Flag prüfen
                    if ($file['isPrivate']) return false;
                    // Alle Parent-Ordner prüfen
                    $parts = explode('/', $file['_relPath']);
                    $check = '';
                    foreach ($parts as $part) {
                        $check = trim($check . '/' . $part, '/');
                        if (isset($visSettings[$check]) && $visSettings[$check] === 'private') return false;
                    }
                    return true;
                }));
            }

            // _relPath aus der Antwort entfernen (intern)
            foreach ($result as &$item) unset($item['_relPath']);
            unset($item);

            echo json_encode(['success' => true, 'files' => $result, 'currentPath' => $targetPath, 'isAdmin' => $isAdmin]);
            break;

        case 'get_content':
        case 'open':
            if (!is_file($targetPath))
                throw new Exception("Keine Datei.");
            echo json_encode(['success' => true, 'content' => file_get_contents($targetPath)]);
            break;

        case 'save_content':
        case 'save':
            if (!hasPermission('save', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Bearbeiten nicht erlaubt).");
            
            if (!$isAdmin) {
                $ext = pathinfo($targetPath, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), ['php', 'phtml', 'htaccess', 'env'])) {
                    throw new Exception("Sicherheitswarnung: Dateityp verboten.");
                }
            }
            $content = $input['content'] ?? $_POST['content'] ?? '';
            if (file_put_contents($targetPath, $content) === false)
                throw new Exception("Speichern fehlgeschlagen.");
            echo json_encode(['success' => 'Datei erfolgreich gespeichert.']);
            break;

        case 'create':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $type = $input['type'] ?? $_POST['type'] ?? 'file';
            $name = $input['fileName'] ?? $_POST['fileName'] ?? '';
            if (!$name)
                throw new Exception("Kein Name angegeben.");

            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");

            if (file_exists($newPath))
                throw new Exception("Bereits vorhanden.");
            if ($type === 'folder') {
                if (!mkdir($newPath, 0755))
                    throw new Exception("Ordner erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Ordner erfolgreich erstellt.']);
            } else {
                if (file_put_contents($newPath, "") === false)
                    throw new Exception("Datei erstellen fehlgeschlagen.");
                echo json_encode(['success' => 'Datei erfolgreich erstellt.']);
            }
            break;

        case 'create_folder':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Ordnername.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Ordner existiert bereits.");
            if (!mkdir($newPath, 0755))
                throw new Exception("Konnte Ordner nicht erstellen.");
            echo json_encode(['success' => 'Ordner erstellt.']);
            break;

        case 'create_file':
            if (!hasPermission('create', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Erstellen nicht erlaubt).");
            $name = $input['name'] ?? $_POST['name'] ?? '';
            if (!$name)
                throw new Exception("Kein Dateiname.");
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $name);
            if (!resolvePath($newPath, $baseDir))
                throw new Exception("Unzulässiger Pfad.");
            if (file_exists($newPath))
                throw new Exception("Datei existiert bereits.");
            if (file_put_contents($newPath, "") === false)
                throw new Exception("Konnte Datei nicht erstellen.");
            echo json_encode(['success' => 'Datei erstellt.']);
            break;

        case 'delete':
            if (!hasPermission('delete', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Löschen nicht erlaubt).");
            if (is_dir($targetPath)) {
                // Rekursives Löschen von Ordnern (Vorsicht!)
                $it = new RecursiveDirectoryIterator($targetPath, RecursiveDirectoryIterator::SKIP_DOTS);
                $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                foreach ($files as $file) {
                    if ($file->isDir())
                        rmdir($file->getRealPath());
                    else
                        unlink($file->getRealPath());
                }
                rmdir($targetPath);
            } else {
                unlink($targetPath);
            }
            echo json_encode(['success' => 'Erfolgreich gelöscht.']);
            break;

        case 'rename':
            if (!hasPermission('rename', $targetPath, $baseDir, $isAdmin))
                throw new Exception("Zugriff verweigert (Umbenennen nicht erlaubt).");
            $oldName = $input['oldName'] ?? $_POST['oldName'] ?? '';
            $newName = $input['newName'] ?? $_POST['newName'] ?? '';
            if (!$oldName || !$newName)
                throw new Exception("Namen fehlen.");

            $oldPath = $targetPath . DIRECTORY_SEPARATOR . $oldName;
            $newPath = $targetPath . DIRECTORY_SEPARATOR . preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $newName);

            if (!resolvePath($oldPath, $baseDir) || !resolvePath($newPath, $baseDir)) {
                throw new Exception("Pfad-Fehler.");
            }
            if (rename($oldPath, $newPath)) {
                echo json_encode(['success' => 'Umbenannt.']);
            } else {
                throw new Exception("Umbenennen fehlgeschlagen.");
            }
            break;



        case 'get_visibility':
            // $pathInput ist bereits der volle Pfad (z.B. /var/www/html/projekt)
            $pathInput   = $_GET['path'] ?? '';
            $relVis      = normalizeVisibilityPath($pathInput, $baseDir);
            $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];
            echo json_encode(['status' => $visSettings[$relVis] ?? 'public', 'rel' => $relVis]);
            break;

        case 'set_visibility':
            if (!$isAdmin) throw new Exception("Admin-Rechte erforderlich.");
            $pathInput = $input['path']    ?? '';
            $status    = $input['status']  ?? 'public';
            $cascade   = !empty($input['cascade']);

            $relVis      = normalizeVisibilityPath($pathInput, $baseDir);
            $visSettings = defined('VISIBILITY_SETTINGS') ? (json_decode(VISIBILITY_SETTINGS, true) ?? []) : [];

            if ($status === 'private') {
                $visSettings[$relVis] = 'private';
            } else {
                unset($visSettings[$relVis]);
                // Cascade: alle Kinder-Einträge ebenfalls öffentlich setzen
                if ($cascade && $relVis !== '') {
                    foreach (array_keys($visSettings) as $key) {
                        if (strpos($key, $relVis . '/') === 0) unset($visSettings[$key]);
                    }
                }
            }

            $json    = json_encode($visSettings, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $content = file_get_contents($securityFile);
            if (strpos($content, "'VISIBILITY_SETTINGS'") !== false) {
                $content = preg_replace("/define\('VISIBILITY_SETTINGS', '.*?'\);/s", "define('VISIBILITY_SETTINGS', '$json');", $content);
            } else {
                $content .= "\ndefine('VISIBILITY_SETTINGS', '$json');\n";
            }
            if (function_exists('opcache_invalidate')) opcache_invalidate($securityFile, true);
            file_put_contents($securityFile, $content);
            $label = $relVis ?: 'Root';
            $cascadeMsg = ($cascade && $status === 'public') ? ' (inkl. Unterelemente)' : '';
            echo json_encode(['success' => "\"$label\" auf " . ($status === 'private' ? 'Privat' : 'Öffentlich') . " gesetzt$cascadeMsg."]);
            break;

        default:
            throw new Exception('Unbekannte Aktion: ' . $action);
    }

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}