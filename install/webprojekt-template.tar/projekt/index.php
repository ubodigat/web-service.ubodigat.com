<?php
declare(strict_types=1);

/* =========================================
   🔐 Web-Access Schutz einbinden
   ========================================= */
// 1. Config laden (Relativ zum Projektordner)
$securityFile = __DIR__ . '/../config/security.php';

if (file_exists($securityFile)) {
    require_once $securityFile;

    // 2. Prüfung: Ist Schutz AN? Und fehlt das Cookie?
    if (
        defined('WEB_ACCESS_ENABLED') &&
        WEB_ACCESS_ENABLED === true &&
        (empty($_COOKIE['web_access']) || $_COOKIE['web_access'] !== '1')
    ) {
        // 3. Zurück zum Login (Relativer Pfad für Portabilität!)
        header('Location: ../web_login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Erfolgreich</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>🚀 Setup Erfolgreich</h1>
        <p>
            Dein Web-Service wurde erfolgreich eingerichtet. Dies ist die Startseite deines neuen Projekts.
        </p>

        <div class="admin-grid">
            <a href="../filemanager/" class="btn">
                <span class="icon">📁</span>
                <span class="label">Dateimanager</span>
            </a>
            <a href="/phpmyadmin" target="_blank" class="btn">
                <span class="icon">🗄️</span>
                <span class="label">Datenbank</span>
            </a>
        </div>

        <div class="footer-info">
            <p>Du kannst diese Seite in <code>projekt/index.php</code> bearbeiten.</p>
        </div>
    </div>
</body>
</html>