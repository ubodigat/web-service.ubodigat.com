<?php
declare(strict_types=1);
session_start();

// 1. Konfiguration & Sicherheit laden
$securityFile = __DIR__ . '/../config/security.php';
$configFile   = __DIR__ . '/config.php';

if (!file_exists($securityFile) || !file_exists($configFile)) {
    http_response_code(500);
    exit('❌ Konfigurationsdateien fehlen.');
}
require_once $securityFile;
require_once $configFile;

// 2. Zugriffskontrolle (Muss identisch zu file_manager.php sein)
$sessionKey = 'filemanager_access';
$cookieName = 'filemanager_access';

if (
    (empty($_SESSION[$sessionKey]) && empty($_SESSION['admin_access'])) ||
    empty($_COOKIE[$cookieName])
) {
    http_response_code(403);
    exit('❌ Zugriff verweigert.');
}

// 3. Timeout Check
$timeout = (defined('FILEMANAGER_TIMEOUT') && FILEMANAGER_TIMEOUT > 0) ? FILEMANAGER_TIMEOUT : 1800;

if (isset($_SESSION['filemanager_last_action']) && (time() - $_SESSION['filemanager_last_action'] > $timeout)) {
    http_response_code(401);
    exit('❌ Sitzung abgelaufen.');
}
$_SESSION['filemanager_last_action'] = time();

// 4. Basis-Pfad & Admin-Status
$baseDirRaw = '/var/www/html/webseite/aeup-projekt';
$baseDir    = realpath($baseDirRaw);

if ($baseDir === false) {
    http_response_code(500);
    exit('❌ Basisverzeichnis nicht erreichbar.');
}

$isAdmin = !empty($_SESSION['admin_access']);

// ---------------------------------------------------------
// Parameter Validierung (Hier war der Fehler!)
// ---------------------------------------------------------

// Wir erwarten nur 'path', der den vollen Pfad zur Datei/Ordner enthält
$requestPath = $_GET['path'] ?? '';

if ($requestPath === '') {
    http_response_code(400);
    exit('❌ Kein Pfad angegeben.');
}

// ---------------------------------------------------------
// Pfad-Sicherheit (Sandbox)
// ---------------------------------------------------------

$fullPath = realpath($requestPath);

// Existenz-Check
if ($fullPath === false || !file_exists($fullPath)) {
    http_response_code(404);
    exit('❌ Datei oder Ordner nicht gefunden.');
}

// Sandbox-Check: Ausbruch verhindern (nur für Nicht-Admins)
if (!$isAdmin) {
    if (strpos($fullPath, $baseDir) !== 0) {
        http_response_code(403);
        exit('❌ Zugriff außerhalb des Projektordners verboten.');
    }
}

// ---------------------------------------------------------
// Fall A: Es ist ein ORDNER -> Als ZIP herunterladen
// ---------------------------------------------------------
if (is_dir($fullPath)) {

    // Temp-Datei für das ZIP
    $zipFilename = basename($fullPath) . '.zip';
    $tempZipPath = sys_get_temp_dir() . '/' . uniqid('zip_') . '.zip';

    $zip = new ZipArchive();
    if ($zip->open($tempZipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        http_response_code(500);
        exit('❌ ZIP konnte nicht erstellt werden.');
    }

    // Rekursiv alle Dateien hinzufügen
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS)
    );

    $maxFiles = 5000; // DoS Schutz
    $count = 0;

    foreach ($iterator as $file) {
        if (++$count > $maxFiles) {
            $zip->close();
            unlink($tempZipPath);
            http_response_code(413); // Payload Too Large
            exit('❌ ZIP enthält zu viele Dateien (Limit 5000).');
        }

        // Pfad innerhalb des Zips relativ machen
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($fullPath) + 1);
        
        if (!$file->isDir()) {
             $zip->addFile($filePath, $relativePath);
        } else {
             $zip->addEmptyDir($relativePath);
        }
    }

    $zip->close();

    // Download starten
    if (file_exists($tempZipPath)) {
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zipFilename . '"');
        header('Content-Length: ' . filesize($tempZipPath));
        header('Pragma: no-cache');
        readfile($tempZipPath);
        
        // Aufräumen
        unlink($tempZipPath);
        exit;
    } else {
        http_response_code(500);
        exit('❌ Fehler beim Erstellen der ZIP-Datei.');
    }
}

// ---------------------------------------------------------
// Fall B: Es ist eine DATEI -> Direkt herunterladen
// ---------------------------------------------------------
if (is_file($fullPath)) {
    
    // MIME-Type ermitteln (besser als octet-stream)
    $mimeType = mime_content_type($fullPath) ?: 'application/octet-stream';
    
    header('Content-Description: File Transfer');
    header('Content-Type: ' . $mimeType);
    header('Content-Disposition: attachment; filename="' . basename($fullPath) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($fullPath));
    header('X-Content-Type-Options: nosniff'); // Security Header
    
    // Puffer leeren, um korrupte Downloads zu verhindern
    if (ob_get_level()) ob_end_clean();
    flush();
    
    readfile($fullPath);
    exit;
}

// Falls weder Datei noch Ordner (z.B. Symlink ins Nichts)
http_response_code(400);
exit('❌ Ungültiger Dateityp.');