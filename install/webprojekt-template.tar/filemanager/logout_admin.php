<?php
declare(strict_types=1);
session_start();

unset($_SESSION['admin_access']);
unset($_SESSION['filemanager_access']);
unset($_SESSION['filemanager_last_action']);

setcookie(
    'filemanager_access',
    '',
    [
        'expires'  => time() - 3600,
        'path'     => '/filemanager',
        'secure'   => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Strict'
    ]
);

session_regenerate_id(true);

header('Location: login_filemanager.php');
exit;