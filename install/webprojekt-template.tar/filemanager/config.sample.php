<?php
    $db_host = 'localhost';
    $db_user = 'DB_BENUTZER_PLATZHALTER';
    $db_pass = 'DB_PASSWORT_PLATZHALTER';
    $db_name = 'DB_NAME_PLATZHALTER';
?>