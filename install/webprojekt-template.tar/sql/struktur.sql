-- Optionale Beispielstruktur
CREATE TABLE IF NOT EXISTS einstellungen (
    id INT AUTO_INCREMENT PRIMARY KEY,
    schluessel VARCHAR(100),
    wert TEXT
);

-- Demodaten für Einstellungen
INSERT IGNORE INTO einstellungen (schluessel, wert) VALUES 
('seitenname', 'Mein Webprojekt'),
('theme', 'dark'),
('admin_email', 'admin@example.com');

-- Demo-Tabelle für Inhalte
CREATE TABLE IF NOT EXISTS inhalte (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titel VARCHAR(255) NOT NULL,
    text TEXT,
    erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demodaten für Inhalte
INSERT IGNORE INTO inhalte (titel, text) VALUES 
('Willkommen', 'Dies ist ein erster Beispiel-Beitrag.'),
('Feature Liste', '1. Schnell, 2. Sicher, 3. Einfach.');